package constant;

public enum EDisease {
	CANCER, HEARTH_ATTACK
}
