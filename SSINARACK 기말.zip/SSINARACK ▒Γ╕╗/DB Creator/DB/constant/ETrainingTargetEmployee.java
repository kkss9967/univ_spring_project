package constant;

public enum ETrainingTargetEmployee {
	salesMan, SalesManager
}
