package constant;

public enum ETest {t1, t2}
