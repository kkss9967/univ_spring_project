package constant;

public enum ETargetCustomer {
	children, teenager, twenties, thirties, forties, fifties, sixties,
	eifhties, nineties, uptohundred
}
