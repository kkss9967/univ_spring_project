package constant;

public enum EInsuranceType {
	Car, Fire, Disease
}
