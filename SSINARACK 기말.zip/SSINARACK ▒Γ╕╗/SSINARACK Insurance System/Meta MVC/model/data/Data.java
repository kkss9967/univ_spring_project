package model.data;

public class Data {

	// Attribute
	private int iD;
	
	// Getter & Setter
	public void setID(int iD) {this.iD=iD;}
	public int getID() {return this.iD;}
}
