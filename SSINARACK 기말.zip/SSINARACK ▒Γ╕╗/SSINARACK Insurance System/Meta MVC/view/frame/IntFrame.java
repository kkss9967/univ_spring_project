package view.frame;

import view.panel.BasicPanel;

public interface IntFrame {

	// Any Time Use
	public void showPanel(BasicPanel view);
}


