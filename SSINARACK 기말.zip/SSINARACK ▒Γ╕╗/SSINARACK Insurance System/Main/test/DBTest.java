package test;

public class DBTest {
	
	// cd C:\Program Files\MySQL\MySQL Server 8.0\bin
	// mysql -u root -p
	// test_0607_1
	
	public static void test() {
//		MySQLStub mySQL = new MySQLStub();
		
		// Insert
//		int id = mySQL.insert("Insurance", null, "18", "18", true, false, 18.18, "Car");
//		System.out.println(id);
		
		// Update
//		mySQL.update("Insurance", "insuranceID", 1999, "insuranceName", "fuck");
		
		// Delete
//		mySQL.delete("Insurance", "insuranceID", 1999); // Select Test �� �� ���� ��
		
		// Select 1
//		System.out.println(mySQL.getString("Insurance", "insuranceID", 1999, "insuranceName"));
//		System.out.println(mySQL.getString("Insurance", "insuranceID", 1999, "content"));
//		
//		// Select 2
//		ResultSet rs = mySQL.select("Insurance", "insuranceID", 1999);
//		try {
//			if(rs.next()) {
//				System.out.println(rs.getString("insuranceName"));
//				System.out.println(rs.getString("content"));
//				System.out.println(rs.getBoolean("insuranceRatePermit"));
//				System.out.println(rs.getBoolean("productPermit"));
//				System.out.println(rs.getDouble("lossPercent"));
//				System.out.println(rs.getString("insuranceType"));
//			}
//		} catch (SQLException e) {e.printStackTrace();}
	}
}
