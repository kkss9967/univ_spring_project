package dbConstant;

public class DBConstant {
	public final static String URL = "jdbc:mysql://localhost/insurance?serverTimezone=UTC&useSSL=false";
	public final static String USER = "root";
	public final static String PW = "sh199919";
	public final static String DB = "ssinarack";
}
