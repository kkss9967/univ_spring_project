package model.data.taskData;

import model.data.Data;

public abstract class AbsTask extends Data{
}
