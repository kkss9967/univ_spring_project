package model.data.employeeData.salesEmployeeData;

import model.data.employeeData.AbsEmployeeData;
import model.data.taskData.AbsTask;

public class SalesManData extends AbsEmployeeData<AbsTask> {
}
