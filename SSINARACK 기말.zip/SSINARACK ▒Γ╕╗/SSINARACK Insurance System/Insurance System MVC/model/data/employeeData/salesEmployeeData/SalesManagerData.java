package model.data.employeeData.salesEmployeeData;

import model.data.employeeData.AbsEmployeeData;
import model.data.taskData.AbsTask;

public class SalesManagerData extends AbsEmployeeData<AbsTask> {
}
