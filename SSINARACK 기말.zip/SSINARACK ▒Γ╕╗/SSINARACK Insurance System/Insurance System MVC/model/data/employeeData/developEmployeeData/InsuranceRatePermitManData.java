package model.data.employeeData.developEmployeeData;

import model.data.employeeData.AbsEmployeeData;
import model.data.taskData.developTask.InsurancePermitTask;

public class InsuranceRatePermitManData extends AbsEmployeeData<InsurancePermitTask> {
}
