package model.data.employeeData.developEmployeeData;

import model.data.employeeData.AbsEmployeeData;
import model.data.taskData.AbsTask;

public class DeveloperData extends AbsEmployeeData<AbsTask> {
}
