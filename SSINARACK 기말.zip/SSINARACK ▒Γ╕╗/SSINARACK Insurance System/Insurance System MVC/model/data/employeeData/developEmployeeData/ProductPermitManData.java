package model.data.employeeData.developEmployeeData;

import model.data.employeeData.AbsEmployeeData;
import model.data.taskData.developTask.InsurancePermitTask;

public class ProductPermitManData extends AbsEmployeeData<InsurancePermitTask> {
}
