package model.data.employeeData.rewardEmployeeData;

import model.data.employeeData.AbsEmployeeData;
import model.data.taskData.rewardTask.LawSuitTask;

public class LawyerData extends AbsEmployeeData<LawSuitTask>{
}
