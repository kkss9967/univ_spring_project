package model.data.employeeData.rewardEmployeeData;

import model.data.employeeData.AbsEmployeeData;
import model.data.taskData.rewardTask.LossCheckTask;

public class LossCheckManData extends AbsEmployeeData<LossCheckTask>{
}
