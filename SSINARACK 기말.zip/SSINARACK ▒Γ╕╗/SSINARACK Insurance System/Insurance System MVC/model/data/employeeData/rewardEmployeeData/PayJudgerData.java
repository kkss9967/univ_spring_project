package model.data.employeeData.rewardEmployeeData;

import model.data.employeeData.AbsEmployeeData;
import model.data.taskData.rewardTask.PayJudgeTask;

public class PayJudgerData extends AbsEmployeeData<PayJudgeTask> {
}
