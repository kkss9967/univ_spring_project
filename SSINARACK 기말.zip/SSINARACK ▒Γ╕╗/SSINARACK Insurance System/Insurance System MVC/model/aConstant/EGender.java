package model.aConstant;

public enum EGender {
	male, female
}
