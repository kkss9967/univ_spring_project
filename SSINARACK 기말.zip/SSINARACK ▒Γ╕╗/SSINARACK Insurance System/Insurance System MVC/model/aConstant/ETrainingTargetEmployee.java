package model.aConstant;

public enum ETrainingTargetEmployee {
	salesMan, SalesManager
}
