package model.aConstant;

public enum EFamilyIllHistory {
	 Cancer, Diabetes,  Stroke, HeartDisease, HighBloodPressure
}
