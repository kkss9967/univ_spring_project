package service;

import login.RealLoginControl;

public enum StartServiceAdapter {
	StartService(new RealLoginControl())
	;
	private Service_LV0 service;
	private StartServiceAdapter(Service_LV0 service) {this.service=service;}
	public void start() {this.service.start();}
}
