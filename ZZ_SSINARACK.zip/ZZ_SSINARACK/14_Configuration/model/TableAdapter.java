package model;

import java.util.Vector;

import model.data.Data_LV1;
import model.table.Table_LV0;

public class TableAdapter {
	
	private static Vector<Table_LV0<? extends Data_LV1>> tm = TestModelCreator.createTestModel();
	
	public enum ETableAdapter{
		developerDataList(tm.get(0)),
		insuranceRatePermitManDataList(tm.get(1)),
		productPermitManDataList(tm.get(2)),
		accidentInvestigatorDataList(tm.get(3)),
		payJudgerDataList(tm.get(4)),
		lossCheckManDataList(tm.get(5)),
		lawyerDataList(tm.get(6)),
		insuranceDataList(tm.get(7)),
		customerDataList(tm.get(8)),
		rewardDataList(tm.get(9)),
		salesManDataList(tm.get(10)),
		salesManagerDataList(tm.get(11)),
		activityPlanDataList(tm.get(12)),
		salesTrainigPlanDataList(tm.get(13)),
		;
		private Table_LV0<? extends Data_LV1> table;
		private ETableAdapter(Table_LV0<? extends Data_LV1> table) {this.table=table;}
		public Table_LV0<? extends Data_LV1> getTable() {return this.table;}
	}
}
