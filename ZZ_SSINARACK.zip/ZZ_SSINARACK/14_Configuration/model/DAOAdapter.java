package model;

import db.DAO;
import db.DAO_LV0;

public class DAOAdapter {

	public static DAO_LV0 getPlugged() {
		return new DAO(); 
	}
}
