package model;

import java.util.Vector;

import model.data.Data_LV1;
import model.table.Table_LV0;
import model.table.Table_LV1;
import specificModel.data.SalesTrainingPlanData.SalesTrainingPlanData;
import specificModel.data.activityPlanData.ActivityPlanData;
import specificModel.data.customerData.CustomerData;
import specificModel.data.employeeData.developEmployeeData.DeveloperData;
import specificModel.data.employeeData.developEmployeeData.InsuranceRatePermitManData;
import specificModel.data.employeeData.developEmployeeData.ProductPermitManData;
import specificModel.data.employeeData.rewardEmployeeData.AccidentInvestigatorData;
import specificModel.data.employeeData.rewardEmployeeData.LawyerData;
import specificModel.data.employeeData.rewardEmployeeData.LossCheckManData;
import specificModel.data.employeeData.rewardEmployeeData.PayJudgerData;
import specificModel.data.employeeData.salesEmployeeData.SalesManData;
import specificModel.data.employeeData.salesEmployeeData.SalesManagerData;
import specificModel.data.insuranceData.AbsInsuranceData;
import specificModel.data.rewardData.RewardData;
import specificModel.enums.EDataListID;

public class TestModelCreator {
	
	public static Vector<Table_LV0<? extends Data_LV1>> createTestModel() {
		Vector<Table_LV0<? extends Data_LV1>> result = new Vector<Table_LV0<? extends Data_LV1>>();
		
		// Create Data
		DeveloperData developer = new DeveloperData();
		developer.setName("Developer");
		developer.setLoginID("d");
		developer.setLoginPW("123");
		
		InsuranceRatePermitManData insuranceRatePermitManData = new InsuranceRatePermitManData();
		insuranceRatePermitManData.setName("InsuranceRatePermitManData");
		insuranceRatePermitManData.setLoginID("i");
		insuranceRatePermitManData.setLoginPW("123");
		
		ProductPermitManData productPermitManData = new ProductPermitManData();
		productPermitManData.setName("ProductPermitManData");
		productPermitManData.setLoginID("p");
		productPermitManData.setLoginPW("123");
		
		SalesManData salesManData = new SalesManData();
		salesManData.setName("SalesMan");
		salesManData.setLoginID("s");
		salesManData.setLoginPW("123");
		
		SalesManagerData salesManagerData = new SalesManagerData();
		salesManagerData.setName("SalesManager");
		salesManagerData.setLoginID("ss");
		salesManagerData.setLoginPW("123");
		
		AccidentInvestigatorData accidentInvestigatorData = new AccidentInvestigatorData();
		accidentInvestigatorData.setName("AccidentInvestigatorData");
		accidentInvestigatorData.setLoginID("ai");
		accidentInvestigatorData.setLoginPW("123");
		
		PayJudgerData payJudgerData = new PayJudgerData();
		payJudgerData.setName("PayJudgerData");
		payJudgerData.setLoginID("pj");
		payJudgerData.setLoginPW("123");
		
		LossCheckManData lossCheckManData = new LossCheckManData();
		lossCheckManData.setName("LossCheckManData");
		lossCheckManData.setLoginID("lc");
		lossCheckManData.setLoginPW("123");
		
		LawyerData lawyerData = new LawyerData();
		lawyerData.setName("LawyerData");
		lawyerData.setLoginID("ld");
		lawyerData.setLoginPW("123");
		
		// Create Model
		// Develop
		Table_LV1<DeveloperData> developerDataList = new Table_LV1<DeveloperData>();
		developerDataList.setID(EDataListID.DeveloperDataListID.ordinal());
		developerDataList.add(developer);
		
		Table_LV1<InsuranceRatePermitManData> insuranceRatePermitManDataList = new Table_LV1<InsuranceRatePermitManData>();
		insuranceRatePermitManDataList.setID(EDataListID.InsuranceRatePermitManDataListID.ordinal());
		insuranceRatePermitManDataList.add(insuranceRatePermitManData);
		
		Table_LV1<ProductPermitManData> productPermitManDataList = new Table_LV1<ProductPermitManData>();
		productPermitManDataList.setID(EDataListID.ProductPermitManDataListID.ordinal());
		productPermitManDataList.add(productPermitManData);
		
		Table_LV1<AbsInsuranceData> insuranceDataList = new Table_LV1<AbsInsuranceData>();
		insuranceDataList.setID(EDataListID.InsuranceDataListID.ordinal());
		
		// Sales
		Table_LV1<SalesManData> salesManDataList = new Table_LV1<SalesManData>(); //������� ����Ʈ �����
		salesManDataList.setID(EDataListID.SalesManDataListID.ordinal());
		salesManDataList.add(salesManData); //������� �߰��ϱ�
		
		Table_LV1<SalesManagerData> salesManagerDataList = new Table_LV1<SalesManagerData>(); //������� ����Ʈ �����
		salesManagerDataList.setID(EDataListID.SalesManagerDataListID.ordinal());
		salesManagerDataList.add(salesManagerData); //������� �߰��ϱ�
		
		Table_LV1<ActivityPlanData> activityPlanDataList = new Table_LV1<ActivityPlanData>();  
		activityPlanDataList.setID(EDataListID.ActivityPlanDataListID.ordinal());
		
		Table_LV1<SalesTrainingPlanData> salesTrainigPlanDataList = new Table_LV1<SalesTrainingPlanData>(); 
		salesTrainigPlanDataList.setID(EDataListID.SalesTrainigPlanDataListID.ordinal());
		
		// Reward
		Table_LV1<CustomerData> customerDataList = new Table_LV1<CustomerData>();
		customerDataList.setID(EDataListID.CustomerDataListID.ordinal());
		
		Table_LV1<AccidentInvestigatorData> accidentInvestigatorDataList = new Table_LV1<AccidentInvestigatorData>();
		accidentInvestigatorDataList.setID(EDataListID.AccidentInvestigatorDataListID.ordinal());
		accidentInvestigatorDataList.add(accidentInvestigatorData);
		
		Table_LV1<PayJudgerData> payJudgerDataList = new Table_LV1<PayJudgerData>();
		payJudgerDataList.setID(EDataListID.PayJudgerDataListID.ordinal());
		payJudgerDataList.add(payJudgerData);
		
		Table_LV1<LossCheckManData> lossCheckManDataList = new Table_LV1<LossCheckManData>();
		lossCheckManDataList.setID(EDataListID.LossCheckManDataListID.ordinal());
		lossCheckManDataList.add(lossCheckManData);
		
		Table_LV1<LawyerData> lawyerDataList = new Table_LV1<LawyerData>();
		lawyerDataList.setID(EDataListID.LawyerDataListID.ordinal());
		lawyerDataList.add(lawyerData);
		
		Table_LV1<RewardData> rewardDataList = new Table_LV1<RewardData>();
		rewardDataList.setID(EDataListID.RewardDataListID.ordinal());
		
		result.add(developerDataList);
		result.add(insuranceRatePermitManDataList);
		result.add(productPermitManDataList);
//		result.add(customerDataList);
		result.add(accidentInvestigatorDataList);
		result.add(payJudgerDataList);
		result.add(lossCheckManDataList);
		result.add(lawyerDataList);
		result.add(insuranceDataList);
		result.add(customerDataList);
		result.add(rewardDataList);
		result.add(salesManDataList);
		result.add(salesManagerDataList);
		result.add(activityPlanDataList);
		result.add(salesTrainigPlanDataList);
		
		return result;
	}
}
