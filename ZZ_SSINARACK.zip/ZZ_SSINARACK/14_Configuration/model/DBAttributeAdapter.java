package model;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class DBAttributeAdapter {

	public static ClassPathXmlApplicationContext getClassPathXmlApplicationContext() {
		return new ClassPathXmlApplicationContext("model/JSH_Attribute.xml");
	}
}
