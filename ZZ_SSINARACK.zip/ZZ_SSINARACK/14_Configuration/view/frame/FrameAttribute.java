package view.frame;

import java.awt.Dimension;

public class FrameAttribute {
	public static final String MainFrameTitle = "Insurance System";
	public static final Dimension MainFrameSize = new Dimension(1020, 720);
}
