package view.frame;

import frame.Frame_LV0;
import frame.MainFrame;

public enum FrameAdapter {
	MainFrame(new MainFrame())
	;
	private Frame_LV0 frame;
	private FrameAdapter(Frame_LV0 frame) {this.frame=frame;}
	public Frame_LV0 getFrame() {return this.frame;}
}
