package view.panel;

import panel.Panel_LV0;
import panel.panel.developView.developer.DeveloperTaskSelectView;
import panel.panel.developView.developer.developInsurance.DevelopInsuranceSelectView;
import panel.panel.developView.developer.developInsurance.DevelopInsuranceView;
import panel.panel.developView.developer.showInsurance.SelectInsuranceToWatchView;
import panel.panel.developView.developer.showInsurance.ShowInsuranceInfoView;
import panel.panel.developView.insuranceRatePermitAndProductPermitMan.PermitTaskSelectView;
import panel.panel.developView.insuranceRatePermitAndProductPermitMan.ShowInsuranceForJudgeView;
import panel.panel.loginView.LoginView;
import panel.panel.rewardView.customer.AccidentProcessApplyView;
import panel.panel.rewardView.customer.CustomerTaskSelectView;
import panel.panel.rewardView.customer.PaymentAgreeView;
import panel.panel.rewardView.customer.ShowPaymentAgreeView;
import panel.panel.rewardView.investigator.InvestigatorTaskSelectView;
import panel.panel.rewardView.investigator.ShowAccidentInfoForIVView;
import panel.panel.rewardView.investigator.WriteInvestReportView;
import panel.panel.rewardView.lawyer.LawsuitTaskSelectView;
import panel.panel.rewardView.lawyer.ShowRewardDataInfoForLwView;
import panel.panel.rewardView.lawyer.WriteSueReportView;
import panel.panel.rewardView.lossChecker.LossCheckTaskSelectView;
import panel.panel.rewardView.lossChecker.ShowLossCheckInfosView;
import panel.panel.rewardView.lossChecker.WriteLossCheckReportView;
import panel.panel.rewardView.payJudger.PayJudgerTaskSelectView;
import panel.panel.rewardView.payJudger.ShowAccInvestInfoForPJView;
import panel.panel.rewardView.payJudger.WritePayJudgeReportView;
import panel.panel.salesView.salesMan.SalesManTaskSelectView;
import panel.panel.salesView.salesMan.LookupAvailableProduct.SearchCustomerView;
import panel.panel.salesView.salesMan.LookupAvailableProduct.ShowAvailableProductView;
import panel.panel.salesView.salesMan.LookupAvailableProduct.ShowCustomerInfoView;
import panel.panel.salesView.salesMan.LookupAvailableProduct.ShowInsuranceInfoToCustomerView;
import panel.panel.salesView.salesMan.SigninCustomer.SigninCustomerView;
import panel.panel.salesView.salesMan.watchActivityPlan.WatchActivityPlanView;
import panel.panel.salesView.salesMan.watchActivityPlan.WatchDetailActivityPlanView;
import panel.panel.salesView.salesMan.watchSalesTrainingPlan.WatchDetailSalesTrainingPlanView;
import panel.panel.salesView.salesMan.watchSalesTrainingPlan.WatchSalesTrainingPlanView;
import panel.panel.salesView.salesManager.SalesManagerTaskSelectView;
import panel.panel.salesView.salesManager.SaveActivityPlanView;
import panel.panel.salesView.salesManager.SaveSalesTrainingPlanView;

public enum PanelAdapter {
//	LoginPanel(new LoginPanel()),
//	;
//	private Panel_LV0 panel;
//	private PanelAdapter(Panel_LV0 frame) {this.panel=frame;}
//	public Panel_LV0 getPanel() {return this.panel;}
	
	// Login
	LoginView(new LoginView()),
	
	// Develop
	DevelopInsuranceSelectView(new DevelopInsuranceSelectView()),
	DevelopInsuranceView(new DevelopInsuranceView()),
	
	SelectInsuranceToWatchView(new SelectInsuranceToWatchView()),
	ShowInsuranceInfoView(new ShowInsuranceInfoView()),
	
	DeveloperTaskSelectView(new DeveloperTaskSelectView()),
	
	PermitTaskSelectView(new PermitTaskSelectView()),
	ShowInsuranceForJudgeView(new ShowInsuranceForJudgeView()),
	
	// Sales
	// SalesManager
	SalesManagerTaskSelectView(new SalesManagerTaskSelectView()),
	
	SaveActivityPlanView(new SaveActivityPlanView()),
	SaveSalesTrainingPlanView(new SaveSalesTrainingPlanView()),
	
	// SalesMan
	SalesManTaskSelectView(new SalesManTaskSelectView()),
	
	SigninCustomerView(new SigninCustomerView()),
	
	WatchActivityPlanView(new WatchActivityPlanView()),
	WatchDetailActivityPlanView(new WatchDetailActivityPlanView()),
	
	WatchSalesTrainingPlanView(new WatchSalesTrainingPlanView()),
	WatchDetailSalesTrainingPlanView(new WatchDetailSalesTrainingPlanView()),
	
	ShowAvailableProductView(new ShowAvailableProductView()),
	SearchCustomerView(new SearchCustomerView()),
	ShowCustomerInfoView(new ShowCustomerInfoView()),
	ShowInsuranceInfoToCustomerView(new ShowInsuranceInfoToCustomerView()),
	
	
	// Reward
	AccidentProcessApplyView(new AccidentProcessApplyView()),
	CustomerTaskSelectView(new CustomerTaskSelectView()),
	PaymentAgreeView(new PaymentAgreeView()),
	ShowPaymentAgreeView(new ShowPaymentAgreeView()),
	
	InvestigatorTaskSelectView(new InvestigatorTaskSelectView()),
	ShowAccidentInfoForIVView(new ShowAccidentInfoForIVView()),
	WriteInvestReportView(new WriteInvestReportView()),
	
	LawsuitTaskSelectView(new LawsuitTaskSelectView()),
	ShowRewardDataInfoForLwView(new ShowRewardDataInfoForLwView()),
	WriteSueReportView(new WriteSueReportView()),
	
	LossCheckTaskSelectView(new LossCheckTaskSelectView()),
	ShowLossCheckInfosView(new ShowLossCheckInfosView()),
	WriteLossCheckReportView(new WriteLossCheckReportView()),
	
	PayJudgerTaskSelectView(new PayJudgerTaskSelectView()),
	ShowAccInvestInfoForPJView(new ShowAccInvestInfoForPJView()),
	WritePayJudgeReportView(new WritePayJudgeReportView()),
	;
	private Panel_LV0 view;
	private PanelAdapter(Panel_LV0 view) {this.view=view;}
	public Panel_LV0 getPanel() {return this.view;}
}
