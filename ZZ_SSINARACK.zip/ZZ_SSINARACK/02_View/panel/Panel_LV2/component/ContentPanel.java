package panel.Panel_LV2.component;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JComponent;
import javax.swing.JPanel;

import component.button.BackButton;
import component.button.LogoutButton;
import view.component.ViewConstant;
import view.component.button.BackButtonConfiguration;
import view.component.button.LogoutButtonConfiguration;
import view.panel.Panel_LV2Configuration;

@SuppressWarnings("serial")
public class ContentPanel extends JPanel {

	// Component
	private JPanel toolPanel, mainPanel;
			
	public ContentPanel() {
		// Set Attribute
		this.setLayout(new BorderLayout());
		this.setBackground(Panel_LV2Configuration.ContentPanelBackground);
		
		// Create Component
		this.toolPanel = new JPanel();
		this.toolPanel.setLayout(new BorderLayout());
		this.toolPanel.setBackground(Panel_LV2Configuration.ContentPanelBackground);
		this.add(this.toolPanel, BorderLayout.NORTH);
		
		this.mainPanel = new JPanel();
		this.mainPanel.setBackground(Panel_LV2Configuration.ContentPanelBackground);
		this.mainPanel.setLayout(new BoxLayout(this.mainPanel, BoxLayout.Y_AXIS));
		this.mainPanel.setBorder(BorderFactory.createEmptyBorder(0, 32, 0, 32));
		this.add(this.mainPanel, BorderLayout.CENTER);
	}
	
	// Initialize Time Use
	public void addComponent(JComponent comp) {
		comp.setAlignmentX(CENTER_ALIGNMENT);
		this.mainPanel.add(comp);
		this.mainPanel.add(Box.createVerticalStrut(ViewConstant.BasicPanelComponentGap));
	}
	public void addToolBTN(Component comp, String borderLayoutPosition) {this.toolPanel.add(comp, borderLayoutPosition);}
	public void addBackAndLogoutButton() {
		bb = new BackButton(); this.toolPanel.add(bb, BorderLayout.WEST);
		lb = new LogoutButton(); this.toolPanel.add(lb, BorderLayout.EAST);
	}
	public void addBackAndLogoutButtonActionListener(ActionListener actionListener) {
		bb.addActionListener(actionListener);
		lb.addActionListener(actionListener);
	}
	BackButton bb;
	LogoutButton lb;
	public void removeBackAndLogoutButton() {
		this.remove(bb);
		this.remove(lb);
		this.addEmptyToolSpace();
	}
	public void addEmptyToolSpace() {
		this.addToolBTN(Box.createVerticalStrut(BackButtonConfiguration.BackButtonSize.height), BorderLayout.WEST);
		this.addToolBTN(Box.createVerticalStrut(LogoutButtonConfiguration.LogoutButtonSize.height), BorderLayout.EAST);		
	}

	public void clear() {
		this.mainPanel.removeAll();
	}
}
