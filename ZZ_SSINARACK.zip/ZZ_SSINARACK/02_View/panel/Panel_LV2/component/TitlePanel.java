package panel.Panel_LV2.component;

import java.awt.FlowLayout;

import javax.swing.JLabel;
import javax.swing.JPanel;

import view.panel.Panel_LV2Configuration;

@SuppressWarnings("serial")
public class TitlePanel extends JPanel {

	// Constructor
	public TitlePanel() {
		// Set Attribute
		this.setBackground(Panel_LV2Configuration.TitlePanelBackground);
		this.setLayout(new FlowLayout(FlowLayout.LEFT));
		
		// Create Component
		JLabel titleLabel = new JLabel(Panel_LV2Configuration.TitlePanelTitle);
		titleLabel.setFont(Panel_LV2Configuration.TitlePanelTitleFont);
		titleLabel.setForeground(Panel_LV2Configuration.TitlePanelForeground);
		this.add(titleLabel);
	}
}
