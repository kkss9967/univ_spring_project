package panel.Panel_LV2.component;

import java.awt.Dimension;

import javax.swing.BoxLayout;
import javax.swing.JComponent;
import javax.swing.JPanel;

import component.etc.SeparateLine;
import view.panel.Panel_LV2Configuration;

@SuppressWarnings("serial")
public class LinkPanel extends JPanel {

	// Constructor
	public LinkPanel() {
		// Set Attribute
		this.setBackground(Panel_LV2Configuration.LinkPanelBackground);
		this.setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		this.setPreferredSize(new Dimension(230, Integer.MAX_VALUE));
	}
	
	public void addToLinkPanel(JComponent comp) {
		this.add(comp);
		this.add(new SeparateLine(Panel_LV2Configuration.LinkPanelSeperatorColor));
	}
}
