package panel.Panel_LV2;

import java.awt.BorderLayout;
import java.awt.event.ActionListener;

import javax.swing.Box;
import javax.swing.JComponent;

import panel.Panel_LV1;
import panel.Panel_LV2.component.CenterPanel;
import view.panel.Panel_LV2Configuration;

@SuppressWarnings("serial")
public abstract class Panel_LV2 extends Panel_LV1 {
	
	// Component
	private CenterPanel centerPanel;
	
	// Constructor
	public Panel_LV2() {
		// Set Attributes
		this.setBackground(Panel_LV2Configuration.InsuranceSystemPanelBackground);
		this.setLayout(new BorderLayout());
		
		// Create Component
		this.centerPanel = new CenterPanel();
		this.add(this.centerPanel, BorderLayout.CENTER);
		this.add(Box.createHorizontalStrut(Panel_LV2Configuration.LeftRightMargin), BorderLayout.WEST);
		this.add(Box.createHorizontalStrut(Panel_LV2Configuration.LeftRightMargin), BorderLayout.EAST);
		this.add(Box.createVerticalStrut(Panel_LV2Configuration.DownMargin), BorderLayout.SOUTH);
		
		this.addBackAndLogoutButton();
	}
	
	// Create Time Use
	public void addToLinkPanel(JComponent...comps) {this.centerPanel.addToLinkPanel(comps);}
	public void setLinkPanelWidth(int w) {this.centerPanel.setLinkPanelWidth(w);}
	
	// Initialize Time Use
	public void addComponent(JComponent comp) {this.centerPanel.addComponent(comp);}
	public void addBackAndLogoutButton() {this.centerPanel.addBackAndLogoutButton();}
	public void addBackAndLogoutButtonActionListener(ActionListener actionListener) {this.centerPanel.addBackAndLogoutButtonActionListener(actionListener);}
	public void removeBackAndLogoutButton() {this.centerPanel.removeBackAndLogoutButton();}
	public void addEmptyToolSpace() {this.centerPanel.addEmptyToolSpace();}
	
	@Override 
	public void setActionListener(ActionListener actionListener) {
		super.setActionListener(actionListener);
		this.addBackAndLogoutButtonActionListener(actionListener);
		this.centerPanel.clear(); // ? �ߺ� ������ �߻��Ͽ� ���⼭ ó��
	}
	
	@Override
	public void end() {
		// this.centerPanel.clear(); // ? �ߺ� ������ �߻��Ͽ� ���⼭ ó��
	}
}
