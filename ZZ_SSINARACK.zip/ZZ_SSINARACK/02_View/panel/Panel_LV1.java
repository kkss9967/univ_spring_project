package panel;

import java.awt.event.ActionListener;

import javax.swing.JPanel;

@SuppressWarnings("serial")
public abstract class Panel_LV1 extends JPanel implements Panel_LV0 {
	
	// Association
	protected ActionListener actionListener;

	// Getter & Setter
	@Override public void setActionListener(ActionListener actionListener) {this.actionListener=actionListener;}
}
