package panel;

import java.awt.event.ActionListener;

import common.IntCommon;

public interface Panel_LV0 extends IntCommon {
	
	// Getter & Setter
	public void setActionListener(ActionListener actionListener);
}
