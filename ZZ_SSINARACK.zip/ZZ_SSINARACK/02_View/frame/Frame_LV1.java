package frame;

import java.awt.Component;

import javax.swing.JFrame;
import javax.swing.JPanel;

import view.frame.Frame_LV1Configuration;

@SuppressWarnings("serial")
public class Frame_LV1 extends JFrame implements Frame_LV0 {

	// Working Variable
	private JPanel nowPanel;
	
	// Constructor
	public Frame_LV1() {
		// Set Attribute
		this.setTitle(Frame_LV1Configuration.MainFrameTitle);
		this.getContentPane().setPreferredSize(Frame_LV1Configuration.MainFrameSize); this.pack(); // Set Frame Size By Set ContentPane Size
		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setAlwaysOnTop(true);
//		this.setResizable(false);
	}
	
	@Override public void start() {this.setVisible(true);}
	@Override public void end() {this.dispose();}
	
	@Override
	public void showPanel(JPanel panel) {
		if(this.nowPanel!=null) {this.remove((Component) this.nowPanel);}
		this.nowPanel = panel;
		this.add(panel);
		this.revalidate();
		this.repaint();
	}
}
