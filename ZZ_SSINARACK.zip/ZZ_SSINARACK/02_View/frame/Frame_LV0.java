package frame;

import javax.swing.JPanel;

import common.IntCommon;

public interface Frame_LV0 extends IntCommon {
	
	// Method
	public void showPanel(JPanel panel);
}
