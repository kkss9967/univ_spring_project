package component.button;

import java.awt.Dimension;
import java.awt.event.ActionListener;

import javax.swing.SwingConstants;

import view.component.button.LinkButtonConfiguration;

@SuppressWarnings("serial")
public class LinkButton extends BasicButton {
	
	// Constructor
	public LinkButton(String text, String actionCommand, ActionListener actionListener) {
		super(text, actionCommand, actionListener);
		this.setPreferredSize(new Dimension(Integer.MAX_VALUE, LinkButtonConfiguration.LinkButtonPreferredHeight));
		this.setMaximumSize(new Dimension(Integer.MAX_VALUE, LinkButtonConfiguration.LinkButtonPreferredHeight));
		this.setFont(LinkButtonConfiguration.LinkButtonFont);
		this.setBackground(LinkButtonConfiguration.LinkButtonBackgroundColor);
		this.setClickColor(LinkButtonConfiguration.LinkButtonClickColor);
		this.setMouseOnColor(LinkButtonConfiguration.LinkButtonMouseOnColor);
		this.setForeground(LinkButtonConfiguration.LinkButtonForegroundColor);
		this.setHorizontalAlignment(SwingConstants.LEFT);
	}
}
