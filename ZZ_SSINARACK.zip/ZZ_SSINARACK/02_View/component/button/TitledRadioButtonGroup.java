package component.button;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.util.Arrays;
import java.util.Vector;

import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;

import view.component.button.TitledRadioButtonGroupConfiguration;

@SuppressWarnings("serial")
public class TitledRadioButtonGroup extends JPanel {
	
	// Component
	private JLabel titleLabel; 
	private Vector<BasicRadioButton> btns;
	
	// Constructor
	public TitledRadioButtonGroup(String title, Class<? extends Enum<?>> targetEnum, boolean multiSelectable, int nameWidth) {
		// Set Attribute
		this.setLayout(new BorderLayout());
		this.setBackground(TitledRadioButtonGroupConfiguration.TitledRadioButtonGroupBackground);
		this.setMaximumSize(new Dimension(Integer.MAX_VALUE, TitledRadioButtonGroupConfiguration.TitledRadioButtonButtonMaximumSize.height*this.getEnumNames(targetEnum).length));
		
		// Create Component
		JPanel innerPanel = new JPanel();
		innerPanel.setBackground(TitledRadioButtonGroupConfiguration.TitledRadioButtonInnerPanelColor);
		innerPanel.setLayout(new BorderLayout());
		this.add(innerPanel, BorderLayout.WEST);
		
		this.titleLabel = new JLabel("  "+title);
		this.titleLabel.setFont(TitledRadioButtonGroupConfiguration.TitledRadioButtonLabelFont);
		this.titleLabel.setPreferredSize(new Dimension(nameWidth, TitledRadioButtonGroupConfiguration.TitledRadioButtonLabelFont.getSize()));
		innerPanel.add(this.titleLabel, BorderLayout.CENTER);
		
		JPanel innerPanel2 = new JPanel();
		innerPanel2.setLayout(new BoxLayout(innerPanel2, BoxLayout.Y_AXIS));
		innerPanel2.setBackground(TitledRadioButtonGroupConfiguration.TitledRadioButtonGroupBackground);
		this.add(innerPanel2, BorderLayout.CENTER);
		
		this.btns = new Vector<BasicRadioButton>();
		ButtonGroup group = new ButtonGroup();
		for(String optionName : this.getEnumNames(targetEnum)) {
			this.btns.add(new BasicRadioButton(optionName));
			if(!multiSelectable) {group.add(this.btns.lastElement());}
			innerPanel2.add(this.btns.lastElement());
		}
		this.btns.firstElement().setSelected(true);
	}
	
	// Getter & Setter
	private String[] getEnumNames(Class<? extends Enum<?>> e) {
	    return Arrays.stream(e.getEnumConstants()).map(Enum::name).toArray(String[]::new);
	}
	public String getTitle() {return this.titleLabel.getText();}
	public Vector<String> getSelectedOptionNames() {
		Vector<String> result = new Vector<String>();
		for(BasicRadioButton btn : this.btns) {if(btn.isSelected()) {result.add(btn.getText());}}
		return result;
	}
	
	// Inner Class
	private class BasicRadioButton extends JRadioButton {
		// Constructor
		public BasicRadioButton(String text) { 
			// Set Attribute
		    this.setIcon(new ImageIcon(TitledRadioButtonGroupConfiguration.TitledRadioButtonGroupNormalIcon));
		    this.setSelectedIcon(new ImageIcon(TitledRadioButtonGroupConfiguration.TitledRadioButtonGroupSelectedIcon));
			this.setText(text);
			this.setForeground(TitledRadioButtonGroupConfiguration.TitledRadioButtonGroupTextColor);
			this.setBackground(TitledRadioButtonGroupConfiguration.TitledRadioButtonGroupButtonColor);
			this.setMaximumSize(TitledRadioButtonGroupConfiguration.TitledRadioButtonButtonMaximumSize);
			this.setBorderPainted(false);
			this.setFocusPainted(false);
			this.setFocusable(false);
		}
	}
}
