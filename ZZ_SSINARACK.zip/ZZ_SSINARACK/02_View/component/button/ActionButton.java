package component.button;

import java.awt.event.ActionListener;

import javax.swing.BorderFactory;

import view.component.button.ActionButtonConfiguration;

@SuppressWarnings("serial")
public class ActionButton extends BasicButton {
	
	// Constructor
	public ActionButton(String text, String actionCommand, ActionListener actionListener) {
		super(text, actionCommand, actionListener);
		this.setBackground(ActionButtonConfiguration.ActionButtonBackground_Normal);
		this.setClickColor(ActionButtonConfiguration.ActionButtonBackground_Clicked);
		this.setMouseOnColor(ActionButtonConfiguration.ActionButtonBackground_MouseOn);
		this.setBorderPainted(true);
		this.setBorder(BorderFactory.createLineBorder(ActionButtonConfiguration.ActionButtonBorderColor));
		this.setForeground(ActionButtonConfiguration.ActionButtonForeground);
	}
}
