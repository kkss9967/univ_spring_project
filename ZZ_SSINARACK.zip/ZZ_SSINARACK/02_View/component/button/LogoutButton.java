package component.button;

import view.component.button.LogoutButtonConfiguration;

@SuppressWarnings("serial")
public class LogoutButton extends BasicButton {
	
	// Constructor
	public LogoutButton() {
		super(LogoutButtonConfiguration.LogoutButtonText, LogoutButtonConfiguration.ActionCommand, null);
		this.setPreferredSize(LogoutButtonConfiguration.LogoutButtonSize);
		this.setBackground(LogoutButtonConfiguration.LogoutButtonBackground);
		this.setClickColor(LogoutButtonConfiguration.LogoutButtonBackground);
		this.setMouseOnColor(LogoutButtonConfiguration.LogoutButtonBackground);
		this.setForeground(LogoutButtonConfiguration.LogoutButtonForeground);
	}
}
