package component.button;

import view.component.button.BackButtonConfiguration; 

@SuppressWarnings("serial")
public class BackButton extends BasicButton {
	
	// Constructor
	public BackButton() {
		super(BackButtonConfiguration.BackButtonText, BackButtonConfiguration.ActionCommand, null);
		this.setPreferredSize(BackButtonConfiguration.BackButtonSize);
		this.setBackground(BackButtonConfiguration.BackButtonBackground);
		this.setClickColor(BackButtonConfiguration.BackButtonBackground);
		this.setMouseOnColor(BackButtonConfiguration.BackButtonBackground);
		this.setForeground(BackButtonConfiguration.BackButtonForeground);
	}
}
