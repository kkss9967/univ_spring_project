package component.button;

import java.awt.event.ActionListener; 

import javax.swing.BorderFactory;
import javax.swing.SwingConstants;

import view.component.button.SelectButtonConfiguration;

@SuppressWarnings("serial")
public class SelectButton extends BasicButton {
	
	// Constructor
	public SelectButton(String text, String actionCommand, ActionListener actionListener) {
		super("    "+text, actionCommand, actionListener);
		this.setBackground(SelectButtonConfiguration.SelectButtonBackground_Normal);
		this.setClickColor(SelectButtonConfiguration.SelectButtonBackground_Clicked);
		this.setMouseOnColor(SelectButtonConfiguration.SelectButtonBackground_MouseOn);
		this.setBorderPainted(true);
		this.setBorder(BorderFactory.createLineBorder(SelectButtonConfiguration.SelectButtonBorderColor));
		this.setForeground(SelectButtonConfiguration.SelectButtonForeground);
		this.setHorizontalAlignment(SwingConstants.LEFT);
	}
}
