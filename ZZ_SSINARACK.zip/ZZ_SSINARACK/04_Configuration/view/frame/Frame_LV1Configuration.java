package view.frame;

import java.awt.Dimension;

public class Frame_LV1Configuration {
	public static final String MainFrameTitle = "Frame_LV1";
	public static final Dimension MainFrameSize = new Dimension(1020, 720);
}
