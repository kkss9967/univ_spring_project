package view.component.label;

import java.awt.Color;

public class LabelConfiguration {
	public static final Color BasicLabelBackground = Color.white;
	public static final String BasicLabelFont = "���� ����";
}
