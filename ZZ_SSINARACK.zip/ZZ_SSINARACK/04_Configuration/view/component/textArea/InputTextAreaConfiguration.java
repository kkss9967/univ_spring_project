package view.component.textArea;

import java.awt.Color;
import java.awt.Font;

import javax.swing.BorderFactory;
import javax.swing.border.Border;

public class InputTextAreaConfiguration {
	public static final Font InputTextAreaPanelLabelFont = new Font("���� ����", Font.PLAIN, 15);
	public static final int InputTextAreaPanelTextAreaHeightUnit = 20;
	public static final Color InputTextAreaPanelBackground = new Color(235,240,245);
	public static final int InputTextAreaBasicBound = 20;
	public static final int InputTextAreaBasicColumn = 20;
	public static final Border InputTextAreaEmptyBorder = BorderFactory.createEmptyBorder(5, 5, 5, 5);
	public static final Border InputTextAreaBorder = BorderFactory.createLineBorder(new Color(173,185,193));
	public static final Border InputTextAreaPanelBorder = BorderFactory.createLineBorder(new Color(220,226,229));
}
