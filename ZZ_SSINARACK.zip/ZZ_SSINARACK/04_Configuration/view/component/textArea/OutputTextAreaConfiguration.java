package view.component.textArea;

import java.awt.Color;
import java.awt.Font;

import javax.swing.BorderFactory;
import javax.swing.border.Border;

public class OutputTextAreaConfiguration {
	public static final Color OutputTextAreaPanelBackground = Color.white;
	public static final int OutputTextAreaPanelTextAreaHeightUnit = 20;
	public static final Font OutputTextAreaPanelLabelFont = new Font("���� ����", Font.BOLD, 15);
	public static final Border OutputTextAreaEmptyBorder = BorderFactory.createEmptyBorder(5, 15, 0, 0);
}
