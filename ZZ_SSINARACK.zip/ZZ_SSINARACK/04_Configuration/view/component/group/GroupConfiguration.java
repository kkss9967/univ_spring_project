package view.component.group;

import java.awt.Color;

public class GroupConfiguration {
	public static final Color BasicGroupBorderColor = new Color(220,226,229);
}
