package view.component;

import java.awt.Color;

public class ViewConstant {

	// Theme
	public static final Color ThemeColor = Color.white;
	
	// Basic Panel
	public static final Color BasicPanelBackground = ViewConstant.ThemeColor;
	public static final int BasicPanelVerticalScrollUnit = 16;
	public static final int BasicPanelComponentGap = 10;
}
