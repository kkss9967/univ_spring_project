package view.component.button;

import java.awt.Color;
import java.awt.Dimension;

import view.component.ViewConstant;

public class BackButtonConfiguration {
	public static final String BackButtonText = "��";
	public static final String ActionCommand = "Back237819";
	public static final Dimension BackButtonSize = new Dimension(50, 30);
	public static final Color BackButtonForeground = new Color(161,165,177);
	public static final Color BackButtonBackground = ViewConstant.ThemeColor;
}
