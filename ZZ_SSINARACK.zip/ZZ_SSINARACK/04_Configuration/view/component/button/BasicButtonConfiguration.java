package view.component.button;

import java.awt.Color;

public class BasicButtonConfiguration {
	public static final Color BasicButtonBackground_Clicked = new Color(255,90,0);
	public static final Color BasicButtonBackground_MouseOn = new Color(255,120,0);
	public static final Color BasicButtonBackground_Normal =  new Color(161,165,177);
	public static final Color BasicButtonForeground =  Color.white;
}
