package view.component.button;

import java.awt.Color;
import java.awt.Dimension;

import view.component.ViewConstant;

public class LogoutButtonConfiguration {
	public static final String LogoutButtonText = "Logout";
	public static final String ActionCommand = "Logout23781asfwf9";
	public static final Dimension LogoutButtonSize = new Dimension(80, 30);
	public static final Color LogoutButtonForeground = new Color(161,165,177);
	public static final Color LogoutButtonBackground = ViewConstant.ThemeColor;
}
