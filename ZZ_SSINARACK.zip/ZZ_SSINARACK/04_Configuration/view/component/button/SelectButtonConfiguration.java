package view.component.button;

import java.awt.Color;

public class SelectButtonConfiguration {
	public static final Color SelectButtonForeground =new Color(106,107,112);
	public static final Color SelectButtonBackground_Normal = Color.white;
	public static final Color SelectButtonBackground_Clicked = new Color(214,231,248);
	public static final Color SelectButtonBackground_MouseOn = new Color(214,231,248);
	public static final Color SelectButtonBorderColor = new Color(229,234,239);
}
