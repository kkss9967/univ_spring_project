package view.component.button;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;

import view.component.ViewConstant;

public class TitledRadioButtonGroupConfiguration {
	public static final String TitledRadioButtonGroupNormalIcon = "06_Resource/view/component/titledRadioButtonGroup/Radio_Normal.png";
	public static final String TitledRadioButtonGroupSelectedIcon = "06_Resource/view/component/titledRadioButtonGroup/Radio_Selected.png";
	public static final Color TitledRadioButtonGroupBackground = ViewConstant.ThemeColor;
	public static final Color TitledRadioButtonGroupButtonColor = ViewConstant.ThemeColor;
	public static final Color TitledRadioButtonGroupTextColor = new Color(110,110,110);
	public static final int TitledRadioButtonTitleHeightSize = 20;
	public static final Dimension TitledRadioButtonButtonMaximumSize = new Dimension(Integer.MAX_VALUE, 27);
	public static final Font TitledRadioButtonLabelFont = new Font("���� ����", Font.PLAIN, 15);
	
	public static final Color TitledRadioButtonInnerPanelColor = new Color(235,240,245);
}
