package view.component.button;

import java.awt.Color;

public class ActionButtonConfiguration {
	public static final Color ActionButtonForeground =new Color(106,107,112);
	public static final Color ActionButtonBackground_Normal = Color.white;
	public static final Color ActionButtonBackground_Clicked = new Color(214,231,248);
	public static final Color ActionButtonBackground_MouseOn = new Color(214,231,248);
	public static final Color ActionButtonBorderColor = new Color(229,234,239);
}
