package view.component.button;

import java.awt.Color; 
import java.awt.Font;

public class LinkButtonConfiguration {
	public static final int LinkButtonPreferredHeight = 65;
	public static final Color LinkButtonBackgroundColor = new Color(220,225,231);
	public static final Color LinkButtonClickColor = new Color(220,225,231);
	public static final Color LinkButtonMouseOnColor = new Color(242,245,250);
	public static final Color LinkButtonForegroundColor = new Color(68,68,68);
	public static final Font LinkButtonFont = new Font("���� ����", Font.PLAIN, 20);
}
