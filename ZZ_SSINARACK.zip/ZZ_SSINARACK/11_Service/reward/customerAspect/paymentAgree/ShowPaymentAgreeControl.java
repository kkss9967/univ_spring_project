package reward.customerAspect.paymentAgree;

import java.awt.event.ActionEvent;

import javax.swing.JOptionPane;

import model.table.Table_LV0;
import panel.panel.rewardView.customer.ShowPaymentAgreeView;
import panel.panelInterface.reward.IntShowPaymentAgreeView;
import reward.RewardControl;
import reward.customerAspect.accidentProcessApply.AccidentProcessApplyControl;
import specificModel.data.customerData.CustomerData;
import specificModel.data.rewardData.RewardData;
import view.frame.FrameAdapter;
import view.panel.PanelAdapter;

public class ShowPaymentAgreeControl extends RewardControl {
	
	// Static
	public enum EActionCommands {AccidentProcessApply, isPaymentAgree}
	
	// Association
	private CustomerData user;
	private Table_LV0<RewardData> rewardDataList;
	
	// Component
	private ShowPaymentAgreeView view;
	
	// Constructor
	public ShowPaymentAgreeControl(CustomerData user, Table_LV0<RewardData> rewardDataList) {
		super(FrameAdapter.MainFrame, PanelAdapter.ShowPaymentAgreeView);
		
		this.user=user; 
		this.rewardDataList=rewardDataList;
		
		IntShowPaymentAgreeView view = (IntShowPaymentAgreeView) this.getPanel();
		view.setUser(this.user);
		view.setRewardDataList(this.rewardDataList);
	}

	@Override
	public void processEvent(ActionEvent e) {
		try {EActionCommands.valueOf(e.getActionCommand());}
		catch(IllegalArgumentException ee) {this.startNewService(new PaymentAgreeControl(this.user, Integer.parseInt(e.getActionCommand())));return;}
		
		switch (EActionCommands.valueOf(e.getActionCommand())) {
		case AccidentProcessApply : this.startNewService(new AccidentProcessApplyControl(this.user)); break;
		case isPaymentAgree : 
			if(user.getTaskList().getList().isEmpty()) {
				JOptionPane.showMessageDialog(this.view, "��� ���� ����� ���ų� ������ �Ϸ���� �ʾҽ��ϴ�.", "�ȳ�", JOptionPane.WARNING_MESSAGE);
			}else {
				this.startNewService(new ShowPaymentAgreeControl(user, this.rewardDataList)); 
			}
			break;
		}
	}
}