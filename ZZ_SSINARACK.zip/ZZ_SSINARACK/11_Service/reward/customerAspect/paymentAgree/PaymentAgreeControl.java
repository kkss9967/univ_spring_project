package reward.customerAspect.paymentAgree;

import java.awt.Component;
import java.awt.event.ActionEvent;

import javax.swing.JOptionPane;

import panel.panelInterface.reward.IntPaymentAgreeView;
import reward.RewardControl;
import reward.customerAspect.accidentProcessApply.AccidentProcessApplyControl;
import specificModel.data.customerData.CustomerData;
import specificModel.data.employeeData.rewardEmployeeData.LawyerData;
import specificModel.data.rewardData.RewardData;
import specificModel.data.taskData.rewardTask.LawSuitTask;
import view.frame.FrameAdapter;
import view.panel.PanelAdapter;

public class PaymentAgreeControl extends RewardControl {
	
	// Static
	public enum EActionCommands {AccidentProcessApply, isPaymentAgree, Permit, Ban}
	
	// Attribute
	private int taskID;
	
	// Association
	private CustomerData user;
	
	// Component
	private IntPaymentAgreeView view;
	
	// Constructor
	public PaymentAgreeControl(CustomerData user, int taskID) {
		super(FrameAdapter.MainFrame, PanelAdapter.PaymentAgreeView);
		
		this.user=user; 
		this.taskID=taskID;
		
		this.view = (IntPaymentAgreeView) this.getPanel();
		this.view.setRewardData(this.rewardDataList.search(this.user.getTaskList().search(this.taskID).getRewardDataID()));
	}
	
	@Override
	public void processEvent(ActionEvent e) {
		switch (EActionCommands.valueOf(e.getActionCommand())) {
		case AccidentProcessApply : this.startNewService(new AccidentProcessApplyControl(this.user)); break;
		case isPaymentAgree : 
			if(user.getTaskList().getList().isEmpty()) {
				JOptionPane.showMessageDialog((Component) this.view, "��� ���� ����� ���ų� ������ �Ϸ���� �ʾҽ��ϴ�.", "�ȳ�", JOptionPane.WARNING_MESSAGE);
			}else {
				this.startNewService(new ShowPaymentAgreeControl(user, this.rewardDataList)); 
			}
			break;
		case Permit : JOptionPane.showMessageDialog((Component) this.view, "����� ������ �Ϸ�Ǿ����ϴ�.", "����� ���� �ȳ�", JOptionPane.INFORMATION_MESSAGE); break;
		case Ban : this.orderLawsuit(); JOptionPane.showMessageDialog((Component) this.view, "�Ҽ� ������ �����մϴ�. �Ҽ� ����� ���� ������� ���޵˴ϴ�."); break;
		default: break; 	
		}
		this.user.deleteTask(this.taskID);
		this.startPreviousService();	
	}
	
	private void orderLawsuit() {
		RewardData rewardData = this.rewardDataList.search(this.user.getTaskList().search(this.taskID).getRewardDataID());	
		for(LawyerData employee : this.lawyerList.getList()) {
			if(employee.isWorkable()) {employee.addTask(new LawSuitTask(rewardData.getID()));
			}
		}
	}	
}
