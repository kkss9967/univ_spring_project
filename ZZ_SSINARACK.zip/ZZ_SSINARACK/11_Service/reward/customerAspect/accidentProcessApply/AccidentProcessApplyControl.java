package reward.customerAspect.accidentProcessApply;

import java.awt.Component;
import java.awt.event.ActionEvent;

import javax.swing.JOptionPane;

import panel.panelInterface.reward.IntAccidentProcessApplyView;
import reward.RewardControl;
import reward.customerAspect.CustomerTaskSelectControl;
import reward.customerAspect.paymentAgree.ShowPaymentAgreeControl;
import specificModel.data.customerData.CustomerData;
import specificModel.data.employeeData.rewardEmployeeData.AccidentInvestigatorData;
import specificModel.data.rewardData.AccidentData;
import specificModel.data.rewardData.RewardData;
import specificModel.data.taskData.rewardTask.AccidentInvestigationTask;
import view.frame.FrameAdapter;
import view.panel.PanelAdapter;

public class AccidentProcessApplyControl extends RewardControl{

	// Static
	public enum EActionCommands {SaveAccidentData, AccidentProcessApply, isPaymentAgree}
		
	// Association
	private CustomerData user;
	
	// Component
	private IntAccidentProcessApplyView view;
	
	public AccidentProcessApplyControl(CustomerData user) {
		super(FrameAdapter.MainFrame, PanelAdapter.AccidentProcessApplyView);
		
		this.user=user;
		
		this.view = (IntAccidentProcessApplyView) this.getPanel();
	}
	
	@Override
	public void processEvent(ActionEvent e) {
		switch (EActionCommands.valueOf(e.getActionCommand())) {
		case SaveAccidentData : this.save(); this.startNewService(new CustomerTaskSelectControl(user)); break;
		case AccidentProcessApply : this.startNewService( new AccidentProcessApplyControl(this.user)); break;
		case isPaymentAgree : 
			if(user.getTaskList().getList().isEmpty()) {
				JOptionPane.showMessageDialog((Component) this.view, "��� ���� ����� ���ų� ������ �Ϸ���� �ʾҽ��ϴ�.", "�ȳ�", JOptionPane.WARNING_MESSAGE);
			}else {
				this.startNewService(new ShowPaymentAgreeControl(user, rewardDataList)); 
			}
			break;
		}
	}
	
	private void save() {
		RewardData rewardData = new RewardData();
		AccidentData data = new AccidentData();
		data.setType(this.view.getAccidentType());
		data.setLocation(this.view.getAccidentLocation());
		data.setDate(this.view.getAccidentDate());
		rewardData.setAccidentData(data);
		this.rewardDataList.add(rewardData);
		
		for(AccidentInvestigatorData employee : this.accidentInvestigatorList.getList()) {
			if(employee.isWorkable()) {employee.addTask(new AccidentInvestigationTask(rewardData.getID())); break;}
		}
	}

}
