package reward.customerAspect;

import java.awt.Component;
import java.awt.event.ActionEvent;

import javax.swing.JOptionPane;

import panel.panelInterface.reward.IntCustomerTaskSelectView;
import reward.RewardControl;
import reward.customerAspect.accidentProcessApply.AccidentProcessApplyControl;
import reward.customerAspect.paymentAgree.ShowPaymentAgreeControl;
import specificModel.data.customerData.CustomerData;
import view.frame.FrameAdapter;
import view.panel.PanelAdapter;

public class CustomerTaskSelectControl extends RewardControl {
	
	// Static
	public enum EActionCommands {AccidentProcessApply, isPaymentAgree}
	
	// Association
	private CustomerData user;
	
	// Component
	private IntCustomerTaskSelectView view;
	
	// Constructor
	public CustomerTaskSelectControl(CustomerData user) {
		super(FrameAdapter.MainFrame, PanelAdapter.CustomerTaskSelectView);
		this.user=user;
		this.view = (IntCustomerTaskSelectView) this.getPanel();
	}

	@Override
	public void processEvent(ActionEvent e) {
		switch (EActionCommands.valueOf(e.getActionCommand())) {
		case AccidentProcessApply : this.startNewService(new AccidentProcessApplyControl(this.user)); break;
		case isPaymentAgree : 
			if(user.getTaskList().getList().isEmpty()) {
				JOptionPane.showMessageDialog((Component)this.view, "��� ���� ����� ���ų� ������ �Ϸ���� �ʾҽ��ϴ�.");
			}else {
				this.startNewService(new ShowPaymentAgreeControl(this.user, this.rewardDataList)); break;
			}
		}
//		JOptionPane.showMessageDialog((Component)this.view, "��� ���� ����� ���ų� ������ �Ϸ���� �ʾҽ��ϴ�.");
	}
}
