package reward.payJudgerAspect;

import java.awt.event.ActionEvent;

import panel.panelInterface.reward.IntPayJudgerTaskSelectView;
import reward.RewardControl;
import specificModel.data.employeeData.rewardEmployeeData.PayJudgerData;
import view.frame.FrameAdapter;
import view.panel.PanelAdapter;

public class PayJudgerTaskSelectControl extends RewardControl {

	// Association
	private PayJudgerData user;
	
	// Constructor
	public PayJudgerTaskSelectControl(PayJudgerData user) {
		super(FrameAdapter.MainFrame, PanelAdapter.PayJudgerTaskSelectView);
		
		this.user=user;
		
		IntPayJudgerTaskSelectView view = (IntPayJudgerTaskSelectView) this.getPanel();
		view.setUser(this.user);
		view.setRewardDataList(this.rewardDataList);
	}
	
	@Override
	public void processEvent(ActionEvent e) {
		if(!e.getActionCommand().equals("")) {
			this.startNewService(new ShowAccInvestInfoForPJControl(this.user, Integer.parseInt(e.getActionCommand())));
		}
	}
}
