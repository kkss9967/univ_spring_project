package reward.payJudgerAspect;

import java.awt.event.ActionEvent;

import panel.panelInterface.reward.IntWritePayJudgeReportView;
import reward.RewardControl;
import specificModel.data.employeeData.rewardEmployeeData.LossCheckManData;
import specificModel.data.employeeData.rewardEmployeeData.PayJudgerData;
import specificModel.data.rewardData.PayJudgeData;
import specificModel.data.rewardData.RewardData;
import specificModel.data.taskData.rewardTask.LossCheckTask;
import view.frame.FrameAdapter;
import view.panel.PanelAdapter;

public class WritePayJudgeReportControl extends RewardControl {

	// Static
	public enum EActionCommands {WritePayJudgeReport, SavePayJudgeData}
		
	// Component
	private IntWritePayJudgeReportView view;
		
	// Association
	private PayJudgerData user;
	private int taskID;
		
	public WritePayJudgeReportControl(PayJudgerData user, int taskID) {
		super(FrameAdapter.MainFrame, PanelAdapter.WritePayJudgeReportView);
		
		this.user=user;
		this.taskID=taskID;
		
		this.view = (IntWritePayJudgeReportView) this.getPanel();
	}
	
	@Override
	public void processEvent(ActionEvent e) {
		switch (EActionCommands.valueOf(e.getActionCommand())) {
		case SavePayJudgeData : this.save(); 
		this.user.deleteTask(this.taskID); this.startNewService(new PayJudgerTaskSelectControl(user)); 
		return;
		default:
			break;
		}
	}
	
	private void save() {
		RewardData rewardData = this.rewardDataList.search(this.user.getTaskList().search(this.taskID).getRewardDataID());
		PayJudgeData data = new PayJudgeData();
		data.setPayJudge(this.view.getPayJudgeTTA());
		data.setJudgementEvidence(this.view.getJudgementEvidenceTTA());
		data.setRelatedLaw(this.view.getRelatedLawTTA());
		rewardData.setPayJudgeData(data);
		
		for(LossCheckManData employee : this.lossCheckManList.getList()) {
			if(employee.isWorkable()) {
				employee.addTask(new LossCheckTask(rewardData.getID()));
			}
		}
	}
}
