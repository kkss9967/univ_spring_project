package reward.payJudgerAspect;

import java.awt.event.ActionEvent;

import panel.panelInterface.reward.IntShowAccInvestInfoForPJView;
import reward.RewardControl;
import specificModel.data.employeeData.rewardEmployeeData.PayJudgerData;
import view.frame.FrameAdapter;
import view.panel.PanelAdapter;

public class ShowAccInvestInfoForPJControl extends RewardControl {

	// Static
	public enum EActionCommands {WritePayJudgeReport}
	
	// Attribute
	private PayJudgerData user;
	private int taskID;
	
	// Constructor
	public ShowAccInvestInfoForPJControl(PayJudgerData user, int taskID) {
		super(FrameAdapter.MainFrame, PanelAdapter.ShowAccInvestInfoForPJView);
		
		this.user=user; this.taskID=taskID;
		
		IntShowAccInvestInfoForPJView view = (IntShowAccInvestInfoForPJView) this.getPanel();
		view.setUser(this.user);
		view.setTaskID(this.taskID);
		view.setRewardDataList(this.rewardDataList);
	}
	
	@Override 
	public void processEvent(ActionEvent e) {
		try {EActionCommands.valueOf(e.getActionCommand());}
		catch(IllegalArgumentException ee) {this.startNewService(new WritePayJudgeReportControl(this.user, this.taskID)); return;}
		
		switch (EActionCommands.valueOf(e.getActionCommand())) {
		case WritePayJudgeReport : this.startNewService(new WritePayJudgeReportControl(this.user, this.taskID)); break;
		}
	}	
}
