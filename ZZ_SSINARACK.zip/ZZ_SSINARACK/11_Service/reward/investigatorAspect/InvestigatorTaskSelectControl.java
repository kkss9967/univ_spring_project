package reward.investigatorAspect;

import java.awt.event.ActionEvent;

import panel.panelInterface.reward.IntInvestigatorTaskSelectView;
import reward.RewardControl;
import specificModel.data.employeeData.rewardEmployeeData.AccidentInvestigatorData;
import view.frame.FrameAdapter;
import view.panel.PanelAdapter;

public class InvestigatorTaskSelectControl extends RewardControl {
	
	// Association
	private AccidentInvestigatorData user;

	// Constructor
	public InvestigatorTaskSelectControl(AccidentInvestigatorData user) {
		super(FrameAdapter.MainFrame, PanelAdapter.InvestigatorTaskSelectView);
		
		this.user=user;
		
		IntInvestigatorTaskSelectView view = (IntInvestigatorTaskSelectView) this.getPanel();
		view.setUser(this.user);
		view.setRewardDataList(this.rewardDataList);
	}

	@Override
	public void processEvent(ActionEvent e) {
		if(!e.getActionCommand().equals("")) {
			this.startNewService(new ShowAccidentInfoForIVControl(this.user, Integer.parseInt(e.getActionCommand())));
		}	
	}
}
