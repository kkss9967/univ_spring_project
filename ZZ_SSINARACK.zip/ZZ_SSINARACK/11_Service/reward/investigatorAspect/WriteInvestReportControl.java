package reward.investigatorAspect;

import java.awt.Component;
import java.awt.event.ActionEvent;

import javax.swing.JOptionPane;

import panel.panelInterface.reward.IntWriteInvestReportView;
import reward.RewardControl;
import specificModel.data.employeeData.rewardEmployeeData.AccidentInvestigatorData;
import specificModel.data.employeeData.rewardEmployeeData.PayJudgerData;
import specificModel.data.rewardData.AccidentInvestigationData;
import specificModel.data.rewardData.RewardData;
import specificModel.data.taskData.rewardTask.PayJudgeTask;
import view.frame.FrameAdapter;
import view.panel.PanelAdapter;

public class WriteInvestReportControl extends RewardControl {
			
	// Static
	public enum EActionCommands {WriteInvestReport, SaveAccidentInvestigationData}
		
	// Component
	private IntWriteInvestReportView view;
	
	// Association
	private AccidentInvestigatorData user;
	private int taskID;
	
	public WriteInvestReportControl(AccidentInvestigatorData user, int taskID) {
		super(FrameAdapter.MainFrame, PanelAdapter.WriteInvestReportView);
		
		this.user=user; this.taskID=taskID;
		
		this.view = (IntWriteInvestReportView) this.getPanel();
	}

	@Override
	public void processEvent(ActionEvent e) {
		switch (EActionCommands.valueOf(e.getActionCommand())) {
		case SaveAccidentInvestigationData : if(this.isNumRight()) {
			this.save(); this.user.deleteTask(this.taskID); this.startNewService(new InvestigatorTaskSelectControl(user)); } return;
		default: break;
		}
	}
	
	private boolean isNumRight() {
		try {Double.parseDouble(this.view.getTreatmentCostTTA());}
		catch(NumberFormatException exc) {JOptionPane.showMessageDialog((Component) this.view, "��� ó�� ����� ���ڷ� �Է��� �ּ���"); return false;}
		return true;
	}

	private void save() {
		RewardData rewardData = this.rewardDataList.search(this.user.getTaskList().search(this.taskID).getRewardDataID());
		AccidentInvestigationData data = new AccidentInvestigationData();
		data.setScenario(this.view.getScenarioTTA());
		data.setDamage(this.view.getDamageTTA());
		data.setTreatment(this.view.getTreatmentTTA());
		data.setTreatmentCost(Integer.parseInt(this.view.getTreatmentCostTTA()));	
		rewardData.setAccidentInvestigationData(data);

		for(PayJudgerData employee : this.payJudgerList.getList()) {
			if(employee.isWorkable()) {employee.addTask(new PayJudgeTask(rewardData.getID()));}
		}
	}	
}