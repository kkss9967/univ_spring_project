package reward.investigatorAspect;

import java.awt.event.ActionEvent;

import panel.panelInterface.reward.IntShowAccidentInfoForIVView;
import reward.RewardControl;
import specificModel.data.employeeData.rewardEmployeeData.AccidentInvestigatorData;
import view.frame.FrameAdapter;
import view.panel.PanelAdapter;

public class ShowAccidentInfoForIVControl extends RewardControl {

	// Static
	public enum EActionCommands {WriteInvestReport}
		
	// Attribute
	private AccidentInvestigatorData user;
	private int taskID;
	
	// Constructor
	public ShowAccidentInfoForIVControl(AccidentInvestigatorData user, int taskID) {
		super(FrameAdapter.MainFrame, PanelAdapter.ShowAccidentInfoForIVView);
		
		this.user=user; this.taskID=taskID;
		
		IntShowAccidentInfoForIVView view = (IntShowAccidentInfoForIVView) this.getPanel();
		view.setUser(this.user);
		view.setTaskId(this.taskID);
		view.setRewardDataList(this.rewardDataList);
	}

	@Override 
	public void processEvent(ActionEvent e) {
		try {EActionCommands.valueOf(e.getActionCommand());}
		catch(IllegalArgumentException ee) {this.startNewService(new WriteInvestReportControl(this.user, this.taskID)); return;}
		
		switch (EActionCommands.valueOf(e.getActionCommand())) {
		case WriteInvestReport : this.startNewService(new WriteInvestReportControl(this.user, this.taskID)); break;
		}
	}	
}