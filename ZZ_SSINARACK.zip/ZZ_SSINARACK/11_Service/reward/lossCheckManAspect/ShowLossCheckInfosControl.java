package reward.lossCheckManAspect;

import java.awt.event.ActionEvent;

import panel.panelInterface.reward.IntShowLossCheckInfosView;
import reward.RewardControl;
import specificModel.data.employeeData.rewardEmployeeData.LossCheckManData;
import view.frame.FrameAdapter;
import view.panel.PanelAdapter;

public class ShowLossCheckInfosControl extends RewardControl {

	// Static
	public enum EActionCommands {WriteLossCheckReport}
	
	// Attribute
	private int taskID;
	
	// Association
	private LossCheckManData user;
		
	// Constructor
	public ShowLossCheckInfosControl(LossCheckManData user, int taskID) {
		super(FrameAdapter.MainFrame, PanelAdapter.ShowLossCheckInfosView);
		
		this.user=user;
		this.taskID=taskID;
		
		IntShowLossCheckInfosView view = (IntShowLossCheckInfosView) this.getPanel(); 
		view.setUser(this.user);
		view.setTaskId(this.taskID);
		view.setRewardDataList(this.rewardDataList);
	}
		
	@Override 
	public void processEvent(ActionEvent e) {	
		try {EActionCommands.valueOf(e.getActionCommand());}
		catch(IllegalArgumentException ee) {this.startNewService(new WriteLossCheckReportControl(this.user, this.taskID)); return;}
		
		switch (EActionCommands.valueOf(e.getActionCommand())) {
		case WriteLossCheckReport :	this.startNewService(new WriteLossCheckReportControl(this.user, this.taskID));
		}
	}
}