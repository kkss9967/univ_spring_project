package reward.lossCheckManAspect;

import java.awt.Component;
import java.awt.event.ActionEvent;

import javax.swing.JOptionPane;

import panel.panelInterface.reward.IntWriteLossCheckReportView;
import reward.RewardControl;
import specificModel.data.customerData.CustomerData;
import specificModel.data.employeeData.rewardEmployeeData.LossCheckManData;
import specificModel.data.rewardData.LossCheckData;
import specificModel.data.rewardData.RewardData;
import specificModel.data.taskData.rewardTask.PayAgreementTask;
import view.frame.FrameAdapter;
import view.panel.PanelAdapter;

public class WriteLossCheckReportControl extends RewardControl {
	
	// Static
	public enum EActionCommands {WriteLossCheckReport, SaveLossCheckData}
		
	// Component
	private IntWriteLossCheckReportView view;
	
	// Association
	private LossCheckManData user;
	private int taskID;
	
	public WriteLossCheckReportControl(LossCheckManData user, int taskID) {
		super(FrameAdapter.MainFrame, PanelAdapter.WriteLossCheckReportView);
		
		this.user=user;
		this.taskID=taskID;
		
		this.view = (IntWriteLossCheckReportView) this.getPanel();
	}
	
	@Override
	public void processEvent(ActionEvent e) {
		switch (EActionCommands.valueOf(e.getActionCommand())) {
		case SaveLossCheckData : if(this.isNumRight()) {this.save(); 
		this.user.deleteTask(this.taskID); this.startNewService(new LossCheckTaskSelectControl(user));
		} return; 
		default:break;
		}
	}
	
	private boolean isNumRight() {
		try {Double.parseDouble(this.view.getPayTTA());}
		catch(NumberFormatException exc) {JOptionPane.showMessageDialog((Component) this.view, "���� ������� ���ڷ� �Է��� �ּ���"); return false;}
		return true;
	}

	private void save() {
		RewardData rewardData = this.rewardDataList.search(this.user.getTaskList().search(this.taskID).getRewardDataID());
		LossCheckData data = new LossCheckData();
		data.setPay(Integer.parseInt(this.view.getPayTTA()));
		data.setJudgeEvidence(this.view.getJudgeEvidenceTTA());
		rewardData.setLossData(data);
		for(CustomerData customer : this.customerList.getList()) {
			customer.addTask(new PayAgreementTask(rewardData.getID()));
		}
	}
}
