package reward.lossCheckManAspect;

import java.awt.event.ActionEvent;

import panel.panelInterface.reward.IntLossCheckTaskSelectView;
import reward.RewardControl;
import specificModel.data.employeeData.rewardEmployeeData.LossCheckManData;
import view.frame.FrameAdapter;
import view.panel.PanelAdapter;

public class LossCheckTaskSelectControl extends RewardControl {

	// Association
	private LossCheckManData user;
	
	// Constructor
	public LossCheckTaskSelectControl(LossCheckManData user) {
		super(FrameAdapter.MainFrame, PanelAdapter.LossCheckTaskSelectView);
		
		this.user=user;
		
		IntLossCheckTaskSelectView view = (IntLossCheckTaskSelectView) this.getPanel();
		view.setUser(this.user);
		view.setRewardDataList(this.rewardDataList);
	}
	

	@Override
	public void processEvent(ActionEvent e) {
		if(!e.getActionCommand().equals("")) {
			this.startNewService(new ShowLossCheckInfosControl(this.user, Integer.parseInt(e.getActionCommand()))); 
		}
	}
}
