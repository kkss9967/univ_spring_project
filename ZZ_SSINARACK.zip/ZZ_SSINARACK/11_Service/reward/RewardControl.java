package reward;

import model.TableAdapter;
import model.table.Table_LV0;
import service.Service_LV2;
import specificModel.data.customerData.CustomerData;
import specificModel.data.employeeData.rewardEmployeeData.AccidentInvestigatorData;
import specificModel.data.employeeData.rewardEmployeeData.LawyerData;
import specificModel.data.employeeData.rewardEmployeeData.LossCheckManData;
import specificModel.data.employeeData.rewardEmployeeData.PayJudgerData;
import specificModel.data.rewardData.RewardData;
import view.frame.FrameAdapter;
import view.panel.PanelAdapter;

@SuppressWarnings("unchecked")
public abstract class RewardControl extends Service_LV2{
	
	// Associate
	protected Table_LV0<CustomerData> customerList= (Table_LV0<CustomerData>) TableAdapter.ETableAdapter.customerDataList.getTable();
	protected Table_LV0<AccidentInvestigatorData> accidentInvestigatorList= (Table_LV0<AccidentInvestigatorData>) TableAdapter.ETableAdapter.accidentInvestigatorDataList.getTable();
	protected Table_LV0<PayJudgerData> payJudgerList= (Table_LV0<PayJudgerData>) TableAdapter.ETableAdapter.payJudgerDataList.getTable();
	protected Table_LV0<LossCheckManData> lossCheckManList= (Table_LV0<LossCheckManData>) TableAdapter.ETableAdapter.lossCheckManDataList.getTable();
	protected Table_LV0<LawyerData> lawyerList= (Table_LV0<LawyerData>) TableAdapter.ETableAdapter.lawyerDataList.getTable();
	protected Table_LV0<RewardData> rewardDataList= (Table_LV0<RewardData>) TableAdapter.ETableAdapter.rewardDataList.getTable();

	public RewardControl(FrameAdapter frameAdapter, PanelAdapter panelAdapter) {
		super(frameAdapter, panelAdapter);
	}
}
 