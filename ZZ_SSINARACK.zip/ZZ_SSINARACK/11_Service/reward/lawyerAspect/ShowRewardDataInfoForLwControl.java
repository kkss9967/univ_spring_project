package reward.lawyerAspect;

import java.awt.event.ActionEvent;

import panel.panelInterface.reward.IntShowRewardDataInfoForLwView;
import reward.RewardControl;
import specificModel.data.employeeData.rewardEmployeeData.LawyerData;
import view.frame.FrameAdapter;
import view.panel.PanelAdapter;

public class ShowRewardDataInfoForLwControl extends RewardControl {

	// Static
	public enum EActionCommands {writeSueReport}
		
	// Attribute
	private int taskID;
	
	// Association
	private LawyerData user;
	
	// Constructor
	public ShowRewardDataInfoForLwControl(LawyerData user, int taskID) {
		super(FrameAdapter.MainFrame, PanelAdapter.ShowRewardDataInfoForLwView);
		
		this.user=user; this.taskID=taskID;
		
		IntShowRewardDataInfoForLwView view = (IntShowRewardDataInfoForLwView) this.getPanel(); 
		view.setUser(this.user);
		view.setTaskId(this.taskID);
		view.setRewardDataList(this.rewardDataList);
	}

	@Override 
	public void processEvent(ActionEvent e) {
		try {EActionCommands.valueOf(e.getActionCommand());}
		catch(IllegalArgumentException ee) {this.startNewService(new WriteSueReportControl(this.user, this.taskID)); return;}
		
		switch (EActionCommands.valueOf(e.getActionCommand())) {
		case writeSueReport :this.startNewService(new WriteSueReportControl(this.user, this.taskID)); break;
		}
	}
}
