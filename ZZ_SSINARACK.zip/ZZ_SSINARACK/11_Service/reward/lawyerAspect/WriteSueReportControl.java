package reward.lawyerAspect;

import java.awt.Component;
import java.awt.event.ActionEvent;

import javax.swing.JOptionPane;

import panel.panelInterface.reward.IntWriteSueReportView;
import reward.RewardControl;
import specificModel.data.employeeData.rewardEmployeeData.LawyerData;
import specificModel.data.rewardData.LawsuitData;
import specificModel.data.rewardData.RewardData;
import view.frame.FrameAdapter;
import view.panel.PanelAdapter;

public class WriteSueReportControl extends RewardControl {
	
	// Static
	public enum EActionCommands {writeSueReport, SaveLawsuitData}
		
	// Component
	private IntWriteSueReportView view;

	// Association
	private LawyerData user;
	private int taskID;

	public WriteSueReportControl(LawyerData user, int taskID) {
		super(FrameAdapter.MainFrame, PanelAdapter.WriteSueReportView);
		
		this.user=user;
		this.taskID=taskID;
		
		this.view = (IntWriteSueReportView) this.getPanel();
	}

	@Override
	public void processEvent(ActionEvent e) {
		switch (EActionCommands.valueOf(e.getActionCommand())) {
		case SaveLawsuitData : if(this.isNumRight()) {this.save(); this.user.deleteTask(this.taskID); this.startNewService(new LawsuitTaskSelectControl(user));
		}  return;
		default:
			break;
		}
	}
	
	private boolean isNumRight() {
		try {Double.parseDouble(this.view.getPayTTA());}
		catch(NumberFormatException exc) {JOptionPane.showMessageDialog((Component) this.view, "���� ������� ���ڷ� �Է��� �ּ���"); return false;}
		return true;
	}
	
	private void save() {
		RewardData rewardData = this.rewardDataList.search(this.user.getTaskList().search(this.taskID).getRewardDataID());
		LawsuitData data = new LawsuitData();
		data.setPay(Integer.parseInt(this.view.getPayTTA()));
		rewardData.setLawsuitData(data);
		
		JOptionPane.showMessageDialog((Component) this.view, "����� ������ �Ϸ�Ǿ����ϴ�.");
	}

	

}
