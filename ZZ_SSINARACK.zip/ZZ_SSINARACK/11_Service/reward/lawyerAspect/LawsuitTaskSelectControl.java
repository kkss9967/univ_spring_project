package reward.lawyerAspect;

import java.awt.event.ActionEvent;

import panel.panelInterface.reward.IntLawsuitTaskSelectView;
import reward.RewardControl;
import specificModel.data.employeeData.rewardEmployeeData.LawyerData;
import view.frame.FrameAdapter;
import view.panel.PanelAdapter;

public class LawsuitTaskSelectControl extends RewardControl {

	// Association
	private LawyerData user;

	// Constructor
	public LawsuitTaskSelectControl(LawyerData user) {
		super(FrameAdapter.MainFrame, PanelAdapter.LawsuitTaskSelectView);
		
		this.user = user;
		
		IntLawsuitTaskSelectView view = (IntLawsuitTaskSelectView) this.getPanel();
		view.setUser(this.user);
		view.setRewardDataList(this.rewardDataList);
	}

	@Override
	public void processEvent(ActionEvent e) {
		if(!e.getActionCommand().equals("")) {
			this.startNewService(new ShowRewardDataInfoForLwControl(this.user, Integer.parseInt(e.getActionCommand())));
		}
	}
}
