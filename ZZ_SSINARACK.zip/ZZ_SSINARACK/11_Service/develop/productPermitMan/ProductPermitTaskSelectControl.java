package develop.productPermitMan;

import java.awt.event.ActionEvent;

import develop.DevelopSystem;
import panel.panelInterface.develop.IntPermitTaskSelectView;
import specificModel.data.employeeData.developEmployeeData.ProductPermitManData;
import view.frame.FrameAdapter;
import view.panel.PanelAdapter;

public class ProductPermitTaskSelectControl extends DevelopSystem {

	// Attribute
	private ProductPermitManData loginPPM;

	// Component
	private IntPermitTaskSelectView view;

	// Constructor
	public ProductPermitTaskSelectControl(ProductPermitManData user) {
		super(FrameAdapter.MainFrame, PanelAdapter.PermitTaskSelectView);
		
		this.loginPPM=user;
		
		this.view = (IntPermitTaskSelectView) this.getPanel();
		this.view.setInsurancePermitTask(this.loginPPM);
		this.view.setAbsInsuranceDataList(this.insuranceList);
	}

	@Override
	public void processEvent(ActionEvent e) {
		this.startNewService(new ShowInsuranceForProductPermitControl(this.loginPPM.getTaskList(), Integer.parseInt(e.getActionCommand())));
	}
}
