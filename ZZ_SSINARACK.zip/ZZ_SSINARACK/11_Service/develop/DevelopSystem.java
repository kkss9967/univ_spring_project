package develop;

import model.TableAdapter;
import model.table.Table_LV0;
import service.Service_LV2;
import specificModel.data.employeeData.developEmployeeData.DeveloperData;
import specificModel.data.employeeData.developEmployeeData.InsuranceRatePermitManData;
import specificModel.data.employeeData.developEmployeeData.ProductPermitManData;
import specificModel.data.insuranceData.AbsInsuranceData;
import view.frame.FrameAdapter;
import view.panel.PanelAdapter;

@SuppressWarnings("unchecked")
public abstract class DevelopSystem extends Service_LV2 {

	// Associate
	protected Table_LV0<DeveloperData> developerList = (Table_LV0<DeveloperData>) TableAdapter.ETableAdapter.developerDataList.getTable();
	protected Table_LV0<InsuranceRatePermitManData> insuranceRatePermitManList = (Table_LV0<InsuranceRatePermitManData>) TableAdapter.ETableAdapter.insuranceRatePermitManDataList.getTable();
	protected Table_LV0<ProductPermitManData> productPermitManList= (Table_LV0<ProductPermitManData>) TableAdapter.ETableAdapter.productPermitManDataList.getTable();
	protected Table_LV0<AbsInsuranceData> insuranceList = (Table_LV0<AbsInsuranceData>) TableAdapter.ETableAdapter.insuranceDataList.getTable();
	
	public DevelopSystem(FrameAdapter frameAdapter, PanelAdapter panelAdapter) {super(frameAdapter, panelAdapter);}
}
