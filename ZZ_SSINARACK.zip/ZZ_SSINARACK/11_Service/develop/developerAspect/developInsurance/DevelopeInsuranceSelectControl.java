package develop.developerAspect.developInsurance;

import java.awt.event.ActionEvent;

import develop.DevelopSystem;
import develop.developerAspect.showInsurance.SelecInsuranceToWatchControl;
import view.frame.FrameAdapter;
import view.panel.PanelAdapter;


public class DevelopeInsuranceSelectControl extends DevelopSystem {
	
	public enum EActionCommands {CarInsurance, DiseaseInsurance, FireInsurance, InsuranceDesign, WatchInsuranceData}

	public DevelopeInsuranceSelectControl() {
		super(FrameAdapter.MainFrame, PanelAdapter.DevelopInsuranceSelectView);
	}
	
	@Override
	public void processEvent(ActionEvent e) {
		switch (EActionCommands.valueOf(e.getActionCommand())) {
		case CarInsurance :  this.startNewService(new DevelopCarInsuranceControl()); break;
		case DiseaseInsurance :  this.startNewService(new DevelopDiseaseInsuranceControl()); break;
		case FireInsurance :  this.startNewService(new DevelopFireInsuranceControl()); break;
		case InsuranceDesign :  this.startNewService(new DevelopeInsuranceSelectControl()); break;
		case WatchInsuranceData :  this.startNewService(new SelecInsuranceToWatchControl()); break;
		}
	}
}
