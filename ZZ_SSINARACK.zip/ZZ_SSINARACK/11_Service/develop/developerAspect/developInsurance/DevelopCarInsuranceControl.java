package develop.developerAspect.developInsurance;

import java.awt.Component;
import java.awt.event.ActionEvent;

import javax.swing.JOptionPane;

import develop.DevelopSystem;
import develop.developerAspect.showInsurance.SelecInsuranceToWatchControl;
import panel.panelInterface.develop.IntDevelopInsuranceView;
import specificModel.data.employeeData.developEmployeeData.InsuranceRatePermitManData;
import specificModel.data.insuranceData.realInsuranceData.CarAccidentInsuranceData;
import specificModel.data.taskData.developTask.InsurancePermitTask;
import view.frame.FrameAdapter;
import view.panel.PanelAdapter;

public class DevelopCarInsuranceControl extends DevelopSystem {
	// Static
	public enum EActionCommands {SaveInsuranceData, InsuranceDesign, WatchInsuranceData}

	// Component
	private IntDevelopInsuranceView view;
	
	public DevelopCarInsuranceControl() {
		super(FrameAdapter.MainFrame, PanelAdapter.DevelopInsuranceView);
		this.view = (IntDevelopInsuranceView) this.getPanel();
		this.view.setIsDisease(false);
	}
	
	@Override
	public void processEvent(ActionEvent e) {
		switch (EActionCommands.valueOf(e.getActionCommand())) {
		case SaveInsuranceData : if(this.isLossRateNum()) {this.save(); this.startPreviousService();} break;
		case InsuranceDesign : this.startNewService(new DevelopeInsuranceSelectControl()); break;
		case WatchInsuranceData : this.startNewService(new SelecInsuranceToWatchControl()); break;
		}
	}
	private boolean isLossRateNum() {
		try {Double.parseDouble(this.view.getLossPercent());}
		catch(NumberFormatException exc) {JOptionPane.showMessageDialog((Component) this.view, "�������� ���ڷ� �Է��� �ּ���"); return false;}
		return true;
	}
	private void save() {
		CarAccidentInsuranceData data = new CarAccidentInsuranceData();
		data.setName(this.view.getName());
		data.setContent(this.view.getContent());
		data.setInsuranceRateInfo(this.view.getInsuranceRateInfo());
		data.setLossPercent(Double.parseDouble(this.view.getLossPercent()));
		this.insuranceList.add(data);
		for(InsuranceRatePermitManData employee : this.insuranceRatePermitManList.getList()) {
			if(employee.isWorkable()) {employee.addTask(new InsurancePermitTask(data.getID())); break;}
		}
	}
}
