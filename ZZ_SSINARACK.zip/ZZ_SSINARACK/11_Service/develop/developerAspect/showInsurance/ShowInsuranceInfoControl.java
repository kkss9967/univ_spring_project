package develop.developerAspect.showInsurance;

import java.awt.event.ActionEvent;

import develop.DevelopSystem;
import develop.developerAspect.developInsurance.DevelopeInsuranceSelectControl;
import panel.panelInterface.develop.IntShowInsuranceInfoView;
import view.frame.FrameAdapter;
import view.panel.PanelAdapter;

public class ShowInsuranceInfoControl extends DevelopSystem {
	// Static
	public enum EActionCommands {InsuranceDesign, WatchInsuranceData}

	// Attribute
	private int insuranceID;

	// Component
	private IntShowInsuranceInfoView view;

	// Constructor
	public ShowInsuranceInfoControl(int insuranceID) {
		super(FrameAdapter.MainFrame, PanelAdapter.ShowInsuranceInfoView);
		
		this.insuranceID=insuranceID;
		
		this.view = (IntShowInsuranceInfoView) this.getPanel();
		this.view.setAbsInsuranceData(this.insuranceList.search(this.insuranceID));
	}

	@Override 
	public void processEvent(ActionEvent e) {
		switch (EActionCommands.valueOf(e.getActionCommand())) {
		case InsuranceDesign : this.startNewService(new DevelopeInsuranceSelectControl()); break;
		case WatchInsuranceData : this.startNewService(new SelecInsuranceToWatchControl()); break;
		}
	}
}
