package develop.developerAspect.showInsurance;

import java.awt.event.ActionEvent;

import develop.DevelopSystem;
import develop.developerAspect.developInsurance.DevelopeInsuranceSelectControl;
import panel.panelInterface.develop.IntSelectInsuranceToWatchView;
import view.frame.FrameAdapter;
import view.panel.PanelAdapter;

public class SelecInsuranceToWatchControl extends DevelopSystem {
	// Static
	public enum EActionCommands {InsuranceDesign, WatchInsuranceData}

	// Component
	private IntSelectInsuranceToWatchView view;

	public SelecInsuranceToWatchControl() {
		super(FrameAdapter.MainFrame, PanelAdapter.SelectInsuranceToWatchView);
		this.view = (IntSelectInsuranceToWatchView) this.getPanel();
		this.view.setAbsInsuranceDataList(this.insuranceList);
	}
	
	@Override
	public void processEvent(ActionEvent e) {
		try {EActionCommands.valueOf(e.getActionCommand());}
		catch(IllegalArgumentException ee) {this.startNewService(new ShowInsuranceInfoControl(Integer.parseInt(e.getActionCommand()))); return;}
		
		switch (EActionCommands.valueOf(e.getActionCommand())) {
		case InsuranceDesign : this.startNewService(new DevelopeInsuranceSelectControl()); break; 
		case WatchInsuranceData : this.startNewService(new SelecInsuranceToWatchControl()); break;
		}
	}
}
