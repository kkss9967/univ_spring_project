package develop.insuranceRatePermitMan;

import java.awt.event.ActionEvent;

import develop.DevelopSystem;
import panel.panelInterface.develop.IntPermitTaskSelectView;
import specificModel.data.employeeData.developEmployeeData.InsuranceRatePermitManData;
import view.frame.FrameAdapter;
import view.panel.PanelAdapter;

public class InsuranceRatePermitTaskSelectControl extends DevelopSystem {

	// Attribute
	private InsuranceRatePermitManData loginIRPM;

	// Component
	private IntPermitTaskSelectView view;

	// Constructor
	public InsuranceRatePermitTaskSelectControl(InsuranceRatePermitManData loginIRPM) {
		super(FrameAdapter.MainFrame, PanelAdapter.PermitTaskSelectView);
		
		this.loginIRPM=loginIRPM;
		
		this.view = (IntPermitTaskSelectView) this.getPanel();
		this.view.setInsurancePermitTask(this.loginIRPM);
		this.view.setAbsInsuranceDataList(this.insuranceList);
	}

	
	@Override
	public void processEvent(ActionEvent e) {
		this.startNewService(new ShowInsuranceForInsuranceRatePermitControl(this.loginIRPM.getTaskList(), Integer.parseInt(e.getActionCommand())));
	}
}
