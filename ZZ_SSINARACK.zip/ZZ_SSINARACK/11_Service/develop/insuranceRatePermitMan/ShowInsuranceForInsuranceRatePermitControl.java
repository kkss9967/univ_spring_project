package develop.insuranceRatePermitMan;

import java.awt.event.ActionEvent;

import develop.DevelopSystem;
import model.table.Table_LV1;
import panel.panelInterface.develop.IntShowInsuranceForJudgeView;
import specificModel.data.employeeData.developEmployeeData.ProductPermitManData;
import specificModel.data.insuranceData.AbsInsuranceData;
import specificModel.data.taskData.developTask.InsurancePermitTask;
import view.frame.FrameAdapter;
import view.panel.PanelAdapter;

public class ShowInsuranceForInsuranceRatePermitControl extends DevelopSystem {
	
	// Static
	public enum EActionCommands {Permit, Ban}

	// Association
	private Table_LV1<InsurancePermitTask> tasks;
	private int taskIndex, targetInsuranceID;
	private AbsInsuranceData insuranceData;

	// Component
	private IntShowInsuranceForJudgeView view;

	// Constructor
	public ShowInsuranceForInsuranceRatePermitControl(Table_LV1<InsurancePermitTask> tasks, int taskIndex) {
		super(FrameAdapter.MainFrame, PanelAdapter.ShowInsuranceForJudgeView);
		this.tasks=tasks; 
		this.taskIndex=taskIndex;
		
		this.targetInsuranceID = this.tasks.search(this.taskIndex).getTargetInsuranceID();
		this.insuranceData = this.insuranceList.search(this.targetInsuranceID);

		this.view = (IntShowInsuranceForJudgeView) this.getPanel();
		this.view.setInsuranceData(this.insuranceData);
	}

	@Override
	public void processEvent(ActionEvent e) {
		switch (EActionCommands.valueOf(e.getActionCommand())) {
		case Permit : this.insuranceData.permitInsuranceRate(); this.orderProductPermit(); break;
		case Ban : break;
		}
		this.tasks.delete(this.taskIndex);
		this.startPreviousService();
	}
	
	private void orderProductPermit() {
		for(ProductPermitManData employee : this.productPermitManList.getList()) {
			if(employee.isWorkable()) {employee.addTask(new InsurancePermitTask(this.targetInsuranceID)); break;}
		}
	}
}
