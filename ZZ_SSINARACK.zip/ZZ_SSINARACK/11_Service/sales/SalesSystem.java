package sales;

import model.TableAdapter;
import model.table.Table_LV0;
import service.Service_LV2;
import specificModel.data.SalesTrainingPlanData.SalesTrainingPlanData;
import specificModel.data.activityPlanData.ActivityPlanData;
import specificModel.data.customerData.CustomerData;
import specificModel.data.employeeData.salesEmployeeData.SalesManData;
import specificModel.data.employeeData.salesEmployeeData.SalesManagerData;
import specificModel.data.insuranceData.AbsInsuranceData;
import view.frame.FrameAdapter;
import view.panel.PanelAdapter;

@SuppressWarnings("unchecked")
public abstract class SalesSystem extends Service_LV2 {
	
	// Associate - person
	protected Table_LV0<SalesManData> salesManList = (Table_LV0<SalesManData>) TableAdapter.ETableAdapter.salesManDataList.getTable();
	protected Table_LV0<SalesManagerData> salesManagerList = (Table_LV0<SalesManagerData>) TableAdapter.ETableAdapter.salesManagerDataList.getTable();
	protected Table_LV0<ActivityPlanData> activityPlanList = (Table_LV0<ActivityPlanData>) TableAdapter.ETableAdapter.activityPlanDataList.getTable();
	protected Table_LV0<SalesTrainingPlanData> salesTrainigPlanList= (Table_LV0<SalesTrainingPlanData>) TableAdapter.ETableAdapter.salesTrainigPlanDataList.getTable();
	protected Table_LV0<CustomerData> customerDataList= (Table_LV0<CustomerData>) TableAdapter.ETableAdapter.customerDataList.getTable();
	protected Table_LV0<AbsInsuranceData> insuranceDataList= (Table_LV0<AbsInsuranceData>) TableAdapter.ETableAdapter.insuranceDataList.getTable();

	public SalesSystem(FrameAdapter frameAdapter, PanelAdapter panelAdapter) {
		super(frameAdapter, panelAdapter);
	}
}
