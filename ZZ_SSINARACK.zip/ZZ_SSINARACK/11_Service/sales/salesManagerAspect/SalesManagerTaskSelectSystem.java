package sales.salesManagerAspect;

import java.awt.event.ActionEvent;

import sales.SalesSystem;
import view.frame.FrameAdapter;
import view.panel.PanelAdapter;

public class SalesManagerTaskSelectSystem extends SalesSystem {

	// Static
	public enum EActionCommands {SaveActivityPlan, SaveSalesTrainingPlan}
		
	public SalesManagerTaskSelectSystem() {
		super(FrameAdapter.MainFrame, PanelAdapter.SalesManagerTaskSelectView);
	}
	
	@Override
	public void processEvent(ActionEvent e) {
		switch (EActionCommands.valueOf(e.getActionCommand())) {
		case SaveActivityPlan : this.startNewService(new SaveActivityPlanSystem()); break;
		case SaveSalesTrainingPlan : this.startNewService(new SaveSalesTrainingPlanSystem()); break;
		}
	}
}
