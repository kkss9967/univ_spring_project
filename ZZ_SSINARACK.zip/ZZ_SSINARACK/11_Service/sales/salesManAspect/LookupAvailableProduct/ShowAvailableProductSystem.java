package sales.salesManAspect.LookupAvailableProduct;

import java.awt.event.ActionEvent;

import panel.panelInterface.sales.SalesMan.LookupAvailableProduct.IntShowAvailableProductView;
import sales.SalesSystem;
import sales.salesManAspect.SigninCustomer.SinginCustomerSystem;
import sales.salesManAspect.WatchActivityPlan.WatchActivityPlanSystem;
import sales.salesManAspect.WatchSalesTrainingPlan.WatchSalesTrainingPlanSystem;
import specificModel.data.customerData.CustomerData;
import view.frame.FrameAdapter;
import view.panel.PanelAdapter;

public class ShowAvailableProductSystem extends SalesSystem {
	
	// Static
	public enum EActionCommands {SigninCustomer,LookupAvailableProduct,WatchActivityPlan, WatchSalesTrainingPlan}
		
	// Association
	private CustomerData customerData;
	
	// Component
	private IntShowAvailableProductView view;
	
	// Constructor
	public ShowAvailableProductSystem(CustomerData customerData) {
		super(FrameAdapter.MainFrame, PanelAdapter.ShowAvailableProductView);
		
		this.customerData = customerData;
		
		this.view = (IntShowAvailableProductView) this.getPanel();
		this.view.setInsuranceDataList(this.insuranceDataList);
		this.view.setCustomerData(this.customerData);
	}
	
	@Override
	public void processEvent(ActionEvent e) {
		if(Character.isDigit(e.getActionCommand().charAt(0))) {
			this.startNewService(new ShowInsuranceInfoToCustomerSystem(Integer.parseInt(e.getActionCommand()), this.customerData));
			return;
		}
		switch (EActionCommands.valueOf(e.getActionCommand())) {
		case SigninCustomer : this.startNewService(new SinginCustomerSystem()); break;
		case LookupAvailableProduct : this.startNewService(new SearchCustomerSystem()); break;
		case WatchActivityPlan: this.startNewService(new WatchActivityPlanSystem()); break;
		case WatchSalesTrainingPlan: this.startNewService(new WatchSalesTrainingPlanSystem()); break;
		}
	}
}
