package sales.salesManAspect.LookupAvailableProduct;

import java.awt.Component;
import java.awt.event.ActionEvent;

import javax.swing.JOptionPane;

import panel.panelInterface.sales.SalesMan.LookupAvailableProduct.IntShowInsuranceInfoToCustomerView;
import sales.SalesSystem;
import sales.salesManAspect.SigninCustomer.SinginCustomerSystem;
import sales.salesManAspect.WatchActivityPlan.WatchActivityPlanSystem;
import sales.salesManAspect.WatchSalesTrainingPlan.WatchSalesTrainingPlanSystem;
import specificModel.data.customerData.CustomerData;
import view.frame.FrameAdapter;
import view.panel.PanelAdapter;

public class ShowInsuranceInfoToCustomerSystem extends SalesSystem {

	// Static
	public enum EActionCommands {SigninProduct,SigninCustomer,LookupAvailableProduct,WatchActivityPlan, WatchSalesTrainingPlan}

	// Association
	private int insuranceID;
	private CustomerData customerData;
	
	// Component
	private IntShowInsuranceInfoToCustomerView view;
	
	// Constructor
	public ShowInsuranceInfoToCustomerSystem(int insuranceID, CustomerData customerData) {
		super(FrameAdapter.MainFrame, PanelAdapter.ShowInsuranceInfoToCustomerView);
		
		this.insuranceID=insuranceID;this.customerData = customerData;
		
		this.view = (IntShowInsuranceInfoToCustomerView) this.getPanel();
		this.view.setInsuranceDataList(this.insuranceDataList);
		this.view.setInsuranceID(this.insuranceID);
		this.view.setCustomerData(this.customerData);
	}

	@Override
	public void processEvent(ActionEvent e) {
		switch (EActionCommands.valueOf(e.getActionCommand())) {
		case SigninCustomer : this.startNewService(new SinginCustomerSystem()); break;
		case LookupAvailableProduct : this.startNewService(new SearchCustomerSystem()); break;
		case WatchActivityPlan: this.startNewService(new WatchActivityPlanSystem()); break;
		case WatchSalesTrainingPlan: this.startNewService(new WatchSalesTrainingPlanSystem()); break;
		case SigninProduct:
			int result = JOptionPane.showConfirmDialog((Component) this.view, "���谡���� �����Ͻðڽ��ϱ�?", "SignInProduct", JOptionPane.YES_NO_OPTION);
			if (result == 0) { // yes
				JOptionPane.showMessageDialog((Component) this.view, "���谡���� �Ϸ�Ǿ����ϴ�.", "SignInProduct", JOptionPane.INFORMATION_MESSAGE);
				this.insuranceDataList.search(this.insuranceID).addCustomerID(this.customerData.getID());
				this.startNewService(new ShowAvailableProductSystem(this.customerData));
			}
			break;
		}
	}
}
