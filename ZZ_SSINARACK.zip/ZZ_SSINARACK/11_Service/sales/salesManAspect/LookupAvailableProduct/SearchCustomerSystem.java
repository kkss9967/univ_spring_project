package sales.salesManAspect.LookupAvailableProduct;

import java.awt.event.ActionEvent;

import model.table.Table_LV0;
import model.table.Table_LV1;
import panel.panelInterface.sales.SalesMan.LookupAvailableProduct.IntSearchCustomerView;
import sales.SalesSystem;
import sales.salesManAspect.SigninCustomer.SinginCustomerSystem;
import sales.salesManAspect.WatchActivityPlan.WatchActivityPlanSystem;
import sales.salesManAspect.WatchSalesTrainingPlan.WatchSalesTrainingPlanSystem;
import specificModel.data.customerData.CustomerData;
import view.frame.FrameAdapter;
import view.panel.PanelAdapter;

public class SearchCustomerSystem extends SalesSystem {
	
	// Static
	public enum EActionCommands {SigninCustomer,LookupAvailableProduct,WatchActivityPlan, WatchSalesTrainingPlan,search}
		
	// Component
	private IntSearchCustomerView view;

	public SearchCustomerSystem() {
		super(FrameAdapter.MainFrame, PanelAdapter.SearchCustomerView);
		this.view = (IntSearchCustomerView) this.getPanel();
		this.view.setCustomerDataList(this.customerDataList);
	}
	
	@Override
	public void processEvent(ActionEvent e) {
		switch (EActionCommands.valueOf(e.getActionCommand())) {
		case SigninCustomer : this.startNewService(new SinginCustomerSystem()); break;
		case LookupAvailableProduct : this.startNewService(new SearchCustomerSystem()); break;
		case WatchActivityPlan: this.startNewService(new WatchActivityPlanSystem()); break;
		case WatchSalesTrainingPlan: this.startNewService(new WatchSalesTrainingPlanSystem()); break;
		case search : this.startNewService(new ShowCustomerInfoSystem(search(),this.view.getCustomerNameTTA())); break;
		}
	}
	
	public Table_LV0<CustomerData> search() {
		Table_LV0<CustomerData> searchedCustomerList=new Table_LV1<CustomerData>();
		for(CustomerData customerData : this.customerDataList.getList()) {
			if(customerData.getName().equals(this.view.getCustomerNameTTA().getContent())) {
				searchedCustomerList.add(customerData);
			}
		}
		return searchedCustomerList;
	}
}
