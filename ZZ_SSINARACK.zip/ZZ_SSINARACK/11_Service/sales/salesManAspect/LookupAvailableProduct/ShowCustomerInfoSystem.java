package sales.salesManAspect.LookupAvailableProduct;

import java.awt.event.ActionEvent;

import component.textArea.InputTextArea;
import model.table.Table_LV0;
import panel.panelInterface.sales.SalesMan.LookupAvailableProduct.IntShowCustomerInfoView;
import sales.SalesSystem;
import sales.salesManAspect.SigninCustomer.SinginCustomerSystem;
import sales.salesManAspect.WatchActivityPlan.WatchActivityPlanSystem;
import sales.salesManAspect.WatchSalesTrainingPlan.WatchSalesTrainingPlanSystem;
import specificModel.data.customerData.CustomerData;
import view.frame.FrameAdapter;
import view.panel.PanelAdapter;

public class ShowCustomerInfoSystem extends SalesSystem {

	// Static
	public enum EActionCommands {SigninCustomer,LookupAvailableProduct,WatchActivityPlan, WatchSalesTrainingPlan}
	// Component
	private IntShowCustomerInfoView view;
	// Association
	private Table_LV0<CustomerData> searchedCustomerList;
	private InputTextArea searchedNameTTA;

	// Constructor
	public ShowCustomerInfoSystem(Table_LV0<CustomerData> customerList, InputTextArea customerNameTTA) {
		super(FrameAdapter.MainFrame, PanelAdapter.ShowCustomerInfoView);
		
		this.searchedCustomerList = customerList;
		this.searchedNameTTA = customerNameTTA;
		
		this.view = (IntShowCustomerInfoView) this.getPanel();
		this.view.setSearchedCustomerList(this.searchedCustomerList);
		this.view.setSearchedNameTTA(this.searchedNameTTA);
	}

	@Override
	public void processEvent(ActionEvent e) {
		if (Character.isDigit(e.getActionCommand().charAt(0))) {
			for (CustomerData customerData : this.customerDataList.getList()) {
				if (Integer.toString(customerData.getID()).equals(e.getActionCommand())) {
					this.startNewService(new ShowAvailableProductSystem(customerData));
					return;
				}
			}
		}
		switch (EActionCommands.valueOf(e.getActionCommand())) {
			case SigninCustomer : this.startNewService(new SinginCustomerSystem()); break;
			case LookupAvailableProduct : this.startNewService(new SearchCustomerSystem()); break;
			case WatchActivityPlan: this.startNewService(new WatchActivityPlanSystem()); break;
			case WatchSalesTrainingPlan: this.startNewService(new WatchSalesTrainingPlanSystem()); break;
		}
	}
}
