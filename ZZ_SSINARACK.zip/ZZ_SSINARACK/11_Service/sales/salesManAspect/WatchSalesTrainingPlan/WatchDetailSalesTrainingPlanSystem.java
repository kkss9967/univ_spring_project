package sales.salesManAspect.WatchSalesTrainingPlan;

import java.awt.event.ActionEvent;

import panel.panelInterface.sales.SalesMan.WatchSalesTrainingPlan.IntWatchDetailSalesTrainingPlanView;
import sales.SalesSystem;
import sales.salesManAspect.LookupAvailableProduct.SearchCustomerSystem;
import sales.salesManAspect.SigninCustomer.SinginCustomerSystem;
import sales.salesManAspect.WatchActivityPlan.WatchActivityPlanSystem;
import view.frame.FrameAdapter;
import view.panel.PanelAdapter;

public class WatchDetailSalesTrainingPlanSystem extends SalesSystem {
	
	// Static
	public enum EActionCommands {SigninCustomer,LookupAvailableProduct,WatchActivityPlan, WatchSalesTrainingPlan}
			
	// Association
	private int salesTrainingPlanID;
	
	// Component
	private IntWatchDetailSalesTrainingPlanView view;
		
	// Constructor
	public WatchDetailSalesTrainingPlanSystem(int ID) {
		super(FrameAdapter.MainFrame, PanelAdapter.WatchDetailSalesTrainingPlanView);
		
		this.salesTrainingPlanID = ID;
		
		this.view = (IntWatchDetailSalesTrainingPlanView) this.getPanel();
		this.view.setSalesTrainingPlanID(this.salesTrainingPlanID);
		this.view.setSalesTrainigPlanList(this.salesTrainigPlanList);
	}
	
	@Override
	public void processEvent(ActionEvent e) {
		switch (EActionCommands.valueOf(e.getActionCommand())) {
		case SigninCustomer : this.startNewService(new SinginCustomerSystem()); break;
		case LookupAvailableProduct : this.startNewService(new SearchCustomerSystem()); break;
		case WatchActivityPlan: this.startNewService(new WatchActivityPlanSystem()); break;
		case WatchSalesTrainingPlan: this.startNewService(new WatchSalesTrainingPlanSystem()); break;
		}
	}
}
