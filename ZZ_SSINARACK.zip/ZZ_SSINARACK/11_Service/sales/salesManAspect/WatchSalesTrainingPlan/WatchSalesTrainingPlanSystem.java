package sales.salesManAspect.WatchSalesTrainingPlan;

import java.awt.event.ActionEvent;

import panel.panelInterface.sales.SalesMan.WatchSalesTrainingPlan.IntWatchSalesTrainingPlanView;
import sales.SalesSystem;
import sales.salesManAspect.LookupAvailableProduct.SearchCustomerSystem;
import sales.salesManAspect.SigninCustomer.SinginCustomerSystem;
import sales.salesManAspect.WatchActivityPlan.WatchActivityPlanSystem;
import view.frame.FrameAdapter;
import view.panel.PanelAdapter;

public class WatchSalesTrainingPlanSystem extends SalesSystem {
	
	// Static
	public enum EActionCommands {SigninCustomer,LookupAvailableProduct,WatchActivityPlan, WatchSalesTrainingPlan}

	// Component
	private IntWatchSalesTrainingPlanView view;

	public WatchSalesTrainingPlanSystem() {
		super(FrameAdapter.MainFrame, PanelAdapter.WatchSalesTrainingPlanView);
		this.view = (IntWatchSalesTrainingPlanView) this.getPanel();
		this.view.setSalesTrainingPlanList(this.salesTrainigPlanList);
	}
	
	@Override
	public void processEvent(ActionEvent e) {
		if(Character.isDigit(e.getActionCommand().charAt(0))) {
			this.startNewService(new WatchDetailSalesTrainingPlanSystem(Integer.parseInt(e.getActionCommand())));
			return;
		}
		switch (EActionCommands.valueOf(e.getActionCommand())) {
		case SigninCustomer : this.startNewService(new SinginCustomerSystem()); break;
		case LookupAvailableProduct : this.startNewService(new SearchCustomerSystem()); break;
		case WatchActivityPlan: this.startNewService(new WatchActivityPlanSystem()); break;
		case WatchSalesTrainingPlan: this.startNewService(new WatchSalesTrainingPlanSystem()); break;
		}
	}
}
