package sales.salesManAspect.WatchActivityPlan;

import java.awt.event.ActionEvent;

import panel.panelInterface.sales.SalesMan.WatchActivityPlan.IntWatchActivityPlanView;
import sales.SalesSystem;
import sales.salesManAspect.LookupAvailableProduct.SearchCustomerSystem;
import sales.salesManAspect.SigninCustomer.SinginCustomerSystem;
import sales.salesManAspect.WatchSalesTrainingPlan.WatchSalesTrainingPlanSystem;
import view.frame.FrameAdapter;
import view.panel.PanelAdapter;

public class WatchActivityPlanSystem extends SalesSystem {
	
	// Static
	public enum EActionCommands {SigninCustomer,LookupAvailableProduct,WatchActivityPlan, WatchSalesTrainingPlan}
	
	// Components
	private IntWatchActivityPlanView view;
	
	public WatchActivityPlanSystem() {
		super(FrameAdapter.MainFrame, PanelAdapter.WatchActivityPlanView);
		this.view = (IntWatchActivityPlanView) this.getPanel();
		this.view.setActivityPlanList(this.activityPlanList);
	}

	@Override
	public void processEvent(ActionEvent e) {
		if(Character.isDigit(e.getActionCommand().charAt(0))) {
			this.startNewService(new WatchDetailActivityPlanSystem(Integer.parseInt(e.getActionCommand())));
			return;
		}
		switch (EActionCommands.valueOf(e.getActionCommand())) {
		case SigninCustomer : this.startNewService(new SinginCustomerSystem()); break;
		case LookupAvailableProduct : this.startNewService(new SearchCustomerSystem()); break;
		case WatchActivityPlan: this.startNewService(new WatchActivityPlanSystem()); break;
		case WatchSalesTrainingPlan: this.startNewService(new WatchSalesTrainingPlanSystem()); break;
		}
	}
}
