package sales.salesManAspect.WatchActivityPlan;

import java.awt.event.ActionEvent;

import panel.panelInterface.sales.SalesMan.WatchActivityPlan.IntWatchDetailActivityPlanView;
import sales.SalesSystem;
import sales.salesManAspect.LookupAvailableProduct.SearchCustomerSystem;
import sales.salesManAspect.SigninCustomer.SinginCustomerSystem;
import sales.salesManAspect.WatchSalesTrainingPlan.WatchSalesTrainingPlanSystem;
import view.frame.FrameAdapter;
import view.panel.PanelAdapter;

public class WatchDetailActivityPlanSystem extends SalesSystem {
	
	// Static
	public enum EActionCommands {SigninCustomer,LookupAvailableProduct,WatchActivityPlan, WatchSalesTrainingPlan}
		
	// Association
	private int activityPlanID;

	// Constructor
	public WatchDetailActivityPlanSystem(int ID) {
		super(FrameAdapter.MainFrame, PanelAdapter.WatchDetailActivityPlanView);
		
		this.activityPlanID = ID;
		
		this.view = (IntWatchDetailActivityPlanView) this.getPanel();
		this.view.setActivityPlanID(this.activityPlanID);
		this.view.setActivityPlanList(this.activityPlanList);
	}
	
	// Component
	private IntWatchDetailActivityPlanView view;
	
	// no use
	@Override
	public void processEvent(ActionEvent e) {
		switch (EActionCommands.valueOf(e.getActionCommand())) {
		case SigninCustomer : this.startNewService(new SinginCustomerSystem()); break;
		case LookupAvailableProduct : this.startNewService(new SearchCustomerSystem()); break;
		case WatchActivityPlan: this.startNewService(new WatchActivityPlanSystem()); break;
		case WatchSalesTrainingPlan: this.startNewService(new WatchSalesTrainingPlanSystem()); break;
		}
	}
}
