package sales.salesManAspect;

import java.awt.event.ActionEvent;

import sales.SalesSystem;
import sales.salesManAspect.LookupAvailableProduct.SearchCustomerSystem;
import sales.salesManAspect.SigninCustomer.SinginCustomerSystem;
import sales.salesManAspect.WatchActivityPlan.WatchActivityPlanSystem;
import sales.salesManAspect.WatchSalesTrainingPlan.WatchSalesTrainingPlanSystem;
import view.frame.FrameAdapter;
import view.panel.PanelAdapter;

public class SalesManTaskSelectSystem extends SalesSystem {

	// Static
	public enum EActionCommands {SigninCustomer,LookupAvailableProduct,WatchActivityPlan, WatchSalesTrainingPlan}
		
	public SalesManTaskSelectSystem() {
		super(FrameAdapter.MainFrame, PanelAdapter.SalesManTaskSelectView);
	}
	
	@Override
	public void processEvent(ActionEvent e) {
		switch (EActionCommands.valueOf(e.getActionCommand())) {
		case SigninCustomer : this.startNewService(new SinginCustomerSystem()); break;
		case LookupAvailableProduct : this.startNewService(new SearchCustomerSystem()); break;
		case WatchActivityPlan: this.startNewService(new WatchActivityPlanSystem()); break;
		case WatchSalesTrainingPlan: this.startNewService(new WatchSalesTrainingPlanSystem()); break;
		}
	}
}
