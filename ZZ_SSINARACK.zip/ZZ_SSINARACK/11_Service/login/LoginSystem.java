package login;

import model.TableAdapter;
import model.table.Table_LV0;
import service.Service_LV2;
import specificModel.data.customerData.CustomerData;
import specificModel.data.employeeData.developEmployeeData.DeveloperData;
import specificModel.data.employeeData.developEmployeeData.InsuranceRatePermitManData;
import specificModel.data.employeeData.developEmployeeData.ProductPermitManData;
import specificModel.data.employeeData.rewardEmployeeData.AccidentInvestigatorData;
import specificModel.data.employeeData.rewardEmployeeData.LawyerData;
import specificModel.data.employeeData.rewardEmployeeData.LossCheckManData;
import specificModel.data.employeeData.rewardEmployeeData.PayJudgerData;
import specificModel.data.employeeData.salesEmployeeData.SalesManData;
import specificModel.data.employeeData.salesEmployeeData.SalesManagerData;
import view.frame.FrameAdapter;
import view.panel.PanelAdapter;

@SuppressWarnings("unchecked")
public abstract class LoginSystem extends Service_LV2 {

	// Associate
	protected Table_LV0<DeveloperData> developerList= (Table_LV0<DeveloperData>) TableAdapter.ETableAdapter.developerDataList.getTable();
	protected Table_LV0<InsuranceRatePermitManData> insuranceRatePermitManList= (Table_LV0<InsuranceRatePermitManData>) TableAdapter.ETableAdapter.insuranceRatePermitManDataList.getTable();
	protected Table_LV0<ProductPermitManData> productPermitManList= (Table_LV0<ProductPermitManData>) TableAdapter.ETableAdapter.productPermitManDataList.getTable();
	protected Table_LV0<CustomerData> customerList= (Table_LV0<CustomerData>) TableAdapter.ETableAdapter.customerDataList.getTable();
	protected Table_LV0<SalesManData> salesManList= (Table_LV0<SalesManData>) TableAdapter.ETableAdapter.salesManDataList.getTable();
	protected Table_LV0<SalesManagerData> salesManagerList= (Table_LV0<SalesManagerData>) TableAdapter.ETableAdapter.salesManagerDataList.getTable();
	protected Table_LV0<AccidentInvestigatorData> accidentInvestigatorList= (Table_LV0<AccidentInvestigatorData>) TableAdapter.ETableAdapter.accidentInvestigatorDataList.getTable();
	protected Table_LV0<PayJudgerData> payJudgerList= (Table_LV0<PayJudgerData>) TableAdapter.ETableAdapter.payJudgerDataList.getTable();
	protected Table_LV0<LossCheckManData> lossCheckManList= (Table_LV0<LossCheckManData>) TableAdapter.ETableAdapter.lossCheckManDataList.getTable();
	protected Table_LV0<LawyerData> lawyerList= (Table_LV0<LawyerData>) TableAdapter.ETableAdapter.lawyerDataList.getTable();
	
	public LoginSystem(FrameAdapter frameAdapter, PanelAdapter panelAdapter) {
		super(frameAdapter, panelAdapter);
	}
}
