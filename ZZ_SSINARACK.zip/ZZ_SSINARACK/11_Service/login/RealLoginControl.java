package login;

import java.awt.event.ActionEvent;
import java.util.Vector;

import develop.developerAspect.DeveloperTaskSelectControl;
import develop.insuranceRatePermitMan.InsuranceRatePermitTaskSelectControl;
import develop.productPermitMan.ProductPermitTaskSelectControl;
import panel.panelInterface.login.IntLoginPanel;
import reward.customerAspect.CustomerTaskSelectControl;
import reward.investigatorAspect.InvestigatorTaskSelectControl;
import reward.lawyerAspect.LawsuitTaskSelectControl;
import reward.lossCheckManAspect.LossCheckTaskSelectControl;
import reward.payJudgerAspect.PayJudgerTaskSelectControl;
import sales.salesManAspect.SalesManTaskSelectSystem;
import sales.salesManagerAspect.SalesManagerTaskSelectSystem;
import specificModel.data.customerData.CustomerData;
import specificModel.data.employeeData.developEmployeeData.InsuranceRatePermitManData;
import specificModel.data.employeeData.developEmployeeData.ProductPermitManData;
import specificModel.data.employeeData.rewardEmployeeData.AccidentInvestigatorData;
import specificModel.data.employeeData.rewardEmployeeData.LawyerData;
import specificModel.data.employeeData.rewardEmployeeData.LossCheckManData;
import specificModel.data.employeeData.rewardEmployeeData.PayJudgerData;
import specificModel.data.systemUserData.SystemUserData;
import view.frame.FrameAdapter;
import view.panel.PanelAdapter;

public class RealLoginControl extends LoginSystem {

	// Component
	private IntLoginPanel view;
	
	public RealLoginControl() {
		super(FrameAdapter.MainFrame, PanelAdapter.LoginView);
		this.view = (IntLoginPanel) this.getPanel();
	}
	
	@Override
	public void processEvent(ActionEvent e) {
		// Develop Aspect
		SystemUserData<?> user;
		user = this.login(this.developerList.getList());
		if(user != null) {this.startNewService(new DeveloperTaskSelectControl()); return;}
		user = this.login(this.insuranceRatePermitManList.getList());
		if(user != null) {this.startNewService(new InsuranceRatePermitTaskSelectControl((InsuranceRatePermitManData) user)); return;}
		user = this.login(this.productPermitManList.getList());
		if(user != null) {this.startNewService(new ProductPermitTaskSelectControl((ProductPermitManData) user)); return;}
		
		// Sales Aspect
		user = this.login(this.salesManList.getList());
		if(user != null) {this.startNewService(new SalesManTaskSelectSystem()); return;}
		user = this.login(this.salesManagerList.getList());
		if(user != null) {this.startNewService(new SalesManagerTaskSelectSystem()); return;}
		
//		// Reward Aspect
		user = this.login(this.customerList.getList());
		if(user != null) {this.startNewService(new CustomerTaskSelectControl((CustomerData) user)); return;}
		user = this.login(this.accidentInvestigatorList.getList());
		if(user != null) {this.startNewService(new InvestigatorTaskSelectControl((AccidentInvestigatorData) user)); return;}
		user = this.login(this.payJudgerList.getList());
		if(user != null) {this.startNewService(new PayJudgerTaskSelectControl((PayJudgerData) user)); return;}
		user = this.login(this.lossCheckManList.getList());
		if(user != null) {this.startNewService(new LossCheckTaskSelectControl((LossCheckManData) user)); return;}
		user = this.login(this.lawyerList.getList());
		if(user != null) {this.startNewService(new LawsuitTaskSelectControl((LawyerData) user)); return;}
		
		// No User
		this.view.showLoginFailed();
	}
	private SystemUserData<?> login(Vector<? extends SystemUserData<?>> list) {
		String id = this.view.getId(), pw = this.view.getPw();
		for(SystemUserData<?> data : list) {if(data.getLoginID().equals(id) && data.getLoginPW().equals(pw)) {return data;}}
		return null;
	}
}
