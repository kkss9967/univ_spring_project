package db;

public interface DAO_LV0 {

	// Create Time Use
	public int insert(Object...values);
	
	// Any Time Use 
	public void delete();
//	public ResultSet select() {return this.select(this.tableName, this.pkName, this.id);}
	public void update (String columnName, Object value);
	
	// Getter & Setter
	public int getInt(String columnName);
	public String getString(String columnName);
	public double getDouble(String columnName);
	public boolean getBoolean(String columnName);
	
	public void setTableName(String tableName);
	public void setPKName(String pkName);
	public void setDefaultValues(Object[] defaultValues);
}
