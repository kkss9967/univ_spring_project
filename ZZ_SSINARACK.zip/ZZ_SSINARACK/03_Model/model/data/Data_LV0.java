package model.data;

public interface Data_LV0 {

}
