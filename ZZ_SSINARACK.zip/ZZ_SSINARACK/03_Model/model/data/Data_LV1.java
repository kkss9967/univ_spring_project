package model.data;

public class Data_LV1 implements Data_LV0 {

	// Attribute
	private int iD;
	
	// Getter & Setter
	public void setID(int iD) {this.iD=iD;}
	public int getID() {return this.iD;}
}
