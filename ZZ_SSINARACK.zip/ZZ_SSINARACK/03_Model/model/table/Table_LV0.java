package model.table;

import java.util.Vector;

import model.data.Data_LV1;

public interface Table_LV0<T extends Data_LV1> {
	
	// Any Time Use
	public void add(T data);
	public void delete(int iD);
	public T search(int iD);
	
	// Getter & Setter
	public Vector<T> getList();
	public int getID();
	public void setID(int id);
}
