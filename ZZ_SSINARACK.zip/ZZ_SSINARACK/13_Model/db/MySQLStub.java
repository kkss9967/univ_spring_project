package db;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import org.springframework.context.ApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import model.DBAttributeAdapter;

public class MySQLStub extends JdbcDaoSupport {
	
	// Attribute
	private JdbcTemplate jdbcTemplate;
	
	// Constructor
	public MySQLStub() {
		@SuppressWarnings("resource")
		ApplicationContext context = DBAttributeAdapter.getClassPathXmlApplicationContext();
//		ApplicationContext context = new ClassPathXmlApplicationContext("ZZ_SSINARACK/DBAttribute.xml");
		this.jdbcTemplate = context.getBean("jdbcTemplate", org.springframework.jdbc.core.JdbcTemplate.class);
	}

	// Any Time Use
	public int insert(String tableName, Object...values) {
		String instruction = "insert into "+tableName+ " values(";	
		for(Object value : values) {instruction += (this.objectToString(value)+", ");}
		instruction = instruction.substring(0, instruction.length() - 2) + ");"; // ������ ", "�� ����
		this.jdbcTemplate.execute(instruction);
		
	    String instruction2 = "select * from " + tableName + ";";
		return this.jdbcTemplate.query(instruction2, new MyRowMapper2()).size(); // ������ ID Ȯ�� ��
	}
	
	
	public MyResultSet select(String tableName, String pkName, int id) {
		String instruction = "select * from " + tableName + " where "+ pkName+" = "+id+";";
		return this.jdbcTemplate.query(instruction, new MyRowMapper()).get(0);
	}
	
	protected class MyRowMapper implements RowMapper<MyResultSet> {
		
		@Override
		public MyResultSet mapRow(ResultSet rs, int arg1) throws SQLException {
			MyResultSet now = new MyResultSet();
			Map<String, Object> map = new HashMap<>();
			try {
				for (int i = 0; i < rs.getMetaData().getColumnCount(); i++) {
					map.put(rs.getMetaData().getColumnLabel(i+1), rs.getObject(i+1));
				}
			} catch (SQLException e) {e.printStackTrace();}
			now.setMap(map);
			return now;
		}
	}
	public class MyResultSet {
		private Map<String, Object> values;
		public void setMap(Map<String, Object> values){this.values=values;}
		public Map<String, Object> getValues(){return this.values;}
		public Object getValueOf(String key){return this.values.get(key);}
	}
	
	public void update (String tableName, String pkName, int id, String name, Object value) {
		String instruction = "update " + tableName + " set " + name + " = " + this.objectToString(value) + " where "+pkName+" = " + id + ";";
		this.jdbcTemplate.execute(instruction);
	}
	public void delete(String tableName, String pkName, int id) {
		String instruction = "delete from " + tableName + " where "+ pkName+" = "+id+";";
		this.jdbcTemplate.execute(instruction);
	}
	public void clearTable(String tableName) {
		String instruction = "delete from " + tableName+";";
		this.jdbcTemplate.execute(instruction);
	}
	public String objectToString(Object value) {
		if(value instanceof Integer) {return (Integer.toString((Integer)value));}
		else if(value instanceof Double) {return (Double.toString((Double)value));}
		else if(value instanceof Boolean) {if((boolean) value) {return "TRUE";}else {return "FALSE";}}
		else if(value instanceof String) {return ("\""+value+"\" ");} // �������̶� "" �޾Ƴ���
		else {return null;}
	}
	public String getString(String tableName, String pkName, int id, String columName) {
		MyResultSet rs = this.select(tableName, pkName, id);
		return (String) rs.getValueOf(columName);
	}
	public int getInt(String tableName, String pkName, int id, String columName) {
		MyResultSet rs = this.select(tableName, pkName, id); 
		return (int) rs.getValueOf(columName);
	}
	public double getDouble(String tableName, String pkName, int id, String columName) {
		MyResultSet rs = this.select(tableName, pkName, id); 
		return Double.parseDouble(String.valueOf(rs.getValueOf(columName)));
	}
	public boolean getBoolean(String tableName, String pkName, int id, String columName) {
		MyResultSet rs = this.select(tableName, pkName, id); 
		return (boolean) rs.getValueOf(columName);
	}
	
	protected class MyRowMapper2 implements RowMapper<ResultSet> {
		@Override public ResultSet mapRow(ResultSet arg0, int arg1) throws SQLException {return arg0;}
	}
}
