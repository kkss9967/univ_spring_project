package db;

public class DAO extends MySQLStub implements DAO_LV0 {

	// Attribute
	protected String tableName, pkName;
	protected int id;
	
	// Create Time Use
	public int insert(Object...values) {return this.insert(this.tableName, values);}
	
	// Any Time Use 
	public void delete() {this.delete(this.tableName, this.pkName, this.id);}
//	public ResultSet select() {return this.select(this.tableName, this.pkName, this.id);}
	public void update (String columnName, Object value) {this.update(this.tableName, this.pkName, this.id, columnName, value);}
	
	// Getter
	public int getInt(String columnName) {return this.getInt(this.tableName, this.pkName, this.id, columnName);}
	public String getString(String columnName) {return this.getString(this.tableName, this.pkName, this.id, columnName);}
	public double getDouble(String columnName) {return this.getDouble(this.tableName, this.pkName, this.id, columnName);}
	public boolean getBoolean(String columnName) {return this.getBoolean(this.tableName, this.pkName, this.id, columnName);}

	@Override public void setTableName(String tableName) {this.tableName = tableName;}		
	@Override public void setPKName(String pkName) {this.pkName = pkName;}
	@Override public void setDefaultValues(Object[] defaultValues) {this.id = this.insert(defaultValues);}// Create DB Data
}
