package specificModel.enums;

public enum EDataListID {
	DeveloperDataListID,
	InsuranceRatePermitManDataListID,
	ProductPermitManDataListID,
	InsuranceDataListID,
	CustomerDataListID,
	AccidentInvestigatorDataListID,
	PayJudgerDataListID,
	LossCheckManDataListID,
	LawyerDataListID,
	RewardDataListID,
	SalesManDataListID,
	SalesManagerDataListID,
	ActivityPlanDataListID,
	SalesTrainigPlanDataListID,
}
