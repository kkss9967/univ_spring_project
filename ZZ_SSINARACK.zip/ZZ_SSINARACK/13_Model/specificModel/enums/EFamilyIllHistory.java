package specificModel.enums;

public enum EFamilyIllHistory {
	 Cancer, Diabetes,  Stroke, HeartDisease, HighBloodPressure
}
