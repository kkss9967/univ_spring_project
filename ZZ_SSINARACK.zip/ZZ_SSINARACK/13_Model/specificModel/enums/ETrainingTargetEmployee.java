package specificModel.enums;

public enum ETrainingTargetEmployee {
	salesMan, SalesManager
}
