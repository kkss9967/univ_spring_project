package specificModel.enums;

public enum EGender {
	male, female
}
