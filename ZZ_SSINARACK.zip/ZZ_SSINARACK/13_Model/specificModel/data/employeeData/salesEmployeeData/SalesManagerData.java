package specificModel.data.employeeData.salesEmployeeData;

import specificModel.data.employeeData.AbsEmployeeData;
import specificModel.data.taskData.AbsTask;

public class SalesManagerData extends AbsEmployeeData<AbsTask> {
}
