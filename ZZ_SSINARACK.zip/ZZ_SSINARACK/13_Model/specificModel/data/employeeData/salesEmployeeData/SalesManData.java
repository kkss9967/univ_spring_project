package specificModel.data.employeeData.salesEmployeeData;

import specificModel.data.employeeData.AbsEmployeeData;
import specificModel.data.taskData.AbsTask;

public class SalesManData extends AbsEmployeeData<AbsTask> {
}
