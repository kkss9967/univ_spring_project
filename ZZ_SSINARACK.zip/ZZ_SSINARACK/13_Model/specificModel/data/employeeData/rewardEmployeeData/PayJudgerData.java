package specificModel.data.employeeData.rewardEmployeeData;

import specificModel.data.employeeData.AbsEmployeeData;
import specificModel.data.taskData.rewardTask.PayJudgeTask;

public class PayJudgerData extends AbsEmployeeData<PayJudgeTask> {
}
