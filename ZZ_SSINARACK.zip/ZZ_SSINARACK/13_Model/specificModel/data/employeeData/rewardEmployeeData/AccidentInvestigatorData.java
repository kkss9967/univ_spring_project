package specificModel.data.employeeData.rewardEmployeeData;

import specificModel.data.employeeData.AbsEmployeeData;
import specificModel.data.taskData.rewardTask.AccidentInvestigationTask;

public class AccidentInvestigatorData extends AbsEmployeeData<AccidentInvestigationTask> {
	
	// Attributes
	public String chargeArea;

	public String getChargeArea() {return chargeArea;}
	public void setChargeArea(String chargeArea) {this.chargeArea = chargeArea;}
}
