package specificModel.data.employeeData.rewardEmployeeData;

import specificModel.data.employeeData.AbsEmployeeData;
import specificModel.data.taskData.rewardTask.LawSuitTask;

public class LawyerData extends AbsEmployeeData<LawSuitTask>{
}
