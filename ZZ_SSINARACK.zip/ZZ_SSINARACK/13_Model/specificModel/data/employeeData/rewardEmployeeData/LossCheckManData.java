package specificModel.data.employeeData.rewardEmployeeData;

import specificModel.data.employeeData.AbsEmployeeData;
import specificModel.data.taskData.rewardTask.LossCheckTask;

public class LossCheckManData extends AbsEmployeeData<LossCheckTask>{
}
