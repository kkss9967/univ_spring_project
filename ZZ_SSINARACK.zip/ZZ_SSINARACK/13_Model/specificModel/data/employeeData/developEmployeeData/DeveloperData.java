package specificModel.data.employeeData.developEmployeeData;

import specificModel.data.employeeData.AbsEmployeeData;
import specificModel.data.taskData.AbsTask;

public class DeveloperData extends AbsEmployeeData<AbsTask> {
}
