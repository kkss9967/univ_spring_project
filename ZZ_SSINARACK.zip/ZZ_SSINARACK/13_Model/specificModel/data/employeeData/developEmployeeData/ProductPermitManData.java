package specificModel.data.employeeData.developEmployeeData;

import specificModel.data.employeeData.AbsEmployeeData;
import specificModel.data.taskData.developTask.InsurancePermitTask;

public class ProductPermitManData extends AbsEmployeeData<InsurancePermitTask> {
}
