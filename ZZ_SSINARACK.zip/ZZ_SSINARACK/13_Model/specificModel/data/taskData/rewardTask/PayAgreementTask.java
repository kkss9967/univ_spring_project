package specificModel.data.taskData.rewardTask;

import specificModel.data.taskData.AbsTask;

public class PayAgreementTask extends AbsTask{
	
	// Attribute
	private int rewardDataID;
	
	// Constructor
	public PayAgreementTask(int rewardDataID) {this.rewardDataID=rewardDataID;}
	
	// Getter & Setter
	public int getRewardDataID() {return this.rewardDataID;}
}
