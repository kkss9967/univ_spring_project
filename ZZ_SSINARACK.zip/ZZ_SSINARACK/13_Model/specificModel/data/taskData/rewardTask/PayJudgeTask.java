package specificModel.data.taskData.rewardTask;

import specificModel.data.taskData.AbsTask;

public class PayJudgeTask extends AbsTask{
	
	// Attribute
	private int rewardDataID;	
	
	// Constructor
	public PayJudgeTask(int customerDataID) {this.rewardDataID=customerDataID;}
	
	// Getter & Setter
	public int getRewardDataID() {return rewardDataID;}
}
