package specificModel.data.taskData.rewardTask;

import specificModel.data.taskData.AbsTask;

public class LossCheckTask extends AbsTask{
	
	// Attribute
	private int rewardDataID;	
	
	// Constructor
	public LossCheckTask(int customerDataID) {this.rewardDataID=customerDataID;}
	
	// Getter & Setter
	public int getRewardDataID() {return rewardDataID;}
}
