package specificModel.data.taskData;

import model.data.Data_LV1;

public abstract class AbsTask extends Data_LV1{
}
