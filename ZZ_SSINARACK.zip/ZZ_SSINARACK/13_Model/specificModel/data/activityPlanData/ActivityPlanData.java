package specificModel.data.activityPlanData;

import java.util.Vector;

import db.DAO_LV0;
import model.DAOAdapter;
import model.data.Data_LV1;
import specificModel.enums.ETargetCustomer;

public class ActivityPlanData extends Data_LV1 {
	
	// Component
	private DAO_LV0 dao;
	private Vector<ETargetCustomer> salesTargetCustomer;
	
	// Constructor
	public ActivityPlanData() {
		this.dao = DAOAdapter.getPlugged();
		this.dao.setTableName("ActivityPlan");
		this.dao.setPKName("activityPlanID");
		this.dao.setDefaultValues(new Object[] { null, "", "", 0, "", 0, null });
	}
	
//	// Original Constructor
//	public ActivityPlanData() {
//		this.dao = new DAO("ActivityPlan", "activityPlanID", new Object[] { null, "", "", 0, "", 0, null });
//	}

	// getter & setter
	public String getTitle() {return this.dao.getString("title");}
	public String getSalesDuration() {return this.dao.getString("salesDuration");}
	public String getActivityGoal() {return this.dao.getString("activityGoal");}
	public int getSalesGoal() {return this.dao.getInt("salesGoal");}
	public int getAdditionalJobOffer() {return this.dao.getInt("additionalJobOffer");}
	public Vector<ETargetCustomer> getSalesTargetCustomer() { return salesTargetCustomer; }
	
	public void setTitle(String title) {this.dao.update("title", title);}
	public void setSalesDuration(String salesDuration) {this.dao.update("salesDuration", salesDuration);}
	public void setActivityGoal(String activityGoal) {this.dao.update("activityGoal", activityGoal);}
	public void setSalesGoal(int salesGoal) {this.dao.update("salesGoal", salesGoal);}	
	public void setAdditionalJobOffer(int additionalJobOffer) {this.dao.update("additionalJobOffer", additionalJobOffer);}
	public void setSalesTargetCustomer(Vector<ETargetCustomer> salesTargetCustomer) { this.salesTargetCustomer = salesTargetCustomer;}

//	public ETargetCustomer getSalesTargetCustomer() {return ETargetCustomer.valueOf(this.dao.getString("salesTargetCustomer"));}
//	public void setSalesTargetCustomer(ETargetCustomer salesTargetCustomer) {this.dao.update("salesTargetCustomer", salesTargetCustomer.ordinal()+1);}
	
}
