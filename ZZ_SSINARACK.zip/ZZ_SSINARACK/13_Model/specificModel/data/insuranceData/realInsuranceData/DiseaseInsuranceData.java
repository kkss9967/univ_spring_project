package specificModel.data.insuranceData.realInsuranceData;

import db.DAO_LV0;
import model.DAOAdapter;
import specificModel.data.customerData.CustomerData;
import specificModel.data.insuranceData.AbsInsuranceData;
import specificModel.enums.EFamilyIllHistory;

public class DiseaseInsuranceData extends AbsInsuranceData {

	// Component
	private DAO_LV0 dao;
	
	// Attribute
	public enum EDisease {CANCER, HEARTH_ATTACK};

		// Constructor
	public DiseaseInsuranceData() {
		this.dao = DAOAdapter.getPlugged();
		this.dao.setTableName("DiseaseIns");
		this.dao.setPKName("diseaseID");
		this.dao.setDefaultValues(new Object[] {null, null});
	}

	// Any Time Use
	@Override 
	public double insuranceRateCheck(CustomerData data) {
		double result = 1;
		for(EFamilyIllHistory history : data.getIllHistory()) {
			switch(history) {
			case Cancer : result*=2; break;
			case Diabetes : result*=1.1; break;
			case HeartDisease : result*=1.3; break;
			case HighBloodPressure : result*=1.1; break;
			case Stroke : result*=1.3; break;
			}
		}
		if(data.getAge()>80) {result*=1.5;}
		else if(data.getAge()>60) {result*=1.4;}
		else if(data.getAge()>40) {result*=1.3;}
		if(data.isMale()) {result*=1.1;}
		return result;
	}

	// Getter & Setter
	public EDisease getDisease() {return EDisease.valueOf(this.dao.getString("disease"));}
	public void setDisease(EDisease disease) {this.dao.update("disease", disease.ordinal()+1);}
}
