package specificModel.data.systemUserData;

import db.DAO_LV0;
import model.DAOAdapter;
import model.data.Data_LV1;
import model.table.Table_LV1;
import specificModel.data.taskData.AbsTask;

public class SystemUserData<TaskType extends AbsTask> extends Data_LV1 {
	
	// Component
//	private DAO dao;
	private DAO_LV0 dao;

	// Attribute
	public String loginID, loginPW;
			
	// Component
	private Table_LV1<TaskType> taskList;
	
	// Constructor
	public SystemUserData() {
		this.dao = DAOAdapter.getPlugged();
		this.dao.setTableName("SystemUserData");
		this.dao.setPKName("systemUserDataID");
		this.dao.setDefaultValues(new Object[] {null, "", ""});
		this.taskList = new Table_LV1<TaskType>();
	}
	
	// Original Constructor
//	public SystemUserData() {
//		// Create Component
//		this.dao = new DAO("SystemUserData", "systemUserDataID", new Object[] {null, "", ""});
//		this.taskList = new DataList<TaskType>();
//	}
	
	// Any Time Use
	public void addTask(TaskType task) {this.taskList.add(task);}
	public void deleteTask(int iD) {this.taskList.delete(iD);}
	public TaskType searchTask(int iD) {return this.taskList.search(iD);}
		
	// Getter & Setter
	public Table_LV1<TaskType> getTaskList() {return this.taskList;}
	
	public String getLoginID() {return this.dao.getString("loginID");}
	public void setLoginID(String loginID) {this.dao.update("loginID", loginID);}
	public String getLoginPW() {return this.dao.getString("loginPW");}
	public void setLoginPW(String loginPW) {this.dao.update("loginPW", loginPW);}

}
