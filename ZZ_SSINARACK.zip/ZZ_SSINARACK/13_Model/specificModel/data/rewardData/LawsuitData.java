package specificModel.data.rewardData;

import db.DAO_LV0;
import model.DAOAdapter;

public class LawsuitData{

	// Component
	private DAO_LV0 dao;
	
	// Constructor
	public LawsuitData() {
		this.dao = DAOAdapter.getPlugged();
		this.dao.setTableName("Lawsuit");
		this.dao.setPKName("lawsuitID");
		this.dao.setDefaultValues(new Object[] {null, 0});
	}

	// Getter & Setter
	public int getPay() {return this.dao.getInt("payOut");}
	public void setPay(int pay) {this.dao.update("payOut", pay);}
}
