package specificModel.data.rewardData;

import db.DAO_LV0;
import model.DAOAdapter;

public class LossCheckData{
	
	// Component
	private DAO_LV0 dao;
	
	// Constructor
	public LossCheckData() {
		this.dao = DAOAdapter.getPlugged();
		this.dao.setTableName("LossData");
		this.dao.setPKName("lossDataID");
		this.dao.setDefaultValues(new Object[] {null, 0, ""});
	}

	// Getter & Setter
	public String getJudgeEvidence() {return this.dao.getString("judgeEvidence");}
	public int getPay() {return this.dao.getInt("pay");}
	public void setJudgeEvidence(String judgeEvidence) {this.dao.update("judgeEvidence", judgeEvidence);}
	public void setPay(int pay) {this.dao.update("pay", pay);}
}
