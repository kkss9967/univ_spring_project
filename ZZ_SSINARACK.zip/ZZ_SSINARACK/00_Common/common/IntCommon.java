package common;

public interface IntCommon {
	
	// Method
	public void start();
	public void end();
}
