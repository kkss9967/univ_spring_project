package panel.panelInterface.develop;

import panel.Panel_LV0;
import specificModel.data.insuranceData.AbsInsuranceData;

public interface IntShowInsuranceForJudgeView extends Panel_LV0 {

    public void setInsuranceData(AbsInsuranceData insuranceData);

}
