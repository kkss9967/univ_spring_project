package panel.panelInterface.develop;

import model.table.Table_LV0;
import panel.Panel_LV0;
import specificModel.data.employeeData.AbsEmployeeData;
import specificModel.data.insuranceData.AbsInsuranceData;
import specificModel.data.taskData.developTask.InsurancePermitTask;

public interface IntPermitTaskSelectView extends Panel_LV0 {

    public void setInsurancePermitTask(AbsEmployeeData<InsurancePermitTask> loginIRPM);
    public void setAbsInsuranceDataList(Table_LV0<AbsInsuranceData> insuranceList);

}
