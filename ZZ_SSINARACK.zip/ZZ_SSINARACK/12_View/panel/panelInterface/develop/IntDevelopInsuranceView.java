package panel.panelInterface.develop;

import panel.Panel_LV0;

public interface IntDevelopInsuranceView extends Panel_LV0 {

	public void setIsDisease(boolean isDisease);
	
	public String getName();
	public String getContent();
	public String getInsuranceRateInfo();
	public String getLossPercent();
	public String getDisease();
}
