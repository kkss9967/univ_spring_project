package panel.panelInterface.develop;

import model.table.Table_LV0;
import panel.Panel_LV0;
import specificModel.data.insuranceData.AbsInsuranceData;

public interface IntSelectInsuranceToWatchView extends Panel_LV0 {
    public void setAbsInsuranceDataList(Table_LV0<AbsInsuranceData> insuranceList);

    public String getName();
    public String getContent();
    public String getInsuranceRateInfo();
    public String getLossPercent();
    public String getDisease();

}
