package panel.panelInterface.develop;

public interface IntDevelopInsuranceSelectView {
}
