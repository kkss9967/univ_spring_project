package panel.panelInterface.develop;

import panel.Panel_LV0;

public interface IntDeveloperTaskSelectView extends Panel_LV0 {
}
