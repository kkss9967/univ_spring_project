package panel.panelInterface.login;

public interface IntLoginPanel {

	// Getter & Setter
	public String getId();
	public String getPw();
	public void showLoginFailed();
}
