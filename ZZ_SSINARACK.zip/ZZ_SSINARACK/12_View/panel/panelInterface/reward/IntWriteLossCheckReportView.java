package panel.panelInterface.reward;

import panel.Panel_LV0;

public interface IntWriteLossCheckReportView extends Panel_LV0 {
	
	public String getPayTTA();
	public String getJudgeEvidenceTTA();
	
}
