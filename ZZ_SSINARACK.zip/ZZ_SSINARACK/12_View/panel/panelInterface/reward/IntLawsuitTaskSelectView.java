package panel.panelInterface.reward;

import model.table.Table_LV0;
import panel.Panel_LV0;
import specificModel.data.employeeData.rewardEmployeeData.LawyerData;
import specificModel.data.rewardData.RewardData;

public interface IntLawsuitTaskSelectView extends Panel_LV0 {
	
	public void setUser(LawyerData user);
	public void setRewardDataList(Table_LV0<RewardData> rewardDataList);
}
