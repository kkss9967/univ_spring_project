package panel.panelInterface.reward;

import model.table.Table_LV0;
import panel.Panel_LV0;
import specificModel.data.customerData.CustomerData;
import specificModel.data.rewardData.RewardData;

public interface IntShowPaymentAgreeView extends Panel_LV0 {
	
	public void setUser(CustomerData user);
	public void setRewardDataList(Table_LV0<RewardData> rewardDataList);
	
	public String getAccidentType();
	public String getAccidentLocation();
	public String getAccidentDate();
}
