package panel.panelInterface.reward;

import panel.Panel_LV0;

public interface IntCustomerTaskSelectView extends Panel_LV0 {
	
}
