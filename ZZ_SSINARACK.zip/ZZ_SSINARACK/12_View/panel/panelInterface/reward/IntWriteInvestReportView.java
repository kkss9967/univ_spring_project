package panel.panelInterface.reward;

import panel.Panel_LV0;

public interface IntWriteInvestReportView extends Panel_LV0 {
	
	public String getScenarioTTA();
	public String getDamageTTA();
	public String getTreatmentTTA();
	public String getTreatmentCostTTA();
}
