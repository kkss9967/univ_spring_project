package panel.panelInterface.reward;

import panel.Panel_LV0;

public interface IntAccidentProcessApplyView extends Panel_LV0 {
	public String getAccidentType();
	public String getAccidentLocation();
	public String getAccidentDate();
}
