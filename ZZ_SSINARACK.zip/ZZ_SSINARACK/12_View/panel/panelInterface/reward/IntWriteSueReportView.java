package panel.panelInterface.reward;

import panel.Panel_LV0;

public interface IntWriteSueReportView extends Panel_LV0 {
	public String getPayTTA();
}
