package panel.panelInterface.reward;

import panel.Panel_LV0;
import specificModel.data.rewardData.RewardData;

public interface IntPaymentAgreeView extends Panel_LV0 {
	
	public void setRewardData(RewardData reward);
}
