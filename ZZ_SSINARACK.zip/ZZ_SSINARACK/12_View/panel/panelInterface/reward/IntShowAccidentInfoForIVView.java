package panel.panelInterface.reward;

import model.table.Table_LV0;
import panel.Panel_LV0;
import specificModel.data.employeeData.rewardEmployeeData.AccidentInvestigatorData;
import specificModel.data.rewardData.RewardData;

public interface IntShowAccidentInfoForIVView extends Panel_LV0 {
	
	public void setUser(AccidentInvestigatorData user);
	public void setTaskId(int taskID);
	public void setRewardDataList(Table_LV0<RewardData> rewardDataList);
}
