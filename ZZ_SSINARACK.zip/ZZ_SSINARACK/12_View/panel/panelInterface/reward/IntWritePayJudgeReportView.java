package panel.panelInterface.reward;

import panel.Panel_LV0;

public interface IntWritePayJudgeReportView extends Panel_LV0 {
	public String getPayJudgeTTA();
	public String getJudgementEvidenceTTA();
	public String getRelatedLawTTA();
}
