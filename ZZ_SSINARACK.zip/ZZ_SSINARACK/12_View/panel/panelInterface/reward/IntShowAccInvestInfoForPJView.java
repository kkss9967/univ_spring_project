package panel.panelInterface.reward;

import model.table.Table_LV0;
import panel.Panel_LV0;
import specificModel.data.employeeData.rewardEmployeeData.PayJudgerData;
import specificModel.data.rewardData.RewardData;

public interface IntShowAccInvestInfoForPJView extends Panel_LV0 {
	public void setUser(PayJudgerData user);
	public void setTaskID(int taskID);
	public void setRewardDataList(Table_LV0<RewardData> rewardDataList);
	
}
