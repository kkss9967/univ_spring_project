package panel.panelInterface.reward;

import model.table.Table_LV0;
import panel.Panel_LV0;
import specificModel.data.employeeData.rewardEmployeeData.LossCheckManData;
import specificModel.data.rewardData.RewardData;

public interface IntLossCheckTaskSelectView extends Panel_LV0 {
	public void setUser(LossCheckManData user);
	public void setRewardDataList(Table_LV0<RewardData> rewardDataList);
}
