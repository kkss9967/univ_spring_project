package panel.panelInterface.sales.SalesManager;

import component.button.TitledRadioButtonGroup;
import component.textArea.InputTextArea;
import panel.Panel_LV0;

public interface IntSaveSalesTrainingPlanView extends Panel_LV0{

	public InputTextArea getTitleTTA() ;
	public void setTitleTTA(InputTextArea titleTTA);
	public InputTextArea getSalesTrainingDateTTA();
	public void setSalesTrainingDateTTA(InputTextArea salesTrainingDateTTA);
	public InputTextArea getSalesTrainingPlaceTTA();
	public void setSalesTrainingPlaceTTA(InputTextArea salesTrainingPlaceTTA);
	public InputTextArea getSalesTrainingGoalTTA();
	public void setSalesTrainingGoalTTA(InputTextArea salesTrainingGoalTTA);
	public InputTextArea getSalesTrainingContentTTA();
	public void setSalesTrainingContentTTA(InputTextArea salesTrainingContentTTA);
	public TitledRadioButtonGroup getSalesTrainingTargetTTA();
	public void setSalesTrainingTargetTTA(TitledRadioButtonGroup salesTrainingTargetTTA);

}
