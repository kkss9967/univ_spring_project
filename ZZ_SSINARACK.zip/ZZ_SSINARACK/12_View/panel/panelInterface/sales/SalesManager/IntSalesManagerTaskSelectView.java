package panel.panelInterface.sales.SalesManager;

import panel.Panel_LV0;

public interface IntSalesManagerTaskSelectView extends Panel_LV0{

}
