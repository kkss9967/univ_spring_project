package panel.panelInterface.sales.SalesManager;

import component.button.TitledRadioButtonGroup;
import component.textArea.InputTextArea;
import panel.Panel_LV0;

public interface IntSaveActivityPlanView extends Panel_LV0{

	public InputTextArea getTitleTTA();
	public void setTitleTTA(InputTextArea titleTTA);
	public InputTextArea getActivityGoalTTA();
	public void setActivityGoalTTA(InputTextArea activityGoalTTA);
	public InputTextArea getDateTTA();
	public void setDateTTA(InputTextArea dateTTA);
	public InputTextArea getSalesGoalTTA();
	public void setSalesGoalTTA(InputTextArea salesGoalTTA);
	public InputTextArea getAdditionalJobOfferTTA();
	public void setAdditionalJobOfferTTA(InputTextArea additionalJobOfferTTA);
	public TitledRadioButtonGroup getSalesTargetCustomerTTA();
	public void setSalesTargetCustomerTTA(TitledRadioButtonGroup salesTargetCustomerTTA);
}
