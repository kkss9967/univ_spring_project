package panel.panelInterface.sales.SalesMan.WatchSalesTrainingPlan;

import model.table.Table_LV0;
import panel.Panel_LV0;
import specificModel.data.SalesTrainingPlanData.SalesTrainingPlanData;

public interface IntWatchDetailSalesTrainingPlanView extends Panel_LV0 {

	public void setSalesTrainingPlanID(int salesTrainingPlanID);
	public void setSalesTrainigPlanList(Table_LV0<SalesTrainingPlanData> salesTrainigPlanList);
	
}
