package panel.panelInterface.sales.SalesMan.WatchSalesTrainingPlan;

import model.table.Table_LV0;
import panel.Panel_LV0;
import specificModel.data.SalesTrainingPlanData.SalesTrainingPlanData;

public interface IntWatchSalesTrainingPlanView extends Panel_LV0 {

	public void setSalesTrainingPlanList(Table_LV0<SalesTrainingPlanData> salesTrainingPlanList);

}
