package panel.panelInterface.sales.SalesMan.LookupAvailableProduct;

import model.table.Table_LV0;
import panel.Panel_LV0;
import specificModel.data.customerData.CustomerData;
import specificModel.data.insuranceData.AbsInsuranceData;

public interface IntShowAvailableProductView extends Panel_LV0{

	public void setCustomerData(CustomerData customerData);
	public void setInsuranceDataList(Table_LV0<AbsInsuranceData> insuranceDataList);

}
