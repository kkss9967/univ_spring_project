package panel.panelInterface.sales.SalesMan.LookupAvailableProduct;

import component.textArea.InputTextArea;
import model.table.Table_LV0;
import panel.Panel_LV0;
import specificModel.data.customerData.CustomerData;

public interface IntSearchCustomerView extends Panel_LV0{

	public void setCustomerDataList(Table_LV0<CustomerData> customerDataList);

	public InputTextArea getCustomerNameTTA() ;
	public void setCustomerNameTTA(InputTextArea customerNameTTA) ;
}
