package panel.panelInterface.sales.SalesMan.LookupAvailableProduct;

import model.table.Table_LV0;
import panel.Panel_LV0;
import specificModel.data.customerData.CustomerData;
import specificModel.data.insuranceData.AbsInsuranceData;

public interface IntShowInsuranceInfoToCustomerView extends Panel_LV0{

	public void setInsuranceDataList(Table_LV0<AbsInsuranceData> insuranceDataList);
	public void setInsuranceID(int insuranceID);
	public void setCustomerData(CustomerData customerData);
}
