package panel.panelInterface.sales.SalesMan.LookupAvailableProduct;

import component.textArea.InputTextArea;
import model.table.Table_LV0;
import panel.Panel_LV0;
import specificModel.data.customerData.CustomerData;

public interface IntShowCustomerInfoView extends Panel_LV0{

	public void setSearchedCustomerList(Table_LV0<CustomerData> searchedCustomerList);
	public void setSearchedNameTTA(InputTextArea searchedNameTTA);

}
