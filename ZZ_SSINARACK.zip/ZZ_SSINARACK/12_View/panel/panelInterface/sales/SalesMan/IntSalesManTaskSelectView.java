package panel.panelInterface.sales.SalesMan;

import panel.Panel_LV0;

public interface IntSalesManTaskSelectView extends Panel_LV0{

}
