package panel.panelInterface.sales.SalesMan.WatchActivityPlan;

import model.table.Table_LV0;
import panel.Panel_LV0;
import specificModel.data.activityPlanData.ActivityPlanData;

public interface IntWatchActivityPlanView extends Panel_LV0{
	public void setActivityPlanList(Table_LV0<ActivityPlanData> activityPlanList);

}
