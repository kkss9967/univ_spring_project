package panel.panelInterface.sales.SalesMan.SignInCustomer;

import component.button.TitledRadioButtonGroup;
import component.textArea.InputTextArea;
import panel.Panel_LV0;

public interface IntSigninCustomerView extends Panel_LV0 {

	public InputTextArea getNameTTA(); 
	public void setNameTTA(InputTextArea nameTTA);
	public InputTextArea getResidenceTTA(); 
	public void setResidenceTTA(InputTextArea residenceTTA);
	public InputTextArea getPhoneNumTTA(); 
	public void setPhoneNumTTA(InputTextArea phoneNumTTA);
	public InputTextArea getEmailTTA();
	public void setEmailTTA(InputTextArea emailTTA);
	public InputTextArea getSocialSecurityNumTTA();
	public void setSocialSecurityNumTTA(InputTextArea socialSecurityNumTTA);
	public InputTextArea getJobTTA();
	public void setJobTTA(InputTextArea jobTTA);
	public InputTextArea getPropertyTTA();
	public void setPropertyTTA(InputTextArea propertyTTA);
	public InputTextArea getAgeTTA();
	public void setAgeTTA(InputTextArea ageTTA);
	public InputTextArea getAccountNumTTA();
	public void setAccountNumTTA(InputTextArea accountNumTTA);
	public InputTextArea getLoginIDTTA();
	public void setLoginIDTTA(InputTextArea loginIDTTA);
	public InputTextArea getLoginPWTTA();
	public void setLoginPWTTA(InputTextArea loginPWTTA);
	public TitledRadioButtonGroup getFamilyillhistoryRBN();
	public void setFamilyillhistoryRBN(TitledRadioButtonGroup familyillhistoryRBN);
	public TitledRadioButtonGroup getGenderRBN();
	public void setGenderRBN(TitledRadioButtonGroup genderRBN);
	public TitledRadioButtonGroup getAccidentHistoryRBN();
	public void setAccidentHistoryRBN(TitledRadioButtonGroup accidentHistoryRBN);
}
