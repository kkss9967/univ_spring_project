package panel.panel.salesView.salesManager;

import java.awt.Color;

import component.button.LinkButton;
import component.button.SelectButton;
import component.etc.SeparateLine;
import component.group.StaticGroup;
import component.label.BasicLabel;
import panel.Panel_LV2.Panel_LV2;
import panel.aConstant.InsuranceSystemViewConstant;
import panel.panelInterface.sales.SalesManager.IntSalesManagerTaskSelectView;
import sales.salesManagerAspect.SalesManagerTaskSelectSystem;

@SuppressWarnings("serial")
public class SalesManagerTaskSelectView extends Panel_LV2 implements IntSalesManagerTaskSelectView{
		
	// Constructor
	public void start() {

		// add component
		this.addComponent(new BasicLabel("���� ����"));
		this.addComponent(new SeparateLine(Color.black));
		
		StaticGroup g = new StaticGroup(new int[] {1,1});
		g.addGroupComponent(new SelectButton("�Ǹ� Ȱ�� ��ȹ �ۼ��ϱ�", SalesManagerTaskSelectSystem.EActionCommands.SaveActivityPlan.name(), this.actionListener));
		g.addGroupComponent(new SelectButton("���� Ȱ�� �����ϱ�", SalesManagerTaskSelectSystem.EActionCommands.SaveSalesTrainingPlan.name(), this.actionListener));
		this.addComponent(g);
		
		this.addToLinkPanel(
				new LinkButton(InsuranceSystemViewConstant.SomeThingLookGreat, "", null),
	            new LinkButton(InsuranceSystemViewConstant.SomeThingLookNide, "", null),
				new LinkButton("�Ǹ� ��ȹ", SalesManagerTaskSelectSystem.EActionCommands.SaveActivityPlan.name(), this.actionListener),
				new LinkButton("���� ����", SalesManagerTaskSelectSystem.EActionCommands.SaveSalesTrainingPlan.name(), this.actionListener)
		);
	}
}
