package panel.panel.salesView.salesMan.watchSalesTrainingPlan;

import java.awt.Color;

import javax.swing.JLabel;

import component.button.LinkButton;
import component.etc.SeparateLine;
import component.label.BasicLabel;
import component.textArea.OutputTextArea;
import model.table.Table_LV0;
import panel.Panel_LV2.Panel_LV2;
import panel.aConstant.InsuranceSystemViewConstant;
import panel.panelInterface.sales.SalesMan.WatchSalesTrainingPlan.IntWatchDetailSalesTrainingPlanView;
import sales.salesManAspect.WatchSalesTrainingPlan.WatchDetailSalesTrainingPlanSystem;
import specificModel.data.SalesTrainingPlanData.SalesTrainingPlanData;
import specificModel.enums.ETrainingTargetEmployee;

public class WatchDetailSalesTrainingPlanView extends Panel_LV2 implements IntWatchDetailSalesTrainingPlanView{
	private static final long serialVersionUID = 1L;

	// Attribute
	private int salesTrainingPlanID;
	private Table_LV0<SalesTrainingPlanData> salesTrainigPlanList;

	@Override public void setSalesTrainingPlanID(int salesTrainingPlanID) {this.salesTrainingPlanID = salesTrainingPlanID;}
	@Override public void setSalesTrainigPlanList(Table_LV0<SalesTrainingPlanData> salesTrainigPlanList) {this.salesTrainigPlanList = salesTrainigPlanList;}
	

	public void start() {

		SalesTrainingPlanData watchingSalesTrainingPlanData = this.salesTrainigPlanList.search(this.salesTrainingPlanID);
		// add component
		this.addComponent(new BasicLabel("���� ���� ���� ��ȹ ����"));
		this.addComponent(new SeparateLine(Color.black));

		String targetNames = "";
		for(ETrainingTargetEmployee target : watchingSalesTrainingPlanData.getTarget()) {targetNames +=(target.name()+", ");}
		this.addComponent(new JLabel("��ȸ�Ͻ� ���� ���� ��ȹ�� ���� �����Դϴ�."));
		this.addComponent(new OutputTextArea("����", watchingSalesTrainingPlanData.getTitle()));
		this.addComponent(new OutputTextArea("��¥", watchingSalesTrainingPlanData.getsalesTraningPlanDate()));
		this.addComponent(new OutputTextArea("���", watchingSalesTrainingPlanData.getPlace()));
		this.addComponent(new OutputTextArea("�������", targetNames));
		this.addComponent(new OutputTextArea("������ǥ ",  watchingSalesTrainingPlanData.getSalesTrainingGoal()));
		this.addComponent(new OutputTextArea("��������",  watchingSalesTrainingPlanData.getSalesTrainingContent()));
		this.addToLinkPanel(
				new LinkButton(InsuranceSystemViewConstant.SomeThingLookGreat, "", null),
	            new LinkButton(InsuranceSystemViewConstant.SomeThingLookNide, "", null),
				new LinkButton("���� ����", WatchDetailSalesTrainingPlanSystem.EActionCommands.SigninCustomer.name(), this.actionListener),
				new LinkButton("���� ���� ��ȸ", WatchDetailSalesTrainingPlanSystem.EActionCommands.LookupAvailableProduct.name(), this.actionListener),
				new LinkButton("�Ǹ� Ȱ�� ��ȸ", WatchDetailSalesTrainingPlanSystem.EActionCommands.WatchActivityPlan.name(), this.actionListener),
				new LinkButton("���� Ȱ�� ��ȸ", WatchDetailSalesTrainingPlanSystem.EActionCommands.WatchSalesTrainingPlan.name(), this.actionListener)
		);
		
	}
}
