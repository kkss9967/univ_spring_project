package panel.panel.salesView.salesMan.watchSalesTrainingPlan;

import java.awt.Color;

import component.button.LinkButton;
import component.button.SelectButton;
import component.etc.SeparateLine;
import component.group.DynamicGroup;
import component.label.BasicLabel;
import model.table.Table_LV0;
import panel.Panel_LV2.Panel_LV2;
import panel.aConstant.InsuranceSystemViewConstant;
import panel.panelInterface.sales.SalesMan.WatchSalesTrainingPlan.IntWatchSalesTrainingPlanView;
import sales.salesManAspect.WatchSalesTrainingPlan.WatchSalesTrainingPlanSystem;
import specificModel.data.SalesTrainingPlanData.SalesTrainingPlanData;

public class WatchSalesTrainingPlanView extends Panel_LV2 implements IntWatchSalesTrainingPlanView{
	private static final long serialVersionUID = 1L;

	// Attribute
	private Table_LV0<SalesTrainingPlanData> salesTrainingPlanList;
	
	@Override public void setSalesTrainingPlanList(Table_LV0<SalesTrainingPlanData> salesTrainingPlanList) {this.salesTrainingPlanList = salesTrainingPlanList;}

	public void start() {

		// add component
		this.addComponent(new BasicLabel("���� ���� ��ȹ ��ȸ"));
		this.addComponent(new SeparateLine(Color.black));

		DynamicGroup selectBtnGroup = new DynamicGroup();
		for (SalesTrainingPlanData data : salesTrainingPlanList.getList()) {
			selectBtnGroup.addGroupComponent(new SelectButton(data.getTitle(), Integer.toString(data.getID()), actionListener));
		}
		this.addComponent(selectBtnGroup);
		
		this.addToLinkPanel(
				new LinkButton(InsuranceSystemViewConstant.SomeThingLookGreat, "", null),
	            new LinkButton(InsuranceSystemViewConstant.SomeThingLookNide, "", null),
				new LinkButton("���� ����", WatchSalesTrainingPlanSystem.EActionCommands.SigninCustomer.name(), actionListener),
				new LinkButton("���� ���� ��ȸ", WatchSalesTrainingPlanSystem.EActionCommands.LookupAvailableProduct.name(), actionListener),
				new LinkButton("�Ǹ� Ȱ�� ��ȸ", WatchSalesTrainingPlanSystem.EActionCommands.WatchActivityPlan.name(), actionListener),
				new LinkButton("���� Ȱ�� ��ȸ", WatchSalesTrainingPlanSystem.EActionCommands.WatchSalesTrainingPlan.name(), actionListener)
		);
	}
}
