package panel.panel.salesView.salesMan.LookupAvailableProduct;

import java.awt.Color;
import java.util.Vector;

import component.button.ActionButton;
import component.button.LinkButton;
import component.etc.SeparateLine;
import component.group.DynamicGroup;
import component.label.BasicLabel;
import component.textArea.OutputTextArea;
import model.table.Table_LV0;
import panel.Panel_LV2.Panel_LV2;
import panel.aConstant.InsuranceSystemViewConstant;
import panel.panelInterface.sales.SalesMan.LookupAvailableProduct.IntShowAvailableProductView;
import sales.salesManAspect.LookupAvailableProduct.ShowAvailableProductSystem;
import specificModel.data.customerData.CustomerData;
import specificModel.data.insuranceData.AbsInsuranceData;

public class ShowAvailableProductView extends Panel_LV2 implements IntShowAvailableProductView{
	private static final long serialVersionUID = 1L;
	
	// Association
	private CustomerData customerData;
	@Override public void setCustomerData(CustomerData customerData) {this.customerData = customerData;}

	// Attribute
	private Table_LV0<AbsInsuranceData> insuranceDataList;
	@Override public void setInsuranceDataList(Table_LV0<AbsInsuranceData> insuranceDataList) {this.insuranceDataList = insuranceDataList;}
	
	public void start() {

		//create and add component
		this.addComponent(new BasicLabel("�����Ͻ� �� �ִ� ���� ��ǰ�Դϴ�."));
		this.addComponent(new SeparateLine(Color.black));
		
		Vector<AbsInsuranceData> searchedInsuranceData = searching(insuranceDataList);
		if(searchedInsuranceData.size()==0){
			this.addComponent(new OutputTextArea("�����Բ��� �����Ͻ� �� �ִ� ��ǰ�� �������� �ʽ��ϴ�.", ""));
		} else {
			DynamicGroup g = new DynamicGroup();
			for (AbsInsuranceData insuranceData : searchedInsuranceData) {
				g.addGroupComponent(new ActionButton(printline(insuranceData), Integer.toString(insuranceData.getID()), actionListener));
			}
			this.addComponent(g);
		}
		
		this.addToLinkPanel(
				new LinkButton(InsuranceSystemViewConstant.SomeThingLookGreat, "", null),
	            new LinkButton(InsuranceSystemViewConstant.SomeThingLookNide, "", null),
				new LinkButton("���� ����", ShowAvailableProductSystem.EActionCommands.SigninCustomer.name(), actionListener),
				new LinkButton("���� ���� ��ȸ", ShowAvailableProductSystem.EActionCommands.LookupAvailableProduct.name(), actionListener),
				new LinkButton("�Ǹ� Ȱ�� ��ȸ", ShowAvailableProductSystem.EActionCommands.WatchActivityPlan.name(), actionListener),
				new LinkButton("���� Ȱ�� ��ȸ", ShowAvailableProductSystem.EActionCommands.WatchSalesTrainingPlan.name(), actionListener)
		);
	}

	// ���԰��� ���� ��ȸ
	public Vector<AbsInsuranceData> searching(Table_LV0<AbsInsuranceData> insuranceDataList) {
//		IntDataList<AbsInsuranceData> availableInsuranceList= new DataList<AbsInsuranceData>();
		Vector<AbsInsuranceData> availableInsuranceList = new Vector<AbsInsuranceData>();
		for (AbsInsuranceData insuranceData : insuranceDataList.getList()) {
			if (!insuranceData.isCustomerSignIn(this.customerData.getID())
					&& insuranceData.getLossPercent() >= insuranceData.insuranceRateCheck(this.customerData)) {
				availableInsuranceList.add(insuranceData);
			}
		}
		return availableInsuranceList;
	}
	
	// ��ư �� ����
	public String printline(AbsInsuranceData insuranceData) {
		// Format : ����� (���� 10�ڸ� + ...)
		String content = "";
		if (insuranceData.getContent().length() > 10) {content = insuranceData.getContent().substring(0, 10);
		} else {content = insuranceData.getContent();}
		String line = insuranceData.getName() + "(" + content + ")";
		return line;
	}
}
