package panel.panel.salesView.salesMan.LookupAvailableProduct;

import java.awt.Color;

import component.button.ActionButton;
import component.button.LinkButton;
import component.etc.SeparateLine;
import component.group.StaticGroup;
import component.label.BasicLabel;
import component.textArea.InputTextArea;
import model.table.Table_LV0;
import panel.Panel_LV2.Panel_LV2;
import panel.aConstant.InsuranceSystemViewConstant;
import panel.panelInterface.sales.SalesMan.LookupAvailableProduct.IntSearchCustomerView;
import sales.salesManAspect.LookupAvailableProduct.SearchCustomerSystem;
import specificModel.data.customerData.CustomerData;

public class SearchCustomerView extends Panel_LV2 implements IntSearchCustomerView {
	private static final long serialVersionUID = 1L;

		// no use
		@Override public void setCustomerDataList(Table_LV0<CustomerData> customerDataList) {}

	// Component
	private InputTextArea customerNameTTA;

	public void start() {

		// add component (create component�� for������ ����������)
		this.addComponent(new BasicLabel("������ �Է�"));
		this.addComponent(new SeparateLine(Color.black));
		
		StaticGroup g = new StaticGroup(new int[] {1});
		this.customerNameTTA = new InputTextArea("������", "������", 1, 100);
		g.addGroupComponent(this.customerNameTTA);
		this.addComponent(g);
		
		this.addComponent(new ActionButton("��ȸ",SearchCustomerSystem.EActionCommands.search.name(),actionListener));
		
		this.addToLinkPanel(
				new LinkButton(InsuranceSystemViewConstant.SomeThingLookGreat, "", null),
	            new LinkButton(InsuranceSystemViewConstant.SomeThingLookNide, "", null),
				new LinkButton("���� ����", SearchCustomerSystem.EActionCommands.SigninCustomer.name(), actionListener),
				new LinkButton("���� ���� ��ȸ", SearchCustomerSystem.EActionCommands.LookupAvailableProduct.name(), actionListener),
				new LinkButton("�Ǹ� Ȱ�� ��ȸ", SearchCustomerSystem.EActionCommands.WatchActivityPlan.name(), actionListener),
				new LinkButton("���� Ȱ�� ��ȸ", SearchCustomerSystem.EActionCommands.WatchSalesTrainingPlan.name(), actionListener)
		);
	}

	// get & set
	public InputTextArea getCustomerNameTTA() {return this.customerNameTTA;}
	public void setCustomerNameTTA(InputTextArea customerNameTTA) {this.customerNameTTA = customerNameTTA;}

}
