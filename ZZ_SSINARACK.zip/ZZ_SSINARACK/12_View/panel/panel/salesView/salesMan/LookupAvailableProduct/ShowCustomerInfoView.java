package panel.panel.salesView.salesMan.LookupAvailableProduct;

import java.awt.Color;
import java.awt.Font;

import component.button.LinkButton;
import component.button.SelectButton;
import component.etc.SeparateLine;
import component.group.DynamicGroup;
import component.label.BasicLabel;
import component.textArea.InputTextArea;
import model.table.Table_LV0;
import panel.Panel_LV2.Panel_LV2;
import panel.aConstant.InsuranceSystemViewConstant;
import panel.panelInterface.sales.SalesMan.LookupAvailableProduct.IntShowCustomerInfoView;
import sales.salesManAspect.LookupAvailableProduct.ShowCustomerInfoSystem;
import specificModel.data.customerData.CustomerData;

public class ShowCustomerInfoView extends Panel_LV2 implements IntShowCustomerInfoView {
	private static final long serialVersionUID = 1L;
	
	// Attribute
	private Table_LV0<CustomerData> searchedCustomerList;
	private InputTextArea searchedNameTTA;

	@Override public void setSearchedCustomerList(Table_LV0<CustomerData> searchedCustomerList) {this.searchedCustomerList = searchedCustomerList;}
	@Override public void setSearchedNameTTA(InputTextArea searchedNameTTA) {this.searchedNameTTA = searchedNameTTA;}

	
	public void start() {

		this.addComponent(new BasicLabel("���� ��ȸ ���"));
		this.addComponent(new SeparateLine(Color.black));

		if (searchedCustomerList.getList().isEmpty()) {
			BasicLabel bl = new BasicLabel("��û�Ͻ� "+searchedNameTTA.getContent() + " ���� �ý��ۿ� �������� �ʽ��ϴ�. �ٽ��ѹ� Ȯ�����ֽʽÿ�");
			bl.setLabelFont(Font.PLAIN, 15);
			this.addComponent(bl);
		} else {
			BasicLabel bl = new BasicLabel("��û�Ͻ� "+ searchedNameTTA.getContent() + "�� �����Դϴ�.");
			bl.setLabelFont(Font.PLAIN, 15);
			this.addComponent(bl);
			// ȫ�浿 �� (��, 22��, 990618-1)�� ����ϵ��� ����
			DynamicGroup g = new DynamicGroup();
			for (CustomerData customerData : searchedCustomerList.getList()) {
				g.addGroupComponent(new SelectButton(printline(customerData),Integer.toString(customerData.getID()), actionListener));
			}
			this.addComponent(g);
		}
		this.addToLinkPanel(
				new LinkButton(InsuranceSystemViewConstant.SomeThingLookGreat, "", null),
	            new LinkButton(InsuranceSystemViewConstant.SomeThingLookNide, "", null),
				new LinkButton("���� ����", ShowCustomerInfoSystem.EActionCommands.SigninCustomer.name(), actionListener),
				new LinkButton("���� ���� ��ȸ", ShowCustomerInfoSystem.EActionCommands.LookupAvailableProduct.name(), actionListener),
				new LinkButton("�Ǹ� Ȱ�� ��ȸ", ShowCustomerInfoSystem.EActionCommands.WatchActivityPlan.name(), actionListener),
				new LinkButton("���� Ȱ�� ��ȸ", ShowCustomerInfoSystem.EActionCommands.WatchSalesTrainingPlan.name(), actionListener)
		);
	}

	private String printline(CustomerData customerData) {
		String returnVal ="";
		String name =customerData.getName();
		String gender = customerData.isMale() ? "��": "��";
		String age = Integer.toString(customerData.getAge());
		String socialSecNum = customerData.getSocialSecurityNum().substring(0, 8);
		returnVal = name+" �� ("+gender+", "+age+"��, "+socialSecNum+")";
		return returnVal;
	}
}
