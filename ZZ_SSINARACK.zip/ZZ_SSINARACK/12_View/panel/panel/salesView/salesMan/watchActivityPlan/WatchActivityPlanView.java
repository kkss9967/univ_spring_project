package panel.panel.salesView.salesMan.watchActivityPlan;

import java.awt.Color;

import component.button.LinkButton;
import component.button.SelectButton;
import component.etc.SeparateLine;
import component.group.DynamicGroup;
import component.label.BasicLabel;
import model.table.Table_LV0;
import panel.Panel_LV2.Panel_LV2;
import panel.aConstant.InsuranceSystemViewConstant;
import panel.panelInterface.sales.SalesMan.WatchActivityPlan.IntWatchActivityPlanView;
import sales.salesManAspect.WatchActivityPlan.WatchActivityPlanSystem;
import specificModel.data.activityPlanData.ActivityPlanData;

public class WatchActivityPlanView extends Panel_LV2 implements IntWatchActivityPlanView  {
	private static final long serialVersionUID = 1L;


	// Attribute
	private Table_LV0<ActivityPlanData> activityPlanList;
	
	@Override public void setActivityPlanList(Table_LV0<ActivityPlanData> activityPlanList) {this.activityPlanList = activityPlanList;}
	
	@Override
	public void start() {
		// add component
		this.addComponent(new BasicLabel("Ȱ�� ��ȹ ��ȸ"));
		this.addComponent(new SeparateLine(Color.black));

		DynamicGroup selectBtnGroup = new DynamicGroup();
		for (ActivityPlanData data : activityPlanList.getList()) {
			selectBtnGroup.addGroupComponent(new SelectButton(data.getTitle(), Integer.toString(data.getID()), actionListener));
		}
		this.addComponent(selectBtnGroup);
		this.addToLinkPanel(
				new LinkButton(InsuranceSystemViewConstant.SomeThingLookGreat, "", null),
	            new LinkButton(InsuranceSystemViewConstant.SomeThingLookNide, "", null),
				new LinkButton("���� ����", WatchActivityPlanSystem.EActionCommands.SigninCustomer.name(), actionListener),
				new LinkButton("���� ���� ��ȸ", WatchActivityPlanSystem.EActionCommands.LookupAvailableProduct.name(), actionListener),
				new LinkButton("�Ǹ� Ȱ�� ��ȸ", WatchActivityPlanSystem.EActionCommands.WatchActivityPlan.name(), actionListener),
				new LinkButton("���� Ȱ�� ��ȸ", WatchActivityPlanSystem.EActionCommands.WatchSalesTrainingPlan.name(), actionListener)
		);
	}
}
