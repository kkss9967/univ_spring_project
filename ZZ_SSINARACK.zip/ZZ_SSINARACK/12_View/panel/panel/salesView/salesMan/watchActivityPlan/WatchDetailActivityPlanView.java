package panel.panel.salesView.salesMan.watchActivityPlan;

import java.awt.Color;

import javax.swing.JLabel;

import component.button.LinkButton;
import component.etc.SeparateLine;
import component.label.BasicLabel;
import component.textArea.OutputTextArea;
import model.table.Table_LV0;
import panel.Panel_LV2.Panel_LV2;
import panel.aConstant.InsuranceSystemViewConstant;
import panel.panelInterface.sales.SalesMan.WatchActivityPlan.IntWatchDetailActivityPlanView;
import sales.salesManAspect.WatchActivityPlan.WatchDetailActivityPlanSystem;
import specificModel.data.activityPlanData.ActivityPlanData;

public class WatchDetailActivityPlanView extends Panel_LV2 implements IntWatchDetailActivityPlanView{
	private static final long serialVersionUID = 1L;

	// Attribute
	private int activityPlanID;
	private Table_LV0<ActivityPlanData> activityPlanList;

	@Override public void setActivityPlanID(int activityPlanID) {this.activityPlanID=activityPlanID;}
	@Override public void setActivityPlanList(Table_LV0<ActivityPlanData> activityPlanList) {this.activityPlanList=activityPlanList;}

	
	@Override
	public void start() {

		ActivityPlanData watchingActivityPlanData = activityPlanList.search(activityPlanID);

		// add component
		this.addComponent(new BasicLabel("���� Ȱ�� ��ȹ ����"));
		this.addComponent(new SeparateLine(Color.black));

		this.addComponent(new JLabel("��ȸ�Ͻ� Ȱ�� ��ȹ�� ���� �����Դϴ�."));
		this.addComponent(new OutputTextArea("����",  watchingActivityPlanData.getTitle()));
		this.addComponent(new OutputTextArea("��¥",  watchingActivityPlanData.getSalesDuration()));
		this.addComponent(new OutputTextArea("��ü ���� ��ǥ",  Integer.toString(watchingActivityPlanData.getSalesGoal())));
		this.addComponent(new OutputTextArea("��ü Ȱ����ǥ",  watchingActivityPlanData.getActivityGoal()));
		this.addComponent(new OutputTextArea("�߰� ���� �ʿ䷮ ", Integer.toString(watchingActivityPlanData.getAdditionalJobOffer())));
		this.addComponent(new OutputTextArea("�ַ� ���� ���� ", watchingActivityPlanData.getSalesTargetCustomer().toString()));

		this.addToLinkPanel(
				new LinkButton(InsuranceSystemViewConstant.SomeThingLookGreat, "", null),
	            new LinkButton(InsuranceSystemViewConstant.SomeThingLookNide, "", null),
				new LinkButton("���� ����", WatchDetailActivityPlanSystem.EActionCommands.SigninCustomer.name(), actionListener),
				new LinkButton("���� ���� ��ȸ", WatchDetailActivityPlanSystem.EActionCommands.LookupAvailableProduct.name(), actionListener),
				new LinkButton("�Ǹ� Ȱ�� ��ȸ", WatchDetailActivityPlanSystem.EActionCommands.WatchActivityPlan.name(), actionListener),
				new LinkButton("���� Ȱ�� ��ȸ", WatchDetailActivityPlanSystem.EActionCommands.WatchSalesTrainingPlan.name(), actionListener)
		);
	}
}
