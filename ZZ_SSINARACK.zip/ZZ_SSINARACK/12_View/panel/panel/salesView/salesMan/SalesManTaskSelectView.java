package panel.panel.salesView.salesMan;

import java.awt.Color;

import component.button.LinkButton;
import component.button.SelectButton;
import component.etc.SeparateLine;
import component.group.StaticGroup;
import component.label.BasicLabel;
import panel.Panel_LV2.Panel_LV2;
import panel.aConstant.InsuranceSystemViewConstant;
import panel.panelInterface.sales.SalesMan.IntSalesManTaskSelectView;
import sales.salesManAspect.SalesManTaskSelectSystem;

@SuppressWarnings("serial")
public class SalesManTaskSelectView extends Panel_LV2 implements IntSalesManTaskSelectView{
	
	// Constructor
	public void start() {
		// add component
		this.addComponent(new BasicLabel("���Ͻô� ������ �����ϼ���."));
		this.addComponent(new SeparateLine(Color.black));
		
		StaticGroup g = new StaticGroup(new int[] {1,1,1,1});
		g.addGroupComponent(new SelectButton("���� ����", SalesManTaskSelectSystem.EActionCommands.SigninCustomer.name(), actionListener));
		g.addGroupComponent(new SelectButton("���� ���� ��ȸ", SalesManTaskSelectSystem.EActionCommands.LookupAvailableProduct.name(), actionListener));
		g.addGroupComponent(new SelectButton("�Ǹ� Ȱ�� ��ȸ", SalesManTaskSelectSystem.EActionCommands.WatchActivityPlan.name(), actionListener));
		g.addGroupComponent(new SelectButton("���� Ȱ�� ��ȸ", SalesManTaskSelectSystem.EActionCommands.WatchSalesTrainingPlan.name(), actionListener));
		this.addComponent(g);
		
		this.addToLinkPanel(
				new LinkButton(InsuranceSystemViewConstant.SomeThingLookGreat, "", null),
	            new LinkButton(InsuranceSystemViewConstant.SomeThingLookNide, "", null),
				new LinkButton("���� ����", SalesManTaskSelectSystem.EActionCommands.SigninCustomer.name(), actionListener),
				new LinkButton("���� ���� ��ȸ", SalesManTaskSelectSystem.EActionCommands.LookupAvailableProduct.name(), actionListener),
				new LinkButton("�Ǹ� Ȱ�� ��ȸ", SalesManTaskSelectSystem.EActionCommands.WatchActivityPlan.name(), actionListener),
				new LinkButton("���� Ȱ�� ��ȸ", SalesManTaskSelectSystem.EActionCommands.WatchSalesTrainingPlan.name(), actionListener)
		);
	}
}
