package panel.panel.salesView.salesMan.SigninCustomer;

import java.awt.Color;

import component.button.ActionButton;
import component.button.LinkButton;
import component.button.TitledRadioButtonGroup;
import component.etc.SeparateLine;
import component.group.StaticGroup;
import component.label.BasicLabel;
import component.textArea.InputTextArea;
import panel.Panel_LV2.Panel_LV2;
import panel.aConstant.InsuranceSystemViewConstant;
import panel.panelInterface.sales.SalesMan.SignInCustomer.IntSigninCustomerView;
import sales.salesManAspect.SigninCustomer.SinginCustomerSystem;
import specificModel.enums.EAccidentHistory;
import specificModel.enums.EFamilyIllHistory;
import specificModel.enums.EGender;

public class SigninCustomerView extends Panel_LV2 implements IntSigninCustomerView{
	private static final long serialVersionUID = 1L;

	// Component
	private InputTextArea nameTTA, residenceTTA,phoneNumTTA,emailTTA,socialSecurityNumTTA,jobTTA,propertyTTA,ageTTA,accountNumTTA,loginIDTTA,loginPWTTA;
	private TitledRadioButtonGroup familyillhistoryRBN,genderRBN,accidentHistoryRBN;
	
	// Constructor
	public void start() {
		//create component
		this.nameTTA = new InputTextArea("�̸�", "������", 1, 100);
		this.residenceTTA = new InputTextArea("������", "���빮�� 65-2", 1, 100);
		this.phoneNumTTA = new InputTextArea("��ȭ��ȣ", "010-3333-4664", 1, 100);
		this.emailTTA = new InputTextArea("�̸���", "cosla@gmail.com", 1, 100);
		this.familyillhistoryRBN = new TitledRadioButtonGroup("������", EFamilyIllHistory.class, true,100);
		this.socialSecurityNumTTA = new InputTextArea("�ֹι�ȣ", "900922-1248150", 1, 100);
		this.genderRBN = new TitledRadioButtonGroup("����", EGender.class, false,100);
		this.jobTTA = new InputTextArea("����", "�л�", 1, 100);
		this.propertyTTA = new InputTextArea("���", "10000000", 1, 100);
		this.accidentHistoryRBN = new TitledRadioButtonGroup("��� �̷�", EAccidentHistory.class, true,100);
		this.ageTTA = new InputTextArea("����", "30", 1, 100);
		this.accountNumTTA = new InputTextArea("���¹�ȣ", "123-456-789012", 1, 100);
		this.loginIDTTA = new InputTextArea("���̵�", "asd", 1, 100);
		this.loginPWTTA = new InputTextArea("��й�ȣ", "123", 1, 100);

		//add component
		this.addComponent(new BasicLabel("���� ���� �Է�"));
		this.addComponent(new SeparateLine(Color.black));
		
		StaticGroup g =  new StaticGroup(new int[] {2,2,1,1,2,1,1,2,2});
		g.addGroupComponent(
				this.nameTTA,this.socialSecurityNumTTA,
				this.ageTTA,this.jobTTA,
				this.genderRBN,
				this.residenceTTA,
				this.phoneNumTTA,this.emailTTA, 
				this.familyillhistoryRBN,
				this.accidentHistoryRBN,
				this.propertyTTA,this.accountNumTTA,
				this.loginIDTTA,this.loginPWTTA
				);
		this.addComponent(g);
		
		this.addComponent(new ActionButton("����", SinginCustomerSystem.EActionCommands.Save.name(), actionListener));

		this.addToLinkPanel(
				new LinkButton(InsuranceSystemViewConstant.SomeThingLookGreat, "", null),
	            new LinkButton(InsuranceSystemViewConstant.SomeThingLookNide, "", null),
				new LinkButton("���� ����", SinginCustomerSystem.EActionCommands.SigninCustomer.name(), actionListener),
				new LinkButton("���� ���� ��ȸ", SinginCustomerSystem.EActionCommands.LookupAvailableProduct.name(), actionListener),
				new LinkButton("�Ǹ� Ȱ�� ��ȸ", SinginCustomerSystem.EActionCommands.WatchActivityPlan.name(), actionListener),
				new LinkButton("���� Ȱ�� ��ȸ", SinginCustomerSystem.EActionCommands.WatchSalesTrainingPlan.name(), actionListener)
		);
	}

	//get & set
	public InputTextArea getNameTTA() {return this.nameTTA;}
	public void setNameTTA(InputTextArea nameTTA) {	this.nameTTA = nameTTA;}
	public InputTextArea getResidenceTTA() {return this.residenceTTA;}
	public void setResidenceTTA(InputTextArea residenceTTA) {this.residenceTTA = residenceTTA;}
	public InputTextArea getPhoneNumTTA() {return this.phoneNumTTA;}
	public void setPhoneNumTTA(InputTextArea phoneNumTTA) {this.phoneNumTTA = phoneNumTTA;}
	public InputTextArea getEmailTTA() {return this.emailTTA;}
	public void setEmailTTA(InputTextArea emailTTA) {this.emailTTA = emailTTA;}
	public InputTextArea getSocialSecurityNumTTA() {return this.socialSecurityNumTTA;}
	public void setSocialSecurityNumTTA(InputTextArea socialSecurityNumTTA) {this.socialSecurityNumTTA = socialSecurityNumTTA;}
	public InputTextArea getJobTTA() {return this.jobTTA;}
	public void setJobTTA(InputTextArea jobTTA) {this.jobTTA = jobTTA;}
	public InputTextArea getPropertyTTA() {return this.propertyTTA;}
	public void setPropertyTTA(InputTextArea propertyTTA) {this.propertyTTA = propertyTTA;}
	public InputTextArea getAgeTTA() {return this.ageTTA;}
	public void setAgeTTA(InputTextArea ageTTA) {this.ageTTA = ageTTA;}
	public InputTextArea getAccountNumTTA() {return this.accountNumTTA;}
	public void setAccountNumTTA(InputTextArea accountNumTTA) {this.accountNumTTA = accountNumTTA;}
	public InputTextArea getLoginIDTTA() {return this.loginIDTTA;}
	public void setLoginIDTTA(InputTextArea loginIDTTA) {this.loginIDTTA = loginIDTTA;}
	public InputTextArea getLoginPWTTA() {return this.loginPWTTA;}
	public void setLoginPWTTA(InputTextArea loginPWTTA) {this.loginPWTTA = loginPWTTA;}
	public TitledRadioButtonGroup getFamilyillhistoryRBN() {return this.familyillhistoryRBN;}
	public void setFamilyillhistoryRBN(TitledRadioButtonGroup familyillhistoryRBN) {this.familyillhistoryRBN = familyillhistoryRBN;}
	public TitledRadioButtonGroup getGenderRBN() {return this.genderRBN;}
	public void setGenderRBN(TitledRadioButtonGroup genderRBN) {this.genderRBN = genderRBN;	}
	public TitledRadioButtonGroup getAccidentHistoryRBN() {return this.accidentHistoryRBN;}
	public void setAccidentHistoryRBN(TitledRadioButtonGroup accidentHistoryRBN) {this.accidentHistoryRBN = accidentHistoryRBN;}


}