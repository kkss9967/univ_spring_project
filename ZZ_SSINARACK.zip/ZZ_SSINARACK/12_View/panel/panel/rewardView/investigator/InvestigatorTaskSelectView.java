package panel.panel.rewardView.investigator;

import java.awt.Color;

import component.button.LinkButton;
import component.button.SelectButton;
import component.etc.SeparateLine;
import component.group.DynamicGroup;
import component.label.BasicLabel;
import component.textArea.OutputTextArea;
import model.table.Table_LV0;
import panel.Panel_LV2.Panel_LV2;
import panel.aConstant.InsuranceSystemViewConstant;
import panel.panelInterface.reward.IntInvestigatorTaskSelectView;
import specificModel.data.employeeData.rewardEmployeeData.AccidentInvestigatorData;
import specificModel.data.rewardData.AccidentData;
import specificModel.data.rewardData.RewardData;
import specificModel.data.taskData.rewardTask.AccidentInvestigationTask;

@SuppressWarnings("serial")
public class InvestigatorTaskSelectView extends Panel_LV2 implements IntInvestigatorTaskSelectView{

	public void start() {
		
		this.addComponent(new BasicLabel("��� ���� ��� ����"));
		this.addComponent(new SeparateLine(Color.black));
		
		if(user.getTaskList().getList().size()==0) {
			this.addComponent(new OutputTextArea("ó���� ������ �����ϴ�.", ""));
		}else {
			DynamicGroup selectBtnGroup = new DynamicGroup();
			for(AccidentInvestigationTask task : user.getTaskList().getList()) {
				RewardData rewardData = rewardDataList.search(task.getRewardDataID());
				AccidentData accidentData = rewardData.getAccidentData();
				selectBtnGroup.addGroupComponent(new SelectButton(accidentData.getType(), Integer.toString(task.getID()), actionListener));
			}
			this.addComponent(selectBtnGroup);
		}	
		this.addToLinkPanel(
				new LinkButton(InsuranceSystemViewConstant.SomeThingLookGreat, "", null),
	            new LinkButton(InsuranceSystemViewConstant.SomeThingLookNide, "", null)
		);
	}

	private AccidentInvestigatorData user;
	@Override public void setUser(AccidentInvestigatorData user) {this.user=user;}		

	private Table_LV0<RewardData> rewardDataList;
	@Override public void setRewardDataList(Table_LV0<RewardData> rewardDataList) {this.rewardDataList=rewardDataList;}
}
