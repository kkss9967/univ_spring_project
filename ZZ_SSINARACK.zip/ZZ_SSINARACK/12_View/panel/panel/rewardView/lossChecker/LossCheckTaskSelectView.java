package panel.panel.rewardView.lossChecker;

import java.awt.Color;

import component.button.LinkButton;
import component.button.SelectButton;
import component.etc.SeparateLine;
import component.group.DynamicGroup;
import component.label.BasicLabel;
import component.textArea.OutputTextArea;
import model.table.Table_LV0;
import panel.Panel_LV2.Panel_LV2;
import panel.aConstant.InsuranceSystemViewConstant;
import panel.panelInterface.reward.IntLossCheckTaskSelectView;
import specificModel.data.employeeData.rewardEmployeeData.LossCheckManData;
import specificModel.data.rewardData.PayJudgeData;
import specificModel.data.rewardData.RewardData;
import specificModel.data.taskData.rewardTask.LossCheckTask;

@SuppressWarnings("serial")
public class LossCheckTaskSelectView extends Panel_LV2 implements IntLossCheckTaskSelectView{

	public void start() {
		
		this.addComponent(new BasicLabel("���ػ����� ������ ���� ����� �����ϼ���"));
		this.addComponent(new SeparateLine(Color.black));
		
		if(user.getTaskList().getList().size()==0) {
			this.addComponent(new OutputTextArea("ó���� ������ �����ϴ�.", ""));
		}else {
			DynamicGroup selectBtnGroup = new DynamicGroup();
			for(LossCheckTask lossCheckData : user.getTaskList().getList()) {
				RewardData rewardData = rewardDataList.search(lossCheckData.getRewardDataID());
				PayJudgeData payJudgeData = rewardData.getPayJudgeData();
				selectBtnGroup.addGroupComponent(new SelectButton(payJudgeData.getPayJudge(), Integer.toString(lossCheckData.getID()), actionListener));
			}
			this.addComponent(selectBtnGroup);
		}
		this.addToLinkPanel(
				new LinkButton(InsuranceSystemViewConstant.SomeThingLookGreat, "", null),
	            new LinkButton(InsuranceSystemViewConstant.SomeThingLookNide, "", null)
		);
	}
	
	private LossCheckManData user;
	@Override public void setUser(LossCheckManData user) {this.user=user;}		

	private Table_LV0<RewardData> rewardDataList;
	@Override public void setRewardDataList(Table_LV0<RewardData> rewardDataList) {this.rewardDataList=rewardDataList;}
}
