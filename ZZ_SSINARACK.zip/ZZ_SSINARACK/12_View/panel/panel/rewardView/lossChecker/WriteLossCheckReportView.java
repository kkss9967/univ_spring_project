package panel.panel.rewardView.lossChecker;

import java.awt.Color;

import component.button.ActionButton;
import component.button.LinkButton;
import component.etc.SeparateLine;
import component.group.StaticGroup;
import component.label.BasicLabel;
import component.textArea.InputTextArea;
import panel.Panel_LV2.Panel_LV2;
import panel.aConstant.InsuranceSystemViewConstant;
import panel.panelInterface.reward.IntWriteLossCheckReportView;
import reward.lossCheckManAspect.WriteLossCheckReportControl;

@SuppressWarnings("serial")
public class WriteLossCheckReportView extends Panel_LV2 implements IntWriteLossCheckReportView {

	// Attribute
	private InputTextArea payTTA, judgeEvidenceTTA;

	public void start() {
		
		this.addComponent(new BasicLabel("���ػ��� ��� �Է�"));
		this.addComponent(new SeparateLine(Color.black));
		
		this.payTTA = new InputTextArea("���� �����", "3000000", 1, 100);
		this.judgeEvidenceTTA = new InputTextArea("�Ǵ� �ٰ�", "�ڵ��� ������� ������ ���� ������ �����Ѵ�.", 5, 100);

		StaticGroup selectBtnGroup = new StaticGroup(new int[] {1, 1});
		selectBtnGroup.addGroupComponent(this.payTTA, this.judgeEvidenceTTA);
		this.addComponent(selectBtnGroup);
		
		this.addComponent(new ActionButton("����", WriteLossCheckReportControl.EActionCommands.SaveLossCheckData.name(), actionListener));

		this.addToLinkPanel(
				new LinkButton(InsuranceSystemViewConstant.SomeThingLookGreat, "", null),
	            new LinkButton(InsuranceSystemViewConstant.SomeThingLookNide, "", null)	
		);
	}

	// Getter & Setter
	public String getPayTTA() {return payTTA.getContent();}
	public String getJudgeEvidenceTTA() {return judgeEvidenceTTA.getContent();}

}
