package panel.panel.rewardView.lawyer;

import java.awt.Color;

import component.button.ActionButton;
import component.button.LinkButton;
import component.etc.SeparateLine;
import component.group.StaticGroup;
import component.label.BasicLabel;
import component.textArea.InputTextArea;
import panel.Panel_LV2.Panel_LV2;
import panel.aConstant.InsuranceSystemViewConstant;
import panel.panelInterface.reward.IntWriteSueReportView;
import reward.lawyerAspect.WriteSueReportControl;

@SuppressWarnings("serial")
public class WriteSueReportView extends Panel_LV2 implements IntWriteSueReportView{

	// Attribute
	private InputTextArea payTTA;
	
	public void start() {
		
		this.addComponent(new BasicLabel("�Ҽ� ��� �Է�"));
		this.addComponent(new SeparateLine(Color.black));
		
		this.payTTA = new InputTextArea("���� �����", "100", 1, 100);
	
		StaticGroup selectBtnGroup = new StaticGroup(new int[] {1});
		selectBtnGroup.addGroupComponent(this.payTTA);
		this.addComponent(selectBtnGroup);
		
		this.addComponent(new ActionButton("����", WriteSueReportControl.EActionCommands.SaveLawsuitData.name(), actionListener));

		this.addToLinkPanel(
				new LinkButton(InsuranceSystemViewConstant.SomeThingLookGreat, "", null),
	            new LinkButton(InsuranceSystemViewConstant.SomeThingLookNide, "", null)	
		);
	}

	// Getter & Setter
	public String getPayTTA() {return payTTA.getContent();}
}
