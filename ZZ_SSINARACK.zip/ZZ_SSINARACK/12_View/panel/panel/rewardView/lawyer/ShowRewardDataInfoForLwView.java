package panel.panel.rewardView.lawyer;

import java.awt.Color;

import component.button.ActionButton;
import component.button.LinkButton;
import component.etc.SeparateLine;
import component.label.BasicLabel;
import component.textArea.OutputTextArea;
import model.table.Table_LV0;
import panel.Panel_LV2.Panel_LV2;
import panel.aConstant.InsuranceSystemViewConstant;
import panel.panelInterface.reward.IntShowRewardDataInfoForLwView;
import reward.lawyerAspect.ShowRewardDataInfoForLwControl;
import specificModel.data.employeeData.rewardEmployeeData.LawyerData;
import specificModel.data.rewardData.AccidentData;
import specificModel.data.rewardData.AccidentInvestigationData;
import specificModel.data.rewardData.LossCheckData;
import specificModel.data.rewardData.PayJudgeData;
import specificModel.data.rewardData.RewardData;

@SuppressWarnings("serial")
public class ShowRewardDataInfoForLwView extends Panel_LV2 implements IntShowRewardDataInfoForLwView{

	public void start(){
		
		RewardData rewardData = rewardDataList.search(user.getTaskList().search(taskID).getRewardDataID());
		AccidentData accidentData = rewardData.getAccidentData();
		AccidentInvestigationData accidentInvestigationData = rewardData.getAccidentInvestigationData();
		PayJudgeData payJudgeData = rewardData.getPayJudgeData();
		LossCheckData lossCheckData = rewardData.getLossData();
		
		this.addComponent(new BasicLabel("��û�Ͻ� ��� ������ �Դϴ�."));
		this.addComponent(new SeparateLine(Color.black));

		this.addComponent(new OutputTextArea("��� ����", accidentData.getType()));
		this.addComponent(new OutputTextArea("��� ��ġ", accidentData.getLocation()));
		this.addComponent(new OutputTextArea("��� �ð�", accidentData.getDate()));

		this.addComponent(new BasicLabel("��û�Ͻ� ��� ���� ������ �Դϴ�."));
		this.addComponent(new SeparateLine(Color.black));

		this.addComponent(new OutputTextArea("��� �ó�����", accidentInvestigationData.getScenario()));
		this.addComponent(new OutputTextArea("����", accidentInvestigationData.getDamage()));
		this.addComponent(new OutputTextArea("��� ó��", accidentInvestigationData.getTreatment()));
		this.addComponent(new OutputTextArea("��� ó�� ���", Integer.toString(accidentInvestigationData.getTreatmentCost())));
		
		this.addComponent(new BasicLabel("��û�Ͻ� ��/��å �Ǵ� ������ �Դϴ�."));
		this.addComponent(new SeparateLine(Color.black));

		this.addComponent(new OutputTextArea("��/��å ���", payJudgeData.getPayJudge()));
		this.addComponent(new OutputTextArea("��/��å �ٰ�", payJudgeData.getJudgementEvidence()));
		this.addComponent(new OutputTextArea("���� ����", payJudgeData.getRelatedLaw()));	

		this.addComponent(new BasicLabel("��û�Ͻ� ���ػ��� ������ �Դϴ�."));
		this.addComponent(new SeparateLine(Color.black));

		this.addComponent(new OutputTextArea("���� �����", Integer.toString(lossCheckData.getPay())));
		this.addComponent(new OutputTextArea("�Ǵ� �ٰ�", lossCheckData.getJudgeEvidence()));
		this.addComponent(new ActionButton("�Ҽ� ��� �Է�", ShowRewardDataInfoForLwControl.EActionCommands.writeSueReport.name(), actionListener));
		
		this.addToLinkPanel(
				new LinkButton(InsuranceSystemViewConstant.SomeThingLookGreat, "", null),
	            new LinkButton(InsuranceSystemViewConstant.SomeThingLookNide, "", null)			);
	}

	private LawyerData user;
	@Override public void setUser(LawyerData user) {this.user=user;}		

	private int taskID;
	@Override public void setTaskId(int taskID) {this.taskID=taskID;}

	private Table_LV0<RewardData> rewardDataList;
	@Override public void setRewardDataList(Table_LV0<RewardData> rewardDataList) {this.rewardDataList=rewardDataList;}
}
