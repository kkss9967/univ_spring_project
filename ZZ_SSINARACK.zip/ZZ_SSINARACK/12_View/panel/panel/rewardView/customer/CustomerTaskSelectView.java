package panel.panel.rewardView.customer;

import java.awt.Color;

import component.button.LinkButton;
import component.button.SelectButton;
import component.etc.SeparateLine;
import component.group.StaticGroup;
import component.label.BasicLabel;
import panel.Panel_LV2.Panel_LV2;
import panel.aConstant.InsuranceSystemViewConstant;
import panel.panelInterface.reward.IntCustomerTaskSelectView;
import reward.customerAspect.CustomerTaskSelectControl;

@SuppressWarnings("serial")
public class CustomerTaskSelectView extends Panel_LV2 implements IntCustomerTaskSelectView{
	
	// Constructor
	public void start() {
		this.addComponent(new BasicLabel("���Ͻô� ���񽺸� �����ϼ���."));
		this.addComponent(new SeparateLine(Color.black));

		StaticGroup selectBtnGroup = new StaticGroup(new int[] {1,1});
		selectBtnGroup.addGroupComponent(new SelectButton("��� ����", CustomerTaskSelectControl.EActionCommands.AccidentProcessApply.name(), actionListener));
		selectBtnGroup.addGroupComponent(new SelectButton("����� ���� Ȯ��", CustomerTaskSelectControl.EActionCommands.isPaymentAgree.name(), actionListener));
		this.addComponent(selectBtnGroup);

		this.addToLinkPanel(
				new LinkButton(InsuranceSystemViewConstant.SomeThingLookGreat, "", null),
	            new LinkButton(InsuranceSystemViewConstant.SomeThingLookNide, "", null)
		);
	}
}
