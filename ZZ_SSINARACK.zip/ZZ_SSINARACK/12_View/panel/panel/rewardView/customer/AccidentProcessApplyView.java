package panel.panel.rewardView.customer;

import java.awt.Color;

import component.button.ActionButton;
import component.button.LinkButton;
import component.etc.SeparateLine;
import component.group.StaticGroup;
import component.label.BasicLabel;
import component.textArea.InputTextArea;
import panel.Panel_LV2.Panel_LV2;
import panel.aConstant.InsuranceSystemViewConstant;
import panel.panelInterface.reward.IntAccidentProcessApplyView;
import reward.customerAspect.accidentProcessApply.AccidentProcessApplyControl;

@SuppressWarnings("serial")
public class AccidentProcessApplyView extends Panel_LV2 implements IntAccidentProcessApplyView{

	// Component
	private InputTextArea accidentTypeTTA, accidentLocationTTA, accidentDateTTA;
	
	// Constructor
	public void start() {
		
		this.addComponent(new BasicLabel("��� ���� �Է�"));
		this.addComponent(new SeparateLine(Color.black));
		
		this.accidentTypeTTA = new InputTextArea("��� ����", "�ڵ��� ���� ���", 2, 100);
		this.accidentLocationTTA = new InputTextArea("��� ��ġ", "���￪ �� Ⱦ�ܺ���", 5, 100);
		this.accidentDateTTA = new InputTextArea("��� �ð�", "10�� ��",  2, 100);
		
		StaticGroup selectBtnGroup = new StaticGroup(new int[] {1, 1, 1});
		selectBtnGroup.addGroupComponent(this.accidentTypeTTA, this.accidentLocationTTA, this.accidentDateTTA);
		this.addComponent(selectBtnGroup);
		
		this.addComponent(new ActionButton("����", AccidentProcessApplyControl.EActionCommands.SaveAccidentData.name(), actionListener));
		
		this.addToLinkPanel (
				new LinkButton(InsuranceSystemViewConstant.SomeThingLookGreat, "", null),
	            new LinkButton(InsuranceSystemViewConstant.SomeThingLookNide, "", null)
		);
	}

	// Getter & Setter
	public String getAccidentType() {return this.accidentTypeTTA.getContent();}
	public String getAccidentLocation() {return this.accidentLocationTTA.getContent();}
	public String getAccidentDate() {return this.accidentDateTTA.getContent();}

}
