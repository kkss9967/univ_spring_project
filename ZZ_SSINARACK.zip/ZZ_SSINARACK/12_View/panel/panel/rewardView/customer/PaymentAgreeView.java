package panel.panel.rewardView.customer;

import java.awt.Color;

import component.button.ActionButton;
import component.button.LinkButton;
import component.etc.SeparateLine;
import component.group.StaticGroup;
import component.label.BasicLabel;
import component.textArea.OutputTextArea;
import panel.Panel_LV2.Panel_LV2;
import panel.aConstant.InsuranceSystemViewConstant;
import panel.panelInterface.reward.IntPaymentAgreeView;
import reward.customerAspect.paymentAgree.PaymentAgreeControl;
import specificModel.data.rewardData.LossCheckData;
import specificModel.data.rewardData.RewardData;

@SuppressWarnings("serial")
public class PaymentAgreeView extends Panel_LV2 implements IntPaymentAgreeView{

	// Constructor
	public void start() {
		
		RewardData rewardData = reward;
		LossCheckData lossCheckData = rewardData.getLossData();
		this.addComponent(new BasicLabel("����� ���� ���θ� �Է����ּ���."));
		this.addComponent(new SeparateLine(Color.black));
		
		this.addComponent(new OutputTextArea("���� �����", Integer.toString(lossCheckData.getPay())));
		this.addComponent(new OutputTextArea("�Ǵ� �ٰ�", lossCheckData.getJudgeEvidence()));
		
		StaticGroup btnGroup = new StaticGroup(new int[] {2});
		btnGroup.addGroupComponent(new ActionButton("����", PaymentAgreeControl.EActionCommands.Permit.name(), actionListener));
		btnGroup.addGroupComponent(new ActionButton("����", PaymentAgreeControl.EActionCommands.Ban.name(), actionListener));
		this.addComponent(btnGroup);
		
		this.addToLinkPanel(
				new LinkButton(InsuranceSystemViewConstant.SomeThingLookGreat, "", null),
	            new LinkButton(InsuranceSystemViewConstant.SomeThingLookNide, "", null)
			);
	}

	private RewardData reward;
	@Override public void setRewardData(RewardData reward) {this.reward=reward;}
}
