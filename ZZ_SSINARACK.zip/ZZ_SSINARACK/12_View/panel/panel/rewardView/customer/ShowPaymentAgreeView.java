package panel.panel.rewardView.customer;

import java.awt.Color;

import component.button.LinkButton;
import component.button.SelectButton;
import component.etc.SeparateLine;
import component.group.DynamicGroup;
import component.label.BasicLabel;
import component.textArea.InputTextArea;
import model.table.Table_LV0;
import panel.Panel_LV2.Panel_LV2;
import panel.aConstant.InsuranceSystemViewConstant;
import panel.panelInterface.reward.IntShowPaymentAgreeView;
import specificModel.data.customerData.CustomerData;
import specificModel.data.rewardData.AccidentData;
import specificModel.data.rewardData.RewardData;
import specificModel.data.taskData.rewardTask.PayAgreementTask;

@SuppressWarnings("serial")
public class ShowPaymentAgreeView extends Panel_LV2 implements IntShowPaymentAgreeView {
	
	// Component
	private InputTextArea accidentTypeTTA, accidentLocationTTA, accidentDateTTA;		
	
	// Constructor
	public void start() {
		
		this.addComponent(new BasicLabel("����� ���� ���� ���� �����ϼ���"));
		this.addComponent(new SeparateLine(Color.black));
		
		DynamicGroup selectBtnGroup = new DynamicGroup();	
		for(PayAgreementTask payAgreementData : user.getTaskList().getList()) {
			RewardData rewardData = rewardDataList.search(payAgreementData.getRewardDataID());
			AccidentData accidentData = rewardData.getAccidentData();
			selectBtnGroup.addGroupComponent(new SelectButton(accidentData.getType(), Integer.toString(payAgreementData.getID()), actionListener));
		}	
		this.addComponent(selectBtnGroup);
		
		this.addToLinkPanel(
				new LinkButton(InsuranceSystemViewConstant.SomeThingLookGreat, "", null),
	            new LinkButton(InsuranceSystemViewConstant.SomeThingLookNide, "", null)
			);
	}
	
	// Getter & Setter
	public String getAccidentType() {return this.accidentTypeTTA.getContent();}
	public String getAccidentLocation() {return this.accidentLocationTTA.getContent();}
	public String getAccidentDate() {return this.accidentDateTTA.getContent();}

	private CustomerData user;
	@Override public void setUser(CustomerData user) {this.user=user;}		

	private Table_LV0<RewardData> rewardDataList;
	@Override public void setRewardDataList(Table_LV0<RewardData> rewardDataList) {this.rewardDataList=rewardDataList;}
}
