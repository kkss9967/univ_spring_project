package panel.panel.loginView;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.Box;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import component.button.ActionButton;
import component.etc.SeparateLine;
import component.group.StaticGroup;
import component.label.BasicLabel;
import component.textArea.InputTextArea;
import component.textArea.OutputTextArea;
import panel.Panel_LV2.Panel_LV2;
import panel.panelInterface.login.IntLoginPanel;

@SuppressWarnings("serial")
public class LoginView extends Panel_LV2 implements IntLoginPanel {

	// Static
	public enum EActionCommands {Login}
		
	// Component
	private InputTextArea idTTA, pwTTA;
	
	// Constructor
	public void start() {
		this.removeBackAndLogoutButton();
		
		this.addComponent(new BasicLabel("�α���"));
		this.addComponent(new SeparateLine(Color.black));
		
		this.idTTA = new InputTextArea("ID", "", 1, 50);
		this.pwTTA = new InputTextArea("PW", "123", 1, 50);
		StaticGroup textAreaGroup = new StaticGroup(new int[] {1,1});
		textAreaGroup.addGroupComponent(this.idTTA, this.pwTTA);
		this.addComponent(textAreaGroup);
		
		ActionButton loginBTN = new ActionButton("�α���", EActionCommands.Login.name(), actionListener);
		this.addComponent(loginBTN);
		
		this.addComponent((JComponent) Box.createVerticalStrut(225));
		
		this.addComponent(new SeparateLine(new Color(174,184, 193)));
		OutputTextArea idpwTextArea = new OutputTextArea("ID/PW", 
				"Developer : d / 123" +"\r\n"+
				"Insurance Rate Permit Man : i / 123"+"\r\n"+
				"Product Permit Man : p / 123"+"\r\n"+
				"Salesman : s / 123"+"\r\n"+
				"Sales Manager : ss / 123"+"\r\n"+
				"Accident Investigator : ai / 123"+"\r\n"+
				"Pay Judger : pj / 123"+"\r\n"+
				"Loss Checker : lc / 123"+"\r\n"+
				"lawer : ld / 123"
				);
		idpwTextArea.setComponentForeGround(new Color(162,163,162));
		this.addComponent(idpwTextArea);
		
		// Link Part
		this.setLinkPanelWidth(600);
		BufferedImage myPicture = null;
		try {myPicture = ImageIO.read(new File("16_Resource/view/panel/loginPanel/loginImage.png"));} catch (IOException e) {e.printStackTrace();}
		this.addToLinkPanel(new JLabel(new ImageIcon(myPicture)));
	}
	
	// Getter & Setter
	public String getId() {return this.idTTA.getContent();}
	public String getPw() {return this.pwTTA.getContent();}

	@Override
	public void showLoginFailed() {
		JOptionPane.showMessageDialog(this, "������ �����ϴ�.");
	}
}
