package panel.panel.developView.developer.developInsurance;

import java.awt.Color;

import component.button.LinkButton;
import component.button.SelectButton;
import component.etc.SeparateLine;
import component.group.StaticGroup;
import component.label.BasicLabel;
import develop.developerAspect.developInsurance.DevelopeInsuranceSelectControl;
import panel.Panel_LV2.Panel_LV2;
import panel.aConstant.InsuranceSystemViewConstant;
import panel.panelInterface.develop.IntDevelopInsuranceSelectView;

@SuppressWarnings("serial")
public class DevelopInsuranceSelectView extends Panel_LV2 implements IntDevelopInsuranceSelectView {

	public void start() {
		this.addComponent(new BasicLabel("���� ���� ����"));
		this.addComponent(new SeparateLine(Color.black));

		StaticGroup selectBtnGroup = new StaticGroup(new int[] {1,1,1});
		selectBtnGroup.addGroupComponent(new SelectButton("�ڵ��� ����", DevelopeInsuranceSelectControl.EActionCommands.CarInsurance.name(), actionListener));
		selectBtnGroup.addGroupComponent(new SelectButton("���� ����", DevelopeInsuranceSelectControl.EActionCommands.DiseaseInsurance.name(), actionListener));
		selectBtnGroup.addGroupComponent(new SelectButton("ȭ�� ����", DevelopeInsuranceSelectControl.EActionCommands.FireInsurance.name(), actionListener));
		this.addComponent(selectBtnGroup);

		this.addToLinkPanel(
				new LinkButton(InsuranceSystemViewConstant.SomeThingLookGreat, "", null),
				new LinkButton(InsuranceSystemViewConstant.SomeThingLookNide, "", null),
				new LinkButton("���� ����", DevelopeInsuranceSelectControl.EActionCommands.InsuranceDesign.name(), actionListener),
				new LinkButton("���� ���� Ȯ��", DevelopeInsuranceSelectControl.EActionCommands.WatchInsuranceData.name(), actionListener)
		);
	}
}
