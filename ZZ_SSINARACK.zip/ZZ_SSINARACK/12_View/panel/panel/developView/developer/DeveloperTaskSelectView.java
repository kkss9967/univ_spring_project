package panel.panel.developView.developer;

import java.awt.Color;

import component.button.LinkButton;
import component.button.SelectButton;
import component.etc.SeparateLine;
import component.group.StaticGroup;
import component.label.BasicLabel;
import develop.developerAspect.DeveloperTaskSelectControl;
import panel.Panel_LV2.Panel_LV2;
import panel.aConstant.InsuranceSystemViewConstant;
import panel.panelInterface.develop.IntDeveloperTaskSelectView;

@SuppressWarnings("serial")
public class DeveloperTaskSelectView extends Panel_LV2 implements IntDeveloperTaskSelectView {

	public void start() {
		this.addComponent(new BasicLabel("���� ����"));
		this.addComponent(new SeparateLine(Color.black));

		StaticGroup selectBtnGroup = new StaticGroup(new int[] {1,1});
		selectBtnGroup.addGroupComponent(new SelectButton("���� ����", DeveloperTaskSelectControl.EActionCommands.InsuranceDesign.name(), actionListener));
		selectBtnGroup.addGroupComponent(new SelectButton("���� ���� Ȯ��", DeveloperTaskSelectControl.EActionCommands.WatchInsuranceData.name(), actionListener));
		this.addComponent(selectBtnGroup);

		this.addToLinkPanel(
				new LinkButton(InsuranceSystemViewConstant.SomeThingLookGreat, "", null),
				new LinkButton(InsuranceSystemViewConstant.SomeThingLookNide, "", null),
				new LinkButton("���� ����", DeveloperTaskSelectControl.EActionCommands.InsuranceDesign.name(), actionListener),
				new LinkButton("���� ���� Ȯ��", DeveloperTaskSelectControl.EActionCommands.WatchInsuranceData.name(), actionListener)
		);
	}
}
