package panel.panel.developView.developer.showInsurance;

import java.awt.Color;

import component.button.LinkButton;
import component.button.SelectButton;
import component.button.TitledRadioButtonGroup;
import component.etc.SeparateLine;
import component.group.DynamicGroup;
import component.label.BasicLabel;
import component.textArea.InputTextArea;
import develop.developerAspect.showInsurance.SelecInsuranceToWatchControl;
import model.table.Table_LV0;
import panel.Panel_LV2.Panel_LV2;
import panel.aConstant.InsuranceSystemViewConstant;
import panel.panelInterface.develop.IntSelectInsuranceToWatchView;
import specificModel.data.insuranceData.AbsInsuranceData;

@SuppressWarnings("serial")
public class SelectInsuranceToWatchView extends Panel_LV2 implements IntSelectInsuranceToWatchView {

	// Component
	private InputTextArea nameTTA, contentTTA, insuranceRateInfoTTA, lossPercentTTA;
	private TitledRadioButtonGroup diseaseTRBG;

	private Table_LV0<AbsInsuranceData> insuranceList;
	@Override public void setAbsInsuranceDataList(Table_LV0<AbsInsuranceData> insuranceList) {this.insuranceList=insuranceList;}

	public void start() {
		this.addComponent(new BasicLabel("���� ����"));
		this.addComponent(new SeparateLine(Color.black));

		DynamicGroup selectBtnGroup = new DynamicGroup();
		for(AbsInsuranceData insuranceData : insuranceList.getList()) {
			selectBtnGroup.addGroupComponent(new SelectButton(insuranceData.getName(), Integer.toString(insuranceData.getID()), actionListener));
		}
		this.addComponent(selectBtnGroup);

		this.addToLinkPanel(
				new LinkButton(InsuranceSystemViewConstant.SomeThingLookGreat, "", null),
				new LinkButton(InsuranceSystemViewConstant.SomeThingLookNide, "", null),
				new LinkButton("���� ����", SelecInsuranceToWatchControl.EActionCommands.InsuranceDesign.name(), actionListener),
				new LinkButton("���� ���� Ȯ��", SelecInsuranceToWatchControl.EActionCommands.WatchInsuranceData.name(), actionListener)
		);
	}

	// Getter & Setter
	public String getName() {return this.nameTTA.getContent();}
	public String getContent() {return this.contentTTA.getContent();}
	public String getInsuranceRateInfo() {return this.insuranceRateInfoTTA.getContent();}
	public String getLossPercent() {return this.lossPercentTTA.getContent();}
	public String getDisease() {return this.diseaseTRBG.getSelectedOptionNames().get(0);}
}
