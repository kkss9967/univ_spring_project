package panel.panel.developView.developer.showInsurance;

import java.awt.Color;

import component.button.LinkButton;
import component.etc.SeparateLine;
import component.label.BasicLabel;
import component.textArea.OutputTextArea;
import develop.developerAspect.showInsurance.ShowInsuranceInfoControl;
import panel.Panel_LV2.Panel_LV2;
import panel.aConstant.InsuranceSystemViewConstant;
import panel.panelInterface.develop.IntShowInsuranceInfoView;
import specificModel.data.insuranceData.AbsInsuranceData;
import specificModel.data.insuranceData.realInsuranceData.DiseaseInsuranceData;

@SuppressWarnings("serial")
public class ShowInsuranceInfoView extends Panel_LV2 implements IntShowInsuranceInfoView {

	private AbsInsuranceData insuranceData;
	@Override public void setAbsInsuranceData(AbsInsuranceData insuranceData) {this.insuranceData=insuranceData;}

	public void start() {
		this.addComponent(new BasicLabel("���� ���� Ȯ��"));
		this.addComponent(new SeparateLine(Color.black));

		this.addComponent(new OutputTextArea("�̸�", insuranceData.getName()));
		this.addComponent(new OutputTextArea("������", Double.toString(insuranceData.getLossPercent())));
		if(insuranceData instanceof DiseaseInsuranceData) {
			this.addComponent(new OutputTextArea("���� ����", ((DiseaseInsuranceData)insuranceData).getDisease().name()));
		}
		this.addComponent(new OutputTextArea("����", insuranceData.getContent()));
		this.addComponent(new OutputTextArea("���� ����", insuranceData.getInsuranceRateInfo()));
		this.addComponent(new OutputTextArea("���� ���� ����", Boolean.toString(insuranceData.isInsuranceratePermit())));
		this.addComponent(new OutputTextArea("��ǰ �ΰ� ����", Boolean.toString(insuranceData.isProductPermit())));

		this.addToLinkPanel(
				new LinkButton(InsuranceSystemViewConstant.SomeThingLookGreat, "", null),
				new LinkButton(InsuranceSystemViewConstant.SomeThingLookNide, "", null),
				new LinkButton("���� ����", ShowInsuranceInfoControl.EActionCommands.InsuranceDesign.name(), actionListener),
				new LinkButton("���� ���� Ȯ��", ShowInsuranceInfoControl.EActionCommands.WatchInsuranceData.name(), actionListener)
		);
	}

}
