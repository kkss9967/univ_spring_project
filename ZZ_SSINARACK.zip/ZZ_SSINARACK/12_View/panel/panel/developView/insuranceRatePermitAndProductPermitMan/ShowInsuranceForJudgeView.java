package panel.panel.developView.insuranceRatePermitAndProductPermitMan;

import java.awt.Color;

import component.button.ActionButton;
import component.button.LinkButton;
import component.etc.SeparateLine;
import component.group.StaticGroup;
import component.label.BasicLabel;
import component.textArea.OutputTextArea;
import develop.insuranceRatePermitMan.ShowInsuranceForInsuranceRatePermitControl;
import panel.Panel_LV2.Panel_LV2;
import panel.aConstant.InsuranceSystemViewConstant;
import panel.panelInterface.develop.IntShowInsuranceForJudgeView;
import specificModel.data.insuranceData.AbsInsuranceData;
import specificModel.data.insuranceData.realInsuranceData.DiseaseInsuranceData;

@SuppressWarnings("serial")
public class ShowInsuranceForJudgeView extends Panel_LV2 implements IntShowInsuranceForJudgeView {

	private AbsInsuranceData insuranceData;
	@Override public void setInsuranceData(AbsInsuranceData insuranceData) {this.insuranceData=insuranceData;}

	public void start() {

		this.addComponent(new BasicLabel("���� ����"));
		this.addComponent(new SeparateLine(Color.black));

		this.addComponent(new OutputTextArea("�̸�", insuranceData.getName()));
		this.addComponent(new OutputTextArea("������", Double.toString(insuranceData.getLossPercent())));
		if(insuranceData instanceof DiseaseInsuranceData) {
			this.addComponent(new OutputTextArea("���� ����", ((DiseaseInsuranceData)insuranceData).getDisease().name()));
		}
		this.addComponent(new OutputTextArea("����", insuranceData.getContent()));
		this.addComponent(new OutputTextArea("���� ����", insuranceData.getInsuranceRateInfo()));

		StaticGroup btnGroup = new StaticGroup(new int[] {2});
		btnGroup.addGroupComponent(new ActionButton("�հ�", ShowInsuranceForInsuranceRatePermitControl.EActionCommands.Permit.name(), actionListener));
		btnGroup.addGroupComponent(new ActionButton("���հ�", ShowInsuranceForInsuranceRatePermitControl.EActionCommands.Ban.name(), actionListener));
		this.addComponent(btnGroup);

		this.addToLinkPanel(
				new LinkButton(InsuranceSystemViewConstant.SomeThingLookGreat, "", null),
				new LinkButton(InsuranceSystemViewConstant.SomeThingLookNide, "", null)
		);
	}
}
