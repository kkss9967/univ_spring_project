package panel.panel.developView.insuranceRatePermitAndProductPermitMan;

import java.awt.Color;

import component.button.LinkButton;
import component.button.SelectButton;
import component.etc.SeparateLine;
import component.group.DynamicGroup;
import component.label.BasicLabel;
import component.textArea.OutputTextArea;
import model.table.Table_LV0;
import panel.Panel_LV2.Panel_LV2;
import panel.aConstant.InsuranceSystemViewConstant;
import panel.panelInterface.develop.IntPermitTaskSelectView;
import specificModel.data.employeeData.AbsEmployeeData;
import specificModel.data.insuranceData.AbsInsuranceData;
import specificModel.data.taskData.developTask.InsurancePermitTask;

@SuppressWarnings("serial")
public class PermitTaskSelectView extends Panel_LV2 implements IntPermitTaskSelectView {

	private AbsEmployeeData<InsurancePermitTask> loginIRPM;
	@Override public void setInsurancePermitTask(AbsEmployeeData<InsurancePermitTask> loginIRPM) {this.loginIRPM=loginIRPM;}

	private Table_LV0<AbsInsuranceData> insuranceList;
	@Override public void setAbsInsuranceDataList(Table_LV0<AbsInsuranceData> insuranceList) {this.insuranceList=insuranceList;}

	public void start() {

		this.addComponent(new BasicLabel("���� ����"));
		this.addComponent(new SeparateLine(Color.black));

		if (loginIRPM.getTaskList().getList().size() == 0) {
			this.addComponent(new OutputTextArea("ó���� ������ �����ϴ�.", ""));
		} else {
			DynamicGroup selectBtnGroup = new DynamicGroup();
			for (InsurancePermitTask task : loginIRPM.getTaskList().getList()) {
				AbsInsuranceData insuranceData = insuranceList.search(task.getTargetInsuranceID());
				selectBtnGroup.addGroupComponent(new SelectButton(insuranceData.getName(), Integer.toString(task.getID()), actionListener));
			}
			this.addComponent(selectBtnGroup);
		}

		this.addToLinkPanel(
				new LinkButton(InsuranceSystemViewConstant.SomeThingLookGreat, "", null),
				new LinkButton(InsuranceSystemViewConstant.SomeThingLookNide, "", null)
		);
	}
}
