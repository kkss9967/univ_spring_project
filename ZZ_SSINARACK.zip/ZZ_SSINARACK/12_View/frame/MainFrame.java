package frame;

import view.frame.FrameAttribute;

@SuppressWarnings("serial")
public class MainFrame extends Frame_LV1 {
	
	public MainFrame() {
		super();
		this.setTitle(FrameAttribute.MainFrameTitle);
		this.getContentPane().setPreferredSize(FrameAttribute.MainFrameSize); this.pack(); // Set Frame Size By Set ContentPane Size
	}
}
