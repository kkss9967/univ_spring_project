package main;

import service.StartServiceAdapter;

public class Main {
	public static void main(String[] args) {
		StartServiceAdapter.StartService.start();
	}
}
