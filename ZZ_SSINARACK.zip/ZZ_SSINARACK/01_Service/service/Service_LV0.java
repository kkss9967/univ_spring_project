package service;

import common.IntCommon;

public interface Service_LV0 extends IntCommon {
	
	// Method
	public void startNewService(Service_LV0 service);
	public void startPreviousService();
	public void startFirstService();
	
	// Getter & Setter
	public void setPreviousService(Service_LV0 service);
}
