package service;

public abstract class Service_LV1 implements Service_LV0 {

	// Association
	private Service_LV0 previousService;
	
	@Override
	public void startNewService(Service_LV0 service) {
		this.end();
		service.start();
		service.setPreviousService(this);
	}

	@Override
	public void startPreviousService() {
		this.end();
		this.previousService.start();
	}

	@Override
	public void startFirstService() {
		if(this.previousService!=null) {
			this.end();
			this.previousService.startFirstService();
		}else {
			this.start();
		}
	}

	// Getter & Setter
	@Override public void setPreviousService(Service_LV0 service) {this.previousService=service;}
}
