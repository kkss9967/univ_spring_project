package service;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JPanel;

import frame.Frame_LV0;
import panel.Panel_LV0;
import view.component.button.BackButtonConfiguration;
import view.component.button.LogoutButtonConfiguration;
import view.frame.FrameAdapter;
import view.panel.PanelAdapter;

public abstract class Service_LV2 extends Service_LV1 {

	// Attribute
	private Frame_LV0 frame;
	private Panel_LV0 panel;
	
	// Constructor
	public Service_LV2 (FrameAdapter frameAdapter, PanelAdapter panelAdapter) {
		this.frame = frameAdapter.getFrame();
		this.panel = panelAdapter.getPanel();
	}
	@Override
	public void start() {
		this.panel.setActionListener(new ActionHandler());
		this.panel.start();
		this.frame.start();
		this.frame.showPanel((JPanel) this.panel);
	}
	@Override public void end() {this.panel.end();}
	
	// Abstract Method
	public abstract void processEvent(ActionEvent e);
	
	// Getter & Setter
	public Panel_LV0 getPanel() {return this.panel;}
	
	// Inner Class
	private class ActionHandler implements ActionListener {
		@Override public void actionPerformed(ActionEvent e) {
			switch(e.getActionCommand()) {
			case BackButtonConfiguration.ActionCommand : startPreviousService(); break;
			case LogoutButtonConfiguration.ActionCommand : startFirstService(); break;
			default : processEvent(e); break;
			}
		}
	}
}
